-- MariaDB dump 10.19  Distrib 10.5.15-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.3.35-MariaDB-1:10.3.35+maria~focal-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_qyauowdvjcprzfqmukujyzovrbeosyqpzjpk` (`ownerId`),
  CONSTRAINT `fk_qyauowdvjcprzfqmukujyzovrbeosyqpzjpk` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wowtrijxlbiuvxknaykxqdeifchxmkchigze` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `pluginId` int(11) DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT 1,
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pugyduxhdbikidgivddacaqlfxzgscdouvyz` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_ztrnoqgjtqodsseddrhqciwotpwhwqbcsqmh` (`dateRead`),
  KEY `fk_syyicbxkvykyibnkcfxyzkpkigndcmoohlqa` (`pluginId`),
  CONSTRAINT `fk_dzvmiroklrijwckrwiooqpziapcsumeraxpj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_syyicbxkvykyibnkcfxyzkpkigndcmoohlqa` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` int(11) NOT NULL,
  `volumeId` int(11) NOT NULL,
  `uri` text DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT 0,
  `recordId` int(11) DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT 0,
  `inProgress` tinyint(1) DEFAULT 0,
  `completed` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_efwjnbajvvvkbgxzevmucyurruitkbgdvugs` (`sessionId`,`volumeId`),
  KEY `idx_htexishznxvpigrioyglwjqmxbzrrjiaycwu` (`volumeId`),
  CONSTRAINT `fk_haqozspzhexrmtbjooddifdhmbmnjxmqanfn` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pxgilhihiwemseufshtzvkdoyjoehgbfxurj` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexingsessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text DEFAULT NULL,
  `totalEntries` int(11) DEFAULT NULL,
  `processedEntries` int(11) NOT NULL DEFAULT 0,
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `isCli` tinyint(1) DEFAULT 0,
  `actionRequired` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mlfziywzxsfaevcmpccxfluolunqbnguzsae` (`filename`,`folderId`),
  KEY `idx_pqfvemsyikfkiqkvvesmjjhlccynibbmjdhv` (`folderId`),
  KEY `idx_zeetacaheewxeaasrwjbfnimwkjuioplwovr` (`volumeId`),
  KEY `fk_mzxyjcvrlvobxsaxktpbhheujjvftvxfyvdo` (`uploaderId`),
  CONSTRAINT `fk_jufsxuyrkhjcbfgaexhkhlcmmpunzramjbph` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mzxyjcvrlvobxsaxktpbhheujjvftvxfyvdo` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ojtkndlherqvrvhhckzgldcrdhhrkuvaeoqy` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xqubraccqqxkxhqufffhxopgizjrdykiolle` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_admhavjgpnuovjnshjhapyqzjkywtymirkut` (`groupId`),
  KEY `fk_rlgsaqwqjogtzxxcwuncmiqpjfmrcipjwcku` (`parentId`),
  CONSTRAINT `fk_cikyoyrdlnapgpajgyfnqzolrwvmsmguvbqw` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_emqinnuzrqvpktzzbgwwndeiebyaqwxpiuuk` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rlgsaqwqjogtzxxcwuncmiqpjfmrcipjwcku` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jyqjbxwcuabjvqsvvflhqtekggmxbnhimyxo` (`name`),
  KEY `idx_hdeohiggnuxnhmjhffaqhrfomkegjekquqec` (`handle`),
  KEY `idx_epnkokkuctacqdjknlngowxlelwtkuhoalyd` (`structureId`),
  KEY `idx_rgfbhiqbcnxeidyfkcczvgvyskbazsuuhurh` (`fieldLayoutId`),
  KEY `idx_mddbdaxqruotlftyjlxszjnckmlbqhwdptks` (`dateDeleted`),
  CONSTRAINT `fk_ffzwxrvonancobqgmtyjyaqhjsqodbwilgdl` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iihmtbcfjkcfecbachsmzeebjcjsfcjoxgqa` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zmhioftwpzfvjnspduqfzujjccbutbtymynz` (`groupId`,`siteId`),
  KEY `idx_gvbewfnleouailxirhmxmzoccibtxonjcalk` (`siteId`),
  CONSTRAINT `fk_qeabohzwzwjuzpyhgkkdevrrcausuninxkhl` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_yaxktyzuhbqmegojhbiorwdfbinkkwqafjxb` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_wnowonrmzggmlqnyrhaspxhpcenlkkrihdug` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_cypydohfoovregouemtkhnykzysmukchffhi` (`siteId`),
  KEY `fk_jdzeeenwywbzqhytfcmcibktkgaaebioznjr` (`userId`),
  CONSTRAINT `fk_cmqcpndxfjxedwasxedoxecuapgxtkpgtfdv` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_cypydohfoovregouemtkhnykzysmukchffhi` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jdzeeenwywbzqhytfcmcibktkgaaebioznjr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_rewcdtgwwqhdtmhwczccokkpvsdyygthjdtj` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_itwjtxuzqrdqnxzfkeacsciradecizyiycmt` (`siteId`),
  KEY `fk_mmqatyldpkiyouwutkpgpvayfjimtdcxelmq` (`fieldId`),
  KEY `fk_idnjnisgsphheiaqpfvdztddhidhnudinwqf` (`userId`),
  CONSTRAINT `fk_idnjnisgsphheiaqpfvdztddhidhnudinwqf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_itwjtxuzqrdqnxzfkeacsciradecizyiycmt` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mmqatyldpkiyouwutkpgpvayfjimtdcxelmq` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_oilzvdxqrgxmvpxocsldagsnahbwlovhezqn` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_coupons`
--

DROP TABLE IF EXISTS `commerce_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) DEFAULT NULL,
  `discountId` int(11) NOT NULL,
  `uses` int(11) NOT NULL DEFAULT 0,
  `maxUses` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pysndbvuosjlorbrmfxqyowgoiapehwmpxhf` (`discountId`),
  KEY `idx_pqejchjyurduhmawxgsfwniwprqcshczfulq` (`code`),
  CONSTRAINT `fk_rmichzsxctkiygcsligbfauzhclxiimbhvhh` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_customer_discountuses`
--

DROP TABLE IF EXISTS `commerce_customer_discountuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_customer_discountuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discountId` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `uses` int(11) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rkdgspdgdeqtxwjocyhculkqhgxyjeiwbumn` (`customerId`,`discountId`),
  KEY `idx_sisfjiousiohyprddyccvktidzjtcjpfxuzq` (`discountId`),
  CONSTRAINT `fk_nhpfplnakxetvthykjhqymeivdhidzrsyiyh` FOREIGN KEY (`customerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qbjqmucwlqmgtbnlpfpvhtljxctvjnesgmpx` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_customers`
--

DROP TABLE IF EXISTS `commerce_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerId` int(11) NOT NULL,
  `primaryBillingAddressId` int(11) DEFAULT NULL,
  `primaryShippingAddressId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_isczwcnjdlsilmsorgmmogqzasechxllqwrt` (`customerId`),
  KEY `idx_yhhshdiauzsgqjwwxzipcfnbiqqoseyoaqlr` (`primaryBillingAddressId`),
  KEY `idx_dldvtifbksqyonlxmkmvrknubkzghgrfbdte` (`primaryShippingAddressId`),
  CONSTRAINT `fk_cidujndwezsbczfeuabfzytdxkfgcsfdeggy` FOREIGN KEY (`primaryBillingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ooiqtnwvlzfjspcquxwqriobwakvrrenvqjn` FOREIGN KEY (`customerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wxxeacsizhysjhtltvrccgvgapvsglevrcpg` FOREIGN KEY (`primaryShippingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_discount_categories`
--

DROP TABLE IF EXISTS `commerce_discount_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_discount_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discountId` int(11) NOT NULL,
  `categoryId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hshudjfxtfaqjaehhuhiwsfouokdyrwkjojs` (`discountId`,`categoryId`),
  KEY `idx_ouajgjeziexopozpxxfcjlixqawfbpgvasef` (`categoryId`),
  CONSTRAINT `fk_cihlnsikzzymgigqkdtckmzuibqsflvcoekz` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kjnvtrhzukhakshnwjrxaanrfflhupjofmvw` FOREIGN KEY (`categoryId`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_discount_purchasables`
--

DROP TABLE IF EXISTS `commerce_discount_purchasables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_discount_purchasables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discountId` int(11) NOT NULL,
  `purchasableId` int(11) NOT NULL,
  `purchasableType` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yplsceyqkyvcxxghpiwymolxeszagojydvmi` (`discountId`,`purchasableId`),
  KEY `idx_poeycgqnvlukhimgsenmdieetzhdkiggqchh` (`purchasableId`),
  CONSTRAINT `fk_ljxcvpnxowbyfhyltbiukklcvftqgxoxdili` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_uvyrmfitndejgrmmrfrcuuiwocwavcvjluio` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_discounts`
--

DROP TABLE IF EXISTS `commerce_discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `couponFormat` varchar(20) NOT NULL DEFAULT '######',
  `orderCondition` text DEFAULT NULL,
  `customerCondition` text DEFAULT NULL,
  `shippingAddressCondition` text DEFAULT NULL,
  `billingAddressCondition` text DEFAULT NULL,
  `perUserLimit` int(11) unsigned NOT NULL DEFAULT 0,
  `perEmailLimit` int(11) unsigned NOT NULL DEFAULT 0,
  `totalDiscountUses` int(11) unsigned NOT NULL DEFAULT 0,
  `totalDiscountUseLimit` int(11) unsigned NOT NULL DEFAULT 0,
  `dateFrom` datetime DEFAULT NULL,
  `dateTo` datetime DEFAULT NULL,
  `purchaseQty` int(11) NOT NULL DEFAULT 0,
  `maxPurchaseQty` int(11) NOT NULL DEFAULT 0,
  `baseDiscount` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `baseDiscountType` enum('value','percentTotal','percentTotalDiscounted','percentItems','percentItemsDiscounted') NOT NULL DEFAULT 'value',
  `perItemDiscount` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `percentDiscount` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `percentageOffSubject` enum('original','discounted') NOT NULL,
  `excludeOnSale` tinyint(1) NOT NULL DEFAULT 0,
  `hasFreeShippingForMatchingItems` tinyint(1) NOT NULL DEFAULT 0,
  `hasFreeShippingForOrder` tinyint(1) NOT NULL DEFAULT 0,
  `allPurchasables` tinyint(1) NOT NULL DEFAULT 0,
  `allCategories` tinyint(1) NOT NULL DEFAULT 0,
  `appliedTo` enum('matchingLineItems','allLineItems') NOT NULL DEFAULT 'matchingLineItems',
  `categoryRelationshipType` enum('element','sourceElement','targetElement') NOT NULL DEFAULT 'element',
  `orderConditionFormula` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `stopProcessing` tinyint(1) NOT NULL DEFAULT 0,
  `ignoreSales` tinyint(1) NOT NULL DEFAULT 0,
  `sortOrder` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mzqbxrwunuoqzfpywtbjjmlvtztxwljfzerp` (`dateFrom`),
  KEY `idx_sexifwlkgkqyerloiusgtcnijryskqryurbv` (`dateTo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_donations`
--

DROP TABLE IF EXISTS `commerce_donations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_donations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(255) NOT NULL,
  `availableForPurchase` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_rjsutaxoyyjybimpfvkdmbomhzjtunsqdawm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_email_discountuses`
--

DROP TABLE IF EXISTS `commerce_email_discountuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_email_discountuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `discountId` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `uses` int(11) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wxsseimsjileubxaaxilichbmjxndpnkidob` (`email`,`discountId`),
  KEY `idx_luqelrpnoxpzmcveqwynzytpodcyfzbndikv` (`discountId`),
  CONSTRAINT `fk_zxesqcideumcsdhdvxwxjwjgxphpkdysykor` FOREIGN KEY (`discountId`) REFERENCES `commerce_discounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_emails`
--

DROP TABLE IF EXISTS `commerce_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `recipientType` enum('customer','custom') DEFAULT 'custom',
  `to` varchar(255) DEFAULT NULL,
  `bcc` varchar(255) DEFAULT NULL,
  `cc` varchar(255) DEFAULT NULL,
  `replyTo` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `templatePath` varchar(255) NOT NULL,
  `plainTextTemplatePath` varchar(255) DEFAULT NULL,
  `pdfId` int(11) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_tmzcdiwgvqzgrjzbbrbpoqexvshosbkynkfs` (`pdfId`),
  CONSTRAINT `fk_tmzcdiwgvqzgrjzbbrbpoqexvshosbkynkfs` FOREIGN KEY (`pdfId`) REFERENCES `commerce_pdfs` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_gateways`
--

DROP TABLE IF EXISTS `commerce_gateways`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `paymentType` enum('authorize','purchase') NOT NULL DEFAULT 'purchase',
  `isFrontendEnabled` varchar(500) NOT NULL DEFAULT '1',
  `isArchived` tinyint(1) NOT NULL DEFAULT 0,
  `dateArchived` datetime DEFAULT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ykiegshylktfqegjevrgeubzevvotiogttpo` (`handle`),
  KEY `idx_hpfaitaytmzalhjqsomdfmfivzbejqbqafjr` (`isArchived`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_lineitems`
--

DROP TABLE IF EXISTS `commerce_lineitems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_lineitems` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` int(11) NOT NULL,
  `purchasableId` int(11) DEFAULT NULL,
  `taxCategoryId` int(11) NOT NULL,
  `shippingCategoryId` int(11) NOT NULL,
  `description` text DEFAULT NULL,
  `options` text DEFAULT NULL,
  `optionsSignature` varchar(255) NOT NULL,
  `price` decimal(14,4) unsigned NOT NULL,
  `saleAmount` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `salePrice` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `sku` varchar(255) DEFAULT NULL,
  `weight` decimal(14,4) unsigned NOT NULL DEFAULT 0.0000,
  `height` decimal(14,4) unsigned NOT NULL DEFAULT 0.0000,
  `length` decimal(14,4) unsigned NOT NULL DEFAULT 0.0000,
  `width` decimal(14,4) unsigned NOT NULL DEFAULT 0.0000,
  `subtotal` decimal(14,4) unsigned NOT NULL DEFAULT 0.0000,
  `total` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `qty` int(11) unsigned NOT NULL,
  `note` text DEFAULT NULL,
  `privateNote` text DEFAULT NULL,
  `snapshot` longtext DEFAULT NULL,
  `lineItemStatusId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uxvtjdokjbgtkdcjvncswvxiivlcfaenckod` (`orderId`,`purchasableId`,`optionsSignature`),
  KEY `idx_exbtfzijhktfbklqxmoddxduswnskbqhizck` (`purchasableId`),
  KEY `idx_jomjjelyrdsjkgtowmpxdvumtrzctejrhhvq` (`taxCategoryId`),
  KEY `idx_mmjmotcodlgtfbozpyshnqyujzdbwbwtshvm` (`shippingCategoryId`),
  CONSTRAINT `fk_glbdwcumyxkcqzgbmdsndzujboqqeszybszw` FOREIGN KEY (`purchasableId`) REFERENCES `elements` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_kjwnrsdcyclcttumtgxiaajkupdvqqutskkn` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_onhsvafkfsolxfyzxaxcwmlmitzmnahluneh` FOREIGN KEY (`shippingCategoryId`) REFERENCES `commerce_shippingcategories` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_rfosfpkunccqkxnoicuuyueafhrkbskulise` FOREIGN KEY (`taxCategoryId`) REFERENCES `commerce_taxcategories` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_lineitemstatuses`
--

DROP TABLE IF EXISTS `commerce_lineitemstatuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_lineitemstatuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `color` enum('green','orange','red','blue','yellow','pink','purple','turquoise','light','grey','black') NOT NULL DEFAULT 'green',
  `isArchived` tinyint(1) NOT NULL DEFAULT 0,
  `dateArchived` datetime DEFAULT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_orderadjustments`
--

DROP TABLE IF EXISTS `commerce_orderadjustments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_orderadjustments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` int(11) NOT NULL,
  `lineItemId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount` decimal(14,4) NOT NULL,
  `included` tinyint(1) NOT NULL DEFAULT 0,
  `isEstimated` tinyint(1) NOT NULL DEFAULT 0,
  `sourceSnapshot` longtext DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_aeoccebtxbpfgsxeabvxxioimeopvzgyioth` (`orderId`),
  CONSTRAINT `fk_bhepvkpfadyorzpaeisqwnpdpffaunvlikpu` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_orderhistories`
--

DROP TABLE IF EXISTS `commerce_orderhistories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_orderhistories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `userName` varchar(255) DEFAULT NULL,
  `prevStatusId` int(11) DEFAULT NULL,
  `newStatusId` int(11) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vhwtaujxbxpfyhhmpcogkapnbnubmzafhyzm` (`orderId`),
  KEY `idx_likdjwiscepkbbpplrkecetaerqxbppygnzm` (`prevStatusId`),
  KEY `idx_twahuivskeshlrfjcmnnctojvygdcmwkejhl` (`newStatusId`),
  KEY `idx_stxsppuclajhhakixtafdxaukmnnxblxosaa` (`userId`),
  CONSTRAINT `fk_kbwknlzmlmjobrdlglpzdblfscswuojivbyw` FOREIGN KEY (`newStatusId`) REFERENCES `commerce_orderstatuses` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_kncyfqwkokclysjazkbvmkbueukwykybzyhy` FOREIGN KEY (`userId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rrllensqymtvdtppwwerogkvmnwimfkflgmk` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zgdhigoyseqhxwntwtymzdncwkkftqypjnio` FOREIGN KEY (`prevStatusId`) REFERENCES `commerce_orderstatuses` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_ordernotices`
--

DROP TABLE IF EXISTS `commerce_ordernotices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_ordernotices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` int(11) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `attribute` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_reckcfwlnbfvbhxmeiqhdgbmenvgegbcukoy` (`orderId`),
  CONSTRAINT `fk_undrkamessvmofnbqormdimxzokqsqcydglv` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_orders`
--

DROP TABLE IF EXISTS `commerce_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_orders` (
  `id` int(11) NOT NULL,
  `billingAddressId` int(11) DEFAULT NULL,
  `shippingAddressId` int(11) DEFAULT NULL,
  `estimatedBillingAddressId` int(11) DEFAULT NULL,
  `estimatedShippingAddressId` int(11) DEFAULT NULL,
  `sourceShippingAddressId` int(11) DEFAULT NULL,
  `sourceBillingAddressId` int(11) DEFAULT NULL,
  `gatewayId` int(11) DEFAULT NULL,
  `paymentSourceId` int(11) DEFAULT NULL,
  `customerId` int(11) DEFAULT NULL,
  `orderStatusId` int(11) DEFAULT NULL,
  `number` varchar(32) DEFAULT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `couponCode` varchar(255) DEFAULT NULL,
  `itemTotal` decimal(14,4) DEFAULT 0.0000,
  `itemSubtotal` decimal(14,4) DEFAULT 0.0000,
  `total` decimal(14,4) DEFAULT 0.0000,
  `totalPrice` decimal(14,4) DEFAULT 0.0000,
  `totalPaid` decimal(14,4) DEFAULT 0.0000,
  `totalDiscount` decimal(14,4) DEFAULT 0.0000,
  `totalTax` decimal(14,4) DEFAULT 0.0000,
  `totalTaxIncluded` decimal(14,4) DEFAULT 0.0000,
  `totalShippingCost` decimal(14,4) DEFAULT 0.0000,
  `paidStatus` enum('paid','partial','unpaid','overPaid') DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `isCompleted` tinyint(1) NOT NULL DEFAULT 0,
  `dateOrdered` datetime DEFAULT NULL,
  `datePaid` datetime DEFAULT NULL,
  `dateAuthorized` datetime DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `paymentCurrency` varchar(255) DEFAULT NULL,
  `lastIp` varchar(255) DEFAULT NULL,
  `orderLanguage` varchar(12) NOT NULL,
  `origin` enum('web','cp','remote') NOT NULL DEFAULT 'web',
  `message` text DEFAULT NULL,
  `registerUserOnOrderComplete` tinyint(1) NOT NULL DEFAULT 0,
  `recalculationMode` enum('all','none','adjustmentsOnly') NOT NULL DEFAULT 'all',
  `returnUrl` text DEFAULT NULL,
  `cancelUrl` text DEFAULT NULL,
  `shippingMethodHandle` varchar(255) DEFAULT NULL,
  `shippingMethodName` varchar(255) DEFAULT NULL,
  `orderSiteId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_njauvjzqydpwfboxxrbpxafbrzgqvzxqkpho` (`number`),
  KEY `idx_tgigeqhyjuhlewxrcjaqdsxmmqlgzlldpnip` (`reference`),
  KEY `idx_tcikvjzglfffiyabmzaztgugeqpjkddgqurs` (`billingAddressId`),
  KEY `idx_mtrwcxjynycjhthemjdyxcgbqaosyuvrvtao` (`shippingAddressId`),
  KEY `idx_yjnjjoqiicpnwzmztengybpbkzflpqsuegfp` (`gatewayId`),
  KEY `idx_fpdiesqoieosyvbcgeytdtdaxrihzlylyaxw` (`customerId`),
  KEY `idx_kjarkomeghmevttotawehpyiwyjxudlgjelg` (`orderStatusId`),
  KEY `idx_jboriohjrtyiiifkiuvbfscjwjzjxplgbzdr` (`email`),
  KEY `fk_finybngokyrwstvfeqnrphaaapsspfizritl` (`estimatedBillingAddressId`),
  KEY `fk_glijscfiijsjolldhtdcghfwzmsrkeoeygni` (`estimatedShippingAddressId`),
  KEY `fk_lbtomruqgaabbhzrbjkvzfxxzcbqmaxqbjzg` (`paymentSourceId`),
  CONSTRAINT `fk_cauzwuxsukwqpmfsldicleaeduoykvppoufw` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_finybngokyrwstvfeqnrphaaapsspfizritl` FOREIGN KEY (`estimatedBillingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_glijscfiijsjolldhtdcghfwzmsrkeoeygni` FOREIGN KEY (`estimatedShippingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lbtomruqgaabbhzrbjkvzfxxzcbqmaxqbjzg` FOREIGN KEY (`paymentSourceId`) REFERENCES `commerce_paymentsources` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_omdmuopwroemgkcomasuybylvqputnbxunjt` FOREIGN KEY (`orderStatusId`) REFERENCES `commerce_orderstatuses` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_opqymelyzqdmrzuymijzfoiljzxahuakpprb` FOREIGN KEY (`shippingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vbuelvyjuytkzzytnszmbzsqwbusptxdqlrz` FOREIGN KEY (`billingAddressId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yhvjhkqfiohqfraijgsttdsshpysdbzpahuw` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zycwnrgevitkicpgvmpscsxsltmqwicihgcf` FOREIGN KEY (`customerId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_orderstatus_emails`
--

DROP TABLE IF EXISTS `commerce_orderstatus_emails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_orderstatus_emails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderStatusId` int(11) NOT NULL,
  `emailId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fxrrscjcqqelkdyckqoroxvbinigdvsmxczg` (`orderStatusId`),
  KEY `idx_oyuorbrlobvqzdyacgeoaluhwziimhxmspwo` (`emailId`),
  CONSTRAINT `fk_mjzlfvciqltktyfngaaotoxfrzmstnwulrri` FOREIGN KEY (`orderStatusId`) REFERENCES `commerce_orderstatuses` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_strbnzigllycphkyqdabklrqlrdoqbffdexb` FOREIGN KEY (`emailId`) REFERENCES `commerce_emails` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_orderstatuses`
--

DROP TABLE IF EXISTS `commerce_orderstatuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_orderstatuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `color` enum('green','orange','red','blue','yellow','pink','purple','turquoise','light','grey','black') NOT NULL DEFAULT 'green',
  `description` varchar(255) DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_paymentcurrencies`
--

DROP TABLE IF EXISTS `commerce_paymentcurrencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_paymentcurrencies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iso` varchar(3) NOT NULL,
  `primary` tinyint(1) NOT NULL DEFAULT 0,
  `rate` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xsehdkhomttzbytngnwrljewtbmnjtwobzef` (`iso`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_paymentsources`
--

DROP TABLE IF EXISTS `commerce_paymentsources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_paymentsources` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customerId` int(11) NOT NULL,
  `gatewayId` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `response` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_jkpwnewfobyflmtqbhgvheofvmjjltouqppp` (`customerId`),
  KEY `fk_hkrjgvfncjpxjkydalutxjlguglwbbppokxk` (`gatewayId`),
  CONSTRAINT `fk_hkrjgvfncjpxjkydalutxjlguglwbbppokxk` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jkpwnewfobyflmtqbhgvheofvmjjltouqppp` FOREIGN KEY (`customerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_pdfs`
--

DROP TABLE IF EXISTS `commerce_pdfs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_pdfs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `templatePath` varchar(255) NOT NULL,
  `fileNameFormat` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `isDefault` tinyint(1) NOT NULL DEFAULT 0,
  `sortOrder` int(11) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_odqtpbxplszkfismghclwqtshbfqzqraganu` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_plans`
--

DROP TABLE IF EXISTS `commerce_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gatewayId` int(11) DEFAULT NULL,
  `planInformationId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `planData` text DEFAULT NULL,
  `isArchived` tinyint(1) NOT NULL DEFAULT 0,
  `dateArchived` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_yvwgajzszgwdzbnztilkmghmuwtodzyjryfe` (`handle`),
  KEY `idx_nbbubaepjntpmndzoohqfnyoddbfvwoiyttu` (`gatewayId`),
  KEY `idx_pvgyoavocmyrwntdjbetgsynxgdpbiagdcvp` (`reference`),
  KEY `fk_yubfmuimfngdsfvdoxqatanyujbqvoqzmsgb` (`planInformationId`),
  CONSTRAINT `fk_prhkaodbduweisejbzpwrywrdjxncrrkchef` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yubfmuimfngdsfvdoxqatanyujbqvoqzmsgb` FOREIGN KEY (`planInformationId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_products`
--

DROP TABLE IF EXISTS `commerce_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_products` (
  `id` int(11) NOT NULL,
  `typeId` int(11) DEFAULT NULL,
  `taxCategoryId` int(11) NOT NULL,
  `shippingCategoryId` int(11) NOT NULL,
  `defaultVariantId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `promotable` tinyint(1) NOT NULL DEFAULT 0,
  `availableForPurchase` tinyint(1) NOT NULL DEFAULT 1,
  `freeShipping` tinyint(1) NOT NULL DEFAULT 1,
  `defaultSku` varchar(255) DEFAULT NULL,
  `defaultPrice` decimal(14,4) DEFAULT NULL,
  `defaultHeight` decimal(14,4) DEFAULT NULL,
  `defaultLength` decimal(14,4) DEFAULT NULL,
  `defaultWidth` decimal(14,4) DEFAULT NULL,
  `defaultWeight` decimal(14,4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pngypjuaxcaqbrtlnntzcseqfsvytccazzja` (`typeId`),
  KEY `idx_qvhlqhewanotmcmcmwaflakqguqbgtvxgolt` (`postDate`),
  KEY `idx_cablnomvccjpvqdtdfwbigvltwdhoefofkct` (`expiryDate`),
  KEY `idx_neuvyzqbezkbjhffxjgjczltkvyqvnzsmiad` (`taxCategoryId`),
  KEY `idx_usaweayvgxjxmmluafkbdgfbbseehofgmyjn` (`shippingCategoryId`),
  CONSTRAINT `fk_bffhwhpshsninqzgredmjaqzxyshjgxaynee` FOREIGN KEY (`taxCategoryId`) REFERENCES `commerce_taxcategories` (`id`),
  CONSTRAINT `fk_jjzhtsxyzbpoiukvwqpnmkgtbfmvrolljjwj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kxcprrzlnpcbmdjbrdskgzuxpiptdhhgdhuk` FOREIGN KEY (`shippingCategoryId`) REFERENCES `commerce_shippingcategories` (`id`),
  CONSTRAINT `fk_zxofqiywscnyeqqusfkgigbkxlygmlqbtzto` FOREIGN KEY (`typeId`) REFERENCES `commerce_producttypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_producttypes`
--

DROP TABLE IF EXISTS `commerce_producttypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_producttypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `variantFieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasDimensions` tinyint(1) NOT NULL DEFAULT 0,
  `hasVariants` tinyint(1) NOT NULL DEFAULT 0,
  `hasVariantTitleField` tinyint(1) NOT NULL DEFAULT 1,
  `variantTitleFormat` varchar(255) NOT NULL,
  `hasProductTitleField` tinyint(1) NOT NULL DEFAULT 1,
  `productTitleFormat` varchar(255) DEFAULT NULL,
  `skuFormat` varchar(255) DEFAULT NULL,
  `descriptionFormat` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vawokmxaiiehvjdmtqeqcjpfgeyqikwtakor` (`handle`),
  KEY `idx_gqzqcwkgslkitssjzsjpzbvpbvujcotztilr` (`fieldLayoutId`),
  KEY `idx_srlwurzejtiuhogfqzsfqzobdmkgoyhthdjg` (`variantFieldLayoutId`),
  CONSTRAINT `fk_vdeyvoeanpmvdeainykmvkttpyyvqpapuchb` FOREIGN KEY (`variantFieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wfmobwggouhsiawdwxxtysopcmtigugpkxdb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_producttypes_shippingcategories`
--

DROP TABLE IF EXISTS `commerce_producttypes_shippingcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_producttypes_shippingcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productTypeId` int(11) NOT NULL,
  `shippingCategoryId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vmpphopgpbujeiwgmiopzuugllcfdmplsjdn` (`productTypeId`,`shippingCategoryId`),
  KEY `idx_yqqdjbgjgpmckntmgkdkxblcxrtufuubmobj` (`shippingCategoryId`),
  CONSTRAINT `fk_hypochuzgvivwgogyaffcdfiidzgpgzsoqju` FOREIGN KEY (`shippingCategoryId`) REFERENCES `commerce_shippingcategories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zufdvjnptmcowqdiqbjuxepophvdhelfbpqy` FOREIGN KEY (`productTypeId`) REFERENCES `commerce_producttypes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_producttypes_sites`
--

DROP TABLE IF EXISTS `commerce_producttypes_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_producttypes_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productTypeId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ywhnocdgloroqrpmjijeriuvhuepwzhttdus` (`productTypeId`,`siteId`),
  KEY `idx_cdiruhysbyzqjakpyjmfnyrcusmiohnsoaiz` (`siteId`),
  CONSTRAINT `fk_btyekgfcyoiqblviexnhcmgponbkynykczym` FOREIGN KEY (`productTypeId`) REFERENCES `commerce_producttypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wrhmmwdobwqpbqqksmpddwzxekdasiewxxga` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_producttypes_taxcategories`
--

DROP TABLE IF EXISTS `commerce_producttypes_taxcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_producttypes_taxcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productTypeId` int(11) NOT NULL,
  `taxCategoryId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_obfhvdsevoygqskjzwtudbffgdufhnglrihq` (`productTypeId`,`taxCategoryId`),
  KEY `idx_vnyqmzdasysabjpvafxhrnnwcurfsrpoyqio` (`taxCategoryId`),
  CONSTRAINT `fk_avtldhkoznuuqshsoxwnreazdphpezcwxnpg` FOREIGN KEY (`taxCategoryId`) REFERENCES `commerce_taxcategories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fmhcxuzlsfqrdxnxochskiwodqbzwnzefjpq` FOREIGN KEY (`productTypeId`) REFERENCES `commerce_producttypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_purchasables`
--

DROP TABLE IF EXISTS `commerce_purchasables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_purchasables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sku` varchar(255) NOT NULL,
  `price` decimal(14,4) NOT NULL,
  `description` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_acavyblubthoeaarfhopxtrrgbmjxipqgknu` (`sku`),
  CONSTRAINT `fk_cifdxpfwrxtxsqptyqsozjayrgtlqsxmqvcy` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_sale_categories`
--

DROP TABLE IF EXISTS `commerce_sale_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_sale_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `saleId` int(11) NOT NULL,
  `categoryId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_eybneamuhjvdjspqzlgeejuxyvwoikuawoif` (`saleId`,`categoryId`),
  KEY `idx_nsrmouzxpcstmsdurfpnhkutcsgvdahzliff` (`categoryId`),
  CONSTRAINT `fk_dkjmxsfeweswxxmafuhcseinyclkbcqkaitw` FOREIGN KEY (`saleId`) REFERENCES `commerce_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jrmvocfkiwfwyictincfvzjevkewzulrqrbw` FOREIGN KEY (`categoryId`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_sale_purchasables`
--

DROP TABLE IF EXISTS `commerce_sale_purchasables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_sale_purchasables` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `saleId` int(11) NOT NULL,
  `purchasableId` int(11) NOT NULL,
  `purchasableType` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wpcqbczuorxehaysgvugvtntmjnubvklzqcm` (`saleId`,`purchasableId`),
  KEY `idx_cptkevcluvtjtqgarndeydtyuhvzjgwvtbhk` (`purchasableId`),
  CONSTRAINT `fk_hnarswgxnndtchujvzofmcyxhjlfxktotbhk` FOREIGN KEY (`purchasableId`) REFERENCES `commerce_purchasables` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ofelybomgcpaqwzhdhcxkbulxaccckftxsxn` FOREIGN KEY (`saleId`) REFERENCES `commerce_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_sale_usergroups`
--

DROP TABLE IF EXISTS `commerce_sale_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_sale_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `saleId` int(11) NOT NULL,
  `userGroupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wpwyhczynfpzyncwahyrufrthjbeopxzvqkz` (`saleId`,`userGroupId`),
  KEY `idx_scxorhsxcpsqzosbuzwbyoerbpyhxortqutu` (`userGroupId`),
  CONSTRAINT `fk_jmuplcgirlscpkfuistzuzrcmhzeojwpfyer` FOREIGN KEY (`saleId`) REFERENCES `commerce_sales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mthnzxuisimbfptxvpfyqlbwrwuwwttmjvxo` FOREIGN KEY (`userGroupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_sales`
--

DROP TABLE IF EXISTS `commerce_sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `dateFrom` datetime DEFAULT NULL,
  `dateTo` datetime DEFAULT NULL,
  `apply` enum('toPercent','toFlat','byPercent','byFlat') NOT NULL,
  `applyAmount` decimal(14,4) NOT NULL,
  `allGroups` tinyint(1) NOT NULL DEFAULT 0,
  `allPurchasables` tinyint(1) NOT NULL DEFAULT 0,
  `allCategories` tinyint(1) NOT NULL DEFAULT 0,
  `categoryRelationshipType` enum('element','sourceElement','targetElement') NOT NULL DEFAULT 'element',
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `ignorePrevious` tinyint(1) NOT NULL DEFAULT 0,
  `stopProcessing` tinyint(1) NOT NULL DEFAULT 0,
  `sortOrder` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_shippingcategories`
--

DROP TABLE IF EXISTS `commerce_shippingcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_shippingcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dajdzwdkaucpeagysaitjxzbuzeasyiscvap` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_shippingmethods`
--

DROP TABLE IF EXISTS `commerce_shippingmethods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_shippingmethods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `isLite` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vzbhllliduugdfmvnibtpklekfzqgjihmwll` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_shippingrule_categories`
--

DROP TABLE IF EXISTS `commerce_shippingrule_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_shippingrule_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shippingRuleId` int(11) DEFAULT NULL,
  `shippingCategoryId` int(11) DEFAULT NULL,
  `condition` enum('allow','disallow','require') NOT NULL,
  `perItemRate` decimal(14,4) DEFAULT NULL,
  `weightRate` decimal(14,4) DEFAULT NULL,
  `percentageRate` decimal(14,4) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_phntgfbfskuracclxxbkqsrxtqeeqaevoeaw` (`shippingRuleId`),
  KEY `idx_lblxkghoshxgwjbjimqaskgyadzqnjkyssyd` (`shippingCategoryId`),
  CONSTRAINT `fk_fvblwubrcaeyxqzzvowcyrcakfivbmoixzom` FOREIGN KEY (`shippingCategoryId`) REFERENCES `commerce_shippingcategories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_omdafhdhgzcqzktdyziezbgshyhwhsvxawoq` FOREIGN KEY (`shippingRuleId`) REFERENCES `commerce_shippingrules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_shippingrules`
--

DROP TABLE IF EXISTS `commerce_shippingrules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_shippingrules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `shippingZoneId` int(11) DEFAULT NULL,
  `methodId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `priority` int(11) NOT NULL DEFAULT 0,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `orderConditionFormula` text DEFAULT NULL,
  `minQty` int(11) NOT NULL DEFAULT 0,
  `maxQty` int(11) NOT NULL DEFAULT 0,
  `minTotal` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `maxTotal` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `minMaxTotalType` enum('salePrice','salePriceWithDiscounts') NOT NULL DEFAULT 'salePrice',
  `minWeight` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `maxWeight` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `baseRate` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `perItemRate` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `weightRate` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `percentageRate` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `minRate` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `maxRate` decimal(14,4) NOT NULL DEFAULT 0.0000,
  `isLite` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gmyxmgwjtopniyzilrlubsrekgsjqkhkalne` (`name`),
  KEY `idx_wrogyfhnitldkersdyzlddawfpnqnvtmgehf` (`methodId`),
  KEY `idx_dfbixtqngcfnnuyuanocvucgbeequrodlwwc` (`shippingZoneId`),
  CONSTRAINT `fk_gbfkvwdpvtmhgpumqryvytyjtcieckixlpby` FOREIGN KEY (`methodId`) REFERENCES `commerce_shippingmethods` (`id`),
  CONSTRAINT `fk_gwtsmuqizklcicgpwgkforssuydrigkrrfkx` FOREIGN KEY (`shippingZoneId`) REFERENCES `commerce_shippingzones` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_shippingzones`
--

DROP TABLE IF EXISTS `commerce_shippingzones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_shippingzones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `condition` text DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ekqywbejlueezpaiklbhsdljdimfvsmysfcg` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_stores`
--

DROP TABLE IF EXISTS `commerce_stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_stores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locationAddressId` int(11) DEFAULT NULL,
  `countries` text DEFAULT NULL,
  `marketAddressCondition` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_subscriptions`
--

DROP TABLE IF EXISTS `commerce_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_subscriptions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `planId` int(11) DEFAULT NULL,
  `gatewayId` int(11) DEFAULT NULL,
  `orderId` int(11) DEFAULT NULL,
  `reference` varchar(255) NOT NULL,
  `subscriptionData` text DEFAULT NULL,
  `trialDays` int(11) NOT NULL,
  `nextPaymentDate` datetime DEFAULT NULL,
  `hasStarted` tinyint(1) NOT NULL DEFAULT 1,
  `isSuspended` tinyint(1) NOT NULL DEFAULT 0,
  `dateSuspended` datetime DEFAULT NULL,
  `isCanceled` tinyint(1) NOT NULL DEFAULT 0,
  `dateCanceled` datetime DEFAULT NULL,
  `isExpired` tinyint(1) NOT NULL DEFAULT 0,
  `dateExpired` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kzxpyhxzyglbyfxxbnqvjbmrxniqqfbxjeqh` (`reference`),
  KEY `idx_gtktqsvqsukwpnewkrhdaiplafsdlbrazrgg` (`userId`),
  KEY `idx_swcqqhncjlymxfjxyljohmzoubqopsrweacp` (`planId`),
  KEY `idx_udrkapjhhulvpnrkrhtdonopehsqmbtcytdd` (`gatewayId`),
  KEY `idx_eiuthdmnnodncbovpannkubrtqjeejhsmaxz` (`nextPaymentDate`),
  KEY `idx_qgcvgfohogmfzstgoxtfozgmtfoqarfrwkeq` (`dateCreated`),
  KEY `idx_inzyltgbnchnefydcibnhbgxqibwcahkezaz` (`dateExpired`),
  KEY `fk_ncoioxyfczudiikovwykbfulsxwripauxsfc` (`orderId`),
  CONSTRAINT `fk_agvuqznblhdmiegxhyhkugsiicseqxtsjuhj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_akcmztbswdtemfaixacfevhonblhkwxfdspa` FOREIGN KEY (`planId`) REFERENCES `commerce_plans` (`id`),
  CONSTRAINT `fk_ncoioxyfczudiikovwykbfulsxwripauxsfc` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_nreocriolgqtpnqgrwchfbirfcgxktudojzf` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qrmaizzrswpeymyjgcpbxwihfgslhxmefqvs` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_taxcategories`
--

DROP TABLE IF EXISTS `commerce_taxcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_taxcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lfvhlesgepufwduinslmlltoltkmwujjpnex` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_taxrates`
--

DROP TABLE IF EXISTS `commerce_taxrates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_taxrates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taxZoneId` int(11) DEFAULT NULL,
  `isEverywhere` tinyint(1) NOT NULL DEFAULT 1,
  `taxCategoryId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `rate` decimal(14,10) NOT NULL,
  `include` tinyint(1) NOT NULL DEFAULT 0,
  `isVat` tinyint(1) NOT NULL DEFAULT 0,
  `removeIncluded` tinyint(1) NOT NULL DEFAULT 0,
  `removeVatIncluded` tinyint(1) NOT NULL DEFAULT 0,
  `taxable` enum('purchasable','price','shipping','price_shipping','order_total_shipping','order_total_price') NOT NULL,
  `isLite` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_uafiohghknfeooraosqtzhnioaxfcobkiolo` (`taxZoneId`),
  KEY `idx_fbbbnfvhjwzctqlystroejqmdoramffkkrve` (`taxCategoryId`),
  CONSTRAINT `fk_cydpaolxzinnpmhnlkfozhjmczsqjgljbpmh` FOREIGN KEY (`taxZoneId`) REFERENCES `commerce_taxzones` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_tiqmeencaamaqrnazsshsaspdwfeifghsahn` FOREIGN KEY (`taxCategoryId`) REFERENCES `commerce_taxcategories` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_taxzones`
--

DROP TABLE IF EXISTS `commerce_taxzones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_taxzones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `condition` text DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_irrnnuynhqpaumtakgxhzydxpnjgkkskznpk` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_transactions`
--

DROP TABLE IF EXISTS `commerce_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `gatewayId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `hash` varchar(32) DEFAULT NULL,
  `type` enum('authorize','capture','purchase','refund') NOT NULL,
  `amount` decimal(14,4) DEFAULT NULL,
  `paymentAmount` decimal(14,4) DEFAULT NULL,
  `currency` varchar(255) DEFAULT NULL,
  `paymentCurrency` varchar(255) DEFAULT NULL,
  `paymentRate` decimal(14,4) DEFAULT NULL,
  `status` enum('pending','redirect','success','failed','processing') NOT NULL,
  `reference` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `note` mediumtext DEFAULT NULL,
  `response` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cqflwdiwioitbafktnycazracphxgbffuttm` (`parentId`),
  KEY `idx_hfwltidglpybnaipexmlhazfskbwnhuzragu` (`gatewayId`),
  KEY `idx_eiczwokwnomlohljfxfcdahgrzaldqejzwkg` (`orderId`),
  KEY `idx_fhrysswxxlnwulwjxsanbchsgkxovqrjydcw` (`userId`),
  CONSTRAINT `fk_jywkojelswulhuoetnqihamxotihxvnqrhne` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_otddeyjeegrmjqjsohokujaecleckixehcnb` FOREIGN KEY (`parentId`) REFERENCES `commerce_transactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qsfqtmojjftdlqpgugmvvjhnmgbroyogcdni` FOREIGN KEY (`userId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xfurjdajnpsafwfwxuknfjoujyojboeprlgs` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `commerce_variants`
--

DROP TABLE IF EXISTS `commerce_variants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commerce_variants` (
  `id` int(11) NOT NULL,
  `productId` int(11) DEFAULT NULL,
  `sku` varchar(255) NOT NULL,
  `isDefault` tinyint(1) NOT NULL DEFAULT 0,
  `price` decimal(14,4) NOT NULL,
  `sortOrder` int(11) DEFAULT NULL,
  `width` decimal(14,4) DEFAULT NULL,
  `height` decimal(14,4) DEFAULT NULL,
  `length` decimal(14,4) DEFAULT NULL,
  `weight` decimal(14,4) DEFAULT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `hasUnlimitedStock` tinyint(1) NOT NULL DEFAULT 0,
  `minQty` int(11) DEFAULT NULL,
  `maxQty` int(11) DEFAULT NULL,
  `deletedWithProduct` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cflkawxzuiotindollprdczapgvyqgthurew` (`sku`),
  KEY `idx_loqoxyjhdshrssxzmewqchzhpkbmzjegtqro` (`productId`),
  CONSTRAINT `fk_gsdfnqrznaurcdpaxeiwwvezwgednaqillwd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ifhkifhzadlsksonmddcvyxxkaeejkdxfexa` FOREIGN KEY (`productId`) REFERENCES `commerce_products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_heading_kfvlhjpo` text DEFAULT NULL,
  `field_pagination_peazjrid` varchar(255) DEFAULT NULL,
  `field_keywords_uzxqvjtt` text DEFAULT NULL,
  `field_color_iyxiwocv` varchar(255) DEFAULT NULL,
  `field_size_ydwihhqh` varchar(255) DEFAULT NULL,
  `field_previewText_qeshyjtt` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_stecjpdtcwsibhfpzffawehxiredvgxqdfsm` (`elementId`,`siteId`),
  KEY `idx_qrfcdhzsvomidinvicnjmrmrohwjgnygybno` (`siteId`),
  KEY `idx_gqnlucstfuvqqjxodxsmkwcjodyooynmjxze` (`title`),
  CONSTRAINT `fk_nwvjqngwxkwqlbqzfztfbiojvzbsxricyhdb` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qfbsmqgfvcdhlgmucailepkxuqwnlrpelkwo` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_decsolzrjcmkruonmypvmwvbggqqzcjhfkal` (`userId`),
  CONSTRAINT `fk_decsolzrjcmkruonmypvmwvbggqqzcjhfkal` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` text DEFAULT NULL,
  `traces` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cnrhcavomzifpfvqseocjmyedgijvcmhnqfa` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `trackChanges` tinyint(1) NOT NULL DEFAULT 0,
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_kszgacfacgqjvmpbqjenzfgctulvrvoetukm` (`creatorId`,`provisional`),
  KEY `idx_exjdplrpjijkhqlmsisjpilxnxlktuvtmnlp` (`saved`),
  KEY `fk_xhxovtghmccpkxqofpzylkdjweuatnuvaxuk` (`canonicalId`),
  CONSTRAINT `fk_uatxsmhqfujdppvihnbtehvlfddltfjvxmhb` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xhxovtghmccpkxqofpzylkdjweuatnuvaxuk` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_strpupkktludorqjdjjxrhpjcbewxskowjha` (`dateDeleted`),
  KEY `idx_focyywtvxnoojroizxillprehijdnnemhwca` (`fieldLayoutId`),
  KEY `idx_icpowfjpxzjlnkwljrdiamhffvbopvzdikjp` (`type`),
  KEY `idx_vygmuyfsteggmbtcnhwfpyfemmfbllyitshz` (`enabled`),
  KEY `idx_kbkeojtmbsxvwqnhmldxycphgjmcnxrrvqfl` (`archived`,`dateCreated`),
  KEY `idx_kcxrecpnkeyordevucycjocguhajifptegli` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_sqkwyhizlzcgrraskbpwjykjwcyyxaqpwbxn` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_ibqwyhujayoldhtshzcfwayvbctnulhknghp` (`canonicalId`),
  KEY `fk_frtkiubsqektsakrqimusvimcwbeqlbzgamd` (`draftId`),
  KEY `fk_oziemgqrqhpvqihqhlzjexlvfhqkfjllzrll` (`revisionId`),
  CONSTRAINT `fk_cbvaclnjdwkmjlizecmgyjreorqqxkiayjkb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_frtkiubsqektsakrqimusvimcwbeqlbzgamd` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ibqwyhujayoldhtshzcfwayvbctnulhknghp` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_oziemgqrqhpvqihqhlzjexlvfhqkfjllzrll` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ydsgegjbghiqowjjovasiwgveplhpxzdavtg` (`elementId`,`siteId`),
  KEY `idx_udcnrzauaxzhhvbuaknmykspkgopdygajwmf` (`siteId`),
  KEY `idx_smavcmiiwvimjrddolgesycoyqeclocldeij` (`slug`,`siteId`),
  KEY `idx_gdatttwdyhbhlraeydqhdhklthakiiwiuhyf` (`enabled`),
  KEY `idx_xycxnkuajxyshjwcfmjaolwjckuujbsgwwit` (`uri`,`siteId`),
  CONSTRAINT `fk_amlgyvfoxdocbqhmvmslnpwiuixoiehrtnov` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pmopfcwvbkkopvxrunnwzccmrxvknetvmyjb` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uwgztpumfdxnkzgjjxzgacwqgrdisyftlkfr` (`postDate`),
  KEY `idx_dyxdumumozyarmmrhumegnvngooxehiijgai` (`expiryDate`),
  KEY `idx_exaoyazmpqqtkwcqograeemxxngltrgksest` (`authorId`),
  KEY `idx_xibzfwrshoqzvfobqgnbamzgymjtwzbbpzhj` (`sectionId`),
  KEY `idx_ijiewyvddqjvpuqdawysipmlbjpbnvmjbgdx` (`typeId`),
  KEY `fk_wzbrxgtkzgkfjafnnhgwzsdukfptubobaavr` (`parentId`),
  CONSTRAINT `fk_iyvtlinnhzojjqwudhjyqfmajpagmuiopkaj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mlgithohtrqimdlbnexsruejzphveqlwdmvx` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ownjriqoczxifewpshvokoppabtxkymsoxif` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wzbrxgtkzgkfjafnnhgwzsdukfptubobaavr` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_yqfstrbazrixwdjnrtcbriyjfhlfnytobmvs` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT 1,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_hukhdxsaaqtibchcwfpurbfyqltghpkgarkx` (`name`,`sectionId`),
  KEY `idx_mfmuhnmfdfitbprkdnffdgjcucnjaeexfuur` (`handle`,`sectionId`),
  KEY `idx_tupikteferrmshkhoacolcytqnmqqehaeslg` (`sectionId`),
  KEY `idx_qqfuflyhtllthveetmthugehimqfamcbqdvq` (`fieldLayoutId`),
  KEY `idx_dueoqoglyxmllmukgyhuwnevlxlxizlryrho` (`dateDeleted`),
  CONSTRAINT `fk_erimwkfgwjqefvxhxmzszqnjbfxfyoijumxb` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ygrwrymvpbtholtivgsivwbjafaachsrvghj` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_roxuyoegesonmoiinectmejlghqkzvwxymfy` (`name`),
  KEY `idx_tsynhruogsyrrwfjdxykdjoenzzlgshwfsep` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lamrzmwcjrvxvvlahrmdgaxueefpmcuksdcr` (`layoutId`,`fieldId`),
  KEY `idx_rnxgnwrdmvppjdztvlqpbsfjgenoulhhhxzc` (`sortOrder`),
  KEY `idx_bvdkccfralbqsptkjmrlskyafrwbzucsdvdb` (`tabId`),
  KEY `idx_vrzeemykzqswwqboirhzqczfmevwmmuhgvtx` (`fieldId`),
  CONSTRAINT `fk_ksosskygvbkbqmnmhyvhrvrhhomaqaabasll` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tnakcerfydlvwkhmhxtybkdsuwnvfwxtrtuz` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vciwxuwgbguoqhkqgbttrmmzoiwokiadbszi` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kefldmuvapkwbotmzuspxidmhgrjskypzrlm` (`dateDeleted`),
  KEY `idx_agffwpijaaeozxvqudgpovuxldrftlarabcr` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `elements` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eqctpnbmoadomlnwpwrqcqajxekhfueoozof` (`sortOrder`),
  KEY `idx_wxklcrymcmiuhpdaxuxkanvkfzdaldvzpgtw` (`layoutId`),
  CONSTRAINT `fk_kufympixhqqfhrwzhmqbmmsxburpiftyjtuh` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `searchable` tinyint(1) NOT NULL DEFAULT 1,
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jpwlhmaiibmfcitqmqobgvagsfpgdbcmevcu` (`handle`,`context`),
  KEY `idx_ypbeutnczkprejdxnefbpromqwmzikgaunab` (`groupId`),
  KEY `idx_yoednidevsqvewolykebnvumklyvmehcnlnh` (`context`),
  CONSTRAINT `fk_uygqbvvsfbhyodliwkrcbqvkxiaayozmgzyh` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_skncwrwqtnfhwpecvmuqabglgmtidfvjhpco` (`name`),
  KEY `idx_carrvbszgncqtpezhqvktqvzqbfjklrgihou` (`handle`),
  KEY `idx_vxvmyppkgelkodfyylucrciucpdbrtgermek` (`fieldLayoutId`),
  KEY `idx_bkczjkbuhtfchzcdylwwzcyldwjotueskxsn` (`sortOrder`),
  CONSTRAINT `fk_pxvzprsygdliyqanxbkujtampelvdworwcia` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qjlzumkbmquepijiopcwqmysjbahbnijdfpc` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cshldkipxwonjabidefsffxjggpvtnkgsohu` (`accessToken`),
  UNIQUE KEY `idx_mebmibsdllaaymutrgzjrvgibckgxvsvrmlt` (`name`),
  KEY `fk_whkvnbnfkvispawkiyakezejgbjtavvavlum` (`schemaId`),
  CONSTRAINT `fk_whkvnbnfkvispawkiyakezejgbjtavvavlum` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT 0,
  `inProgress` tinyint(1) NOT NULL DEFAULT 0,
  `error` tinyint(1) NOT NULL DEFAULT 0,
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xsrtstpowwtazrpmecbcgopjgqcodcoozshy` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xnjiedcsiitetwxcuvwcvqqlwqqsjwujbrga` (`name`),
  KEY `idx_bdxppybwqbhtyvxctitstgbtowelhxgcjtop` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lenz_linkfield`
--

DROP TABLE IF EXISTS `lenz_linkfield`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lenz_linkfield` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `type` varchar(63) DEFAULT NULL,
  `linkedUrl` text DEFAULT NULL,
  `linkedId` int(11) DEFAULT NULL,
  `linkedSiteId` int(11) DEFAULT NULL,
  `linkedTitle` varchar(255) DEFAULT NULL,
  `payload` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_diletsdtotxzxwxbihidbngobzhrnkaqbwld` (`elementId`,`siteId`,`fieldId`),
  KEY `idx_gjvbuicaprnnhqitvfmvlyxysjnjcdszvamp` (`fieldId`),
  KEY `idx_vojmcdiomripqdujazrculkqbpyyjhdvastk` (`siteId`),
  KEY `fk_qmmolbcdghtnpzzlknrqrijxplvrtmzbmdyr` (`linkedId`),
  KEY `fk_mnbrsayjvlhtmdmhjnpkzhpstuuucgbqjtrj` (`linkedSiteId`),
  CONSTRAINT `fk_dbozokramtxtkhijolhaqfmsncaalnbapmvk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hfsatehshrycowvgijskhlaqzhhbvnedzepf` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mnbrsayjvlhtmdmhjnpkzhpstuuucgbqjtrj` FOREIGN KEY (`linkedSiteId`) REFERENCES `sites` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `fk_qmmolbcdghtnpzzlknrqrijxplvrtmzbmdyr` FOREIGN KEY (`linkedId`) REFERENCES `elements` (`id`) ON DELETE SET NULL ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `primaryOwnerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_elgxeqrwwqjezeakwvtmxlyetpyffplroqsi` (`primaryOwnerId`),
  KEY `idx_wjqekndsbwipxmbbgjrqglzsilyculmsnujq` (`fieldId`),
  KEY `idx_zoblhvvqbufxnjofwpitrtshmjsbvsbsimjr` (`typeId`),
  CONSTRAINT `fk_hakccbeysxwmkraqgkaytckajsmylrmrjuhw` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kjjpcnnpvwohjdqsmjfanatcaxhcymhsxnyu` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lpvccgwxesvzfcwywmlxlorftvwxhlobbntd` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pbtxxamicatvktsioksjmprsfvdwzddfupbj` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_xcznwtwdeogyavpmhsdqrwopslwzjykhudpa` (`ownerId`),
  CONSTRAINT `fk_lhbyoyfqoepinvtqsxikmkcmlijdmqollwld` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xcznwtwdeogyavpmhsdqrwopslwzjykhudpa` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_efdggbrkmseapqncvysbxdhgcsrqqbxmqrce` (`name`,`fieldId`),
  KEY `idx_yvttjxpuxnrzlxmmvjtokrqodiaiaddrtemi` (`handle`,`fieldId`),
  KEY `idx_mohmlqvdbdmqfoyogzyvklnyfjrgmpyxacef` (`fieldId`),
  KEY `idx_hpvnlivnxwrmjmbckfzviblygexhcpryiqfp` (`fieldLayoutId`),
  CONSTRAINT `fk_calqynrtfxnjhkmhuprkrryzuzyblnkcbuze` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ddmcssdqlyudyqjccoinrnbmmkezsblltmwh` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_contentblocks`
--

DROP TABLE IF EXISTS `matrixcontent_contentblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixcontent_contentblocks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_heading_size_fvusojty` varchar(255) DEFAULT NULL,
  `field_heading_heading_jpsldsyc` text DEFAULT NULL,
  `field_copy_richText_ncfavohf` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lijuybkzjlfofzzaoqdclnpvtakeuhifunez` (`elementId`,`siteId`),
  KEY `fk_qcpafxitkarximpqhtmovupqudqyrqamtdmt` (`siteId`),
  CONSTRAINT `fk_eybnnmrjaauuwccqapbtrtbzggwduephtvet` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qcpafxitkarximpqhtmovupqudqyrqamtdmt` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `matrixcontent_primarynavigation`
--

DROP TABLE IF EXISTS `matrixcontent_primarynavigation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixcontent_primarynavigation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kylqcmmusqegzvzbpbavabyackcekgdkjofs` (`elementId`,`siteId`),
  KEY `fk_kkdedeiblhrszqrldyrskxfqejgtjmundsde` (`siteId`),
  CONSTRAINT `fk_cmnznydqshruuunmzkubjigynzcfulokmtyh` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kkdedeiblhrszqrldyrskxfqejgtjmundsde` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_blfsecwzbzypgwkzvmfhbmnzlmwovkiggwqq` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','trial','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pcwmrefmzgtqjkmkpvpdxookouirsueynmql` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text DEFAULT NULL,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT 0,
  `priority` int(11) unsigned NOT NULL DEFAULT 1024,
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT 0,
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT 0,
  `dateFailed` datetime DEFAULT NULL,
  `error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ovumfxuxbryjvdxgiijlpcyazublgdfsrsgt` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_wajcvukvvjbigdsqvwtmgmkvmeamyxgnwuih` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hbghtoynqumziwduuejvutzjlzwcxkmeaquy` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_nkyozccdolmjahlvubjwvhxxldxlouqbpxia` (`sourceId`),
  KEY `idx_qlfmshuipxmeebulktgigdhshbowxosxdoww` (`targetId`),
  KEY `idx_mkxnmpbnniwmnjaiqmmdhzceqoraqhlnckzn` (`sourceSiteId`),
  CONSTRAINT `fk_dqsaafnipeysgvsuzedceykenijgouoaezrp` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nbajanicxepqbwqwhsmaoezhztqfgdkxmxix` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_plheuopsyvnnzxdtqlisinzpjuiwyvsfyphi` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_pqjyofyipapmbgwoeblrjuywxwwzhpciqdqa` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ysxewvphajtevdkdsfrihsbpnwvbqxztgkna` (`canonicalId`,`num`),
  KEY `fk_spvnzljmlawqqccttgdosulivtwblnppzupz` (`creatorId`),
  CONSTRAINT `fk_sbzhdlxxfzliedixneltxknlclasuyxbdiac` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_spvnzljmlawqqccttgdosulivtwblnppzupz` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_rjjlyyceoawsxywpogunvucyvuqflzzlrure` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT 0,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ausqtmydyxtxbhrmifprblbumncvfqtizhbu` (`handle`),
  KEY `idx_njagazeyjxxpqptbcpyocjzvqxnhcerwgojn` (`name`),
  KEY `idx_sqxelhkvjpenngeshodbmatdwcjpuggektme` (`structureId`),
  KEY `idx_hlwanbteswizrnogutivrwbbnlbdzjyylbtm` (`dateDeleted`),
  CONSTRAINT `fk_biwqncqibnthlzuurtexqqsfytaisiamgaob` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lkhkrugjsstqfflaljzujadsvwnzoayvlbvz` (`sectionId`,`siteId`),
  KEY `idx_shybzeocznvlujrfsntgluuzqbvpwzmigztp` (`siteId`),
  CONSTRAINT `fk_wpscgnwmjmzjpxbvyfxkdqkjgkqpkbzcxlbw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zsdhdpswyoemyotagguxvnawbzhlajjeoigz` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `seomatic_metabundles`
--

DROP TABLE IF EXISTS `seomatic_metabundles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seomatic_metabundles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `bundleVersion` varchar(255) NOT NULL DEFAULT '',
  `sourceBundleType` varchar(255) NOT NULL DEFAULT '',
  `sourceId` int(11) DEFAULT NULL,
  `sourceName` varchar(255) NOT NULL DEFAULT '',
  `sourceHandle` varchar(255) NOT NULL DEFAULT '',
  `sourceType` varchar(64) NOT NULL DEFAULT '',
  `typeId` int(11) DEFAULT NULL,
  `sourceTemplate` varchar(500) DEFAULT '',
  `sourceSiteId` int(11) DEFAULT NULL,
  `sourceAltSiteSettings` text DEFAULT NULL,
  `sourceDateUpdated` datetime NOT NULL,
  `metaGlobalVars` text DEFAULT NULL,
  `metaSiteVars` text DEFAULT NULL,
  `metaSitemapVars` text DEFAULT NULL,
  `metaContainers` text DEFAULT NULL,
  `redirectsContainer` text DEFAULT NULL,
  `frontendTemplatesContainer` text DEFAULT NULL,
  `metaBundleSettings` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ijtsldniiwsscxakjbdmufkqhtxehbhzmrms` (`sourceBundleType`),
  KEY `idx_lcadlenhkshzepbbnltbvxkwynpbcgdjcrqt` (`sourceId`),
  KEY `idx_abayirkjzhlghpbzcfsbnliefhrhrhrayczr` (`sourceSiteId`),
  KEY `idx_weshjauqlfemelxgtahedjnanklyohjcjpas` (`sourceHandle`),
  CONSTRAINT `fk_vmjdmqlmnatijvnvzvaduosgidsjdsbgtexe` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_srqrwnwlmnoyleoieuhmmsohxbguorrdgbax` (`uid`),
  KEY `idx_edodrjrymuvwtaipeyucfjndvejkuzgpjxrz` (`token`),
  KEY `idx_skarvzoxyygxwsgpucmpghvtbicrqtylpgrw` (`dateUpdated`),
  KEY `idx_viefyduxkgutausxxknxqqnjxlbbtwgrarzq` (`userId`),
  CONSTRAINT `fk_fqpdivqnzftvmkakafxkqrjncttrmrnsixtu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_smqsrrygqfczvlxbwljwejmnhszkivaahfik` (`userId`,`message`),
  CONSTRAINT `fk_jvzvbryctfzbgjixtjltipgqpzgqvrqbsyqc` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_avpzwxtinhmihgfykkavgxrpxylslvatyped` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 0,
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_btsoonabwaagfrnxmhvlnjogggullhhnggqm` (`dateDeleted`),
  KEY `idx_mftqhmqfaebucenbwnpxfwdwclpkvolgoixy` (`handle`),
  KEY `idx_nijiqeemctpziezvaaaikoijqfeshtgelnjd` (`sortOrder`),
  KEY `fk_egbwukrwjmgjuarpenyidbhqvhnefzjwqeny` (`groupId`),
  CONSTRAINT `fk_egbwukrwjmgjuarpenyidbhqvhnefzjwqeny` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stripe_customers`
--

DROP TABLE IF EXISTS `stripe_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `gatewayId` int(11) NOT NULL,
  `reference` varchar(255) NOT NULL,
  `response` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_uykakyubkwtrbjmafgzoauijruosrlajilnv` (`reference`),
  KEY `idx_rbizrymfbbxjjwdjqkvgkwtberkowrtbcfyp` (`gatewayId`),
  KEY `idx_funsikuqohodrzqocrunhxpbmuaocqibyrwl` (`userId`),
  CONSTRAINT `fk_jeocmsomwcolqiuuqzmkqykxzjicofikrajn` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vnixdjkvnbbjwmamkblxyniighlzatgbobgj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stripe_invoices`
--

DROP TABLE IF EXISTS `stripe_invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(255) DEFAULT NULL,
  `subscriptionId` int(11) NOT NULL,
  `invoiceData` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lmxyiczlkhpnmykpqgijhcygaipdfbvrriiy` (`reference`),
  KEY `idx_cggbnsknwmgjcifipbghinpkepggjkgpxpme` (`subscriptionId`),
  CONSTRAINT `fk_svbntlnskbsfveiclxgcpcsffujazsijjykq` FOREIGN KEY (`subscriptionId`) REFERENCES `commerce_subscriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stripe_paymentintents`
--

DROP TABLE IF EXISTS `stripe_paymentintents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stripe_paymentintents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reference` varchar(255) DEFAULT NULL,
  `gatewayId` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `orderId` int(11) NOT NULL,
  `transactionHash` varchar(255) NOT NULL,
  `intentData` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_haedhrhhhmjbdayybqjmghmwcuqrevkbqyus` (`orderId`,`gatewayId`,`customerId`,`transactionHash`),
  UNIQUE KEY `idx_qkjrzogpsswffqsmuggrgsfbwxwujnrnjazi` (`reference`),
  KEY `fk_rqkubwlsbhblmvhrhywuciivbjtqkbnkgslu` (`gatewayId`),
  KEY `fk_gowmywleigolkosxvsprjygazfsvjaokogvv` (`customerId`),
  CONSTRAINT `fk_gowmywleigolkosxvsprjygazfsvjaokogvv` FOREIGN KEY (`customerId`) REFERENCES `stripe_customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rqkubwlsbhblmvhrhywuciivbjtqkbnkgslu` FOREIGN KEY (`gatewayId`) REFERENCES `commerce_gateways` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zgdgxzcqhbxfqnklundgkhvsovsotlfegxhk` FOREIGN KEY (`orderId`) REFERENCES `commerce_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ulcgioouqeevbyrvjchbovcaiheonghdtynq` (`structureId`,`elementId`),
  KEY `idx_lnrwgwdfetaiqmhptvpddapreqtaayyghveq` (`root`),
  KEY `idx_zefytqttuopsjiqzzwnfldmramdhxdqrfxzg` (`lft`),
  KEY `idx_oalgoidikwkreewgjpsudgekydsobxrnjqen` (`rgt`),
  KEY `idx_dllpjozngknewialippxbuiajzeliivcbmts` (`level`),
  KEY `idx_dylicxcwpteyvfgfriprnrwusqnvggbjkdij` (`elementId`),
  CONSTRAINT `fk_cwruqwfnumqxnxryiqrbxcytqhbwildenpxc` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lnaalbharpyiqjoosiilovwcfigjzodxkapm` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zwhrxowghjyarsoctkleahmotrhkpyonpzzr` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sgznbskqoabtiwbhusbozqzvnmrlvwynanar` (`key`,`language`),
  KEY `idx_uvtuzhywpbgekmtzknznniszlcisjyypxwib` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_awioizlhrtcewlgtyjytvdbycedhoiyixrxy` (`name`),
  KEY `idx_ughnbjgxnashccbkhlassgtpztbolgkulyts` (`handle`),
  KEY `idx_lkltiprkylphmgjxmgtvnsvtbdqwhdgvvynp` (`dateDeleted`),
  KEY `fk_dbqwuakixnhujfoofmltwxsfqkizxcvujgrr` (`fieldLayoutId`),
  CONSTRAINT `fk_dbqwuakixnhujfoofmltwxsfqkizxcvujgrr` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tcmqvsmzarftyclgbqdddrbpswyzaiwzuqvh` (`groupId`),
  CONSTRAINT `fk_rusjkcbiplykeuvpwydyyrmtbglptezcfdlx` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zxxywsroubczzuukgrlmmnkfkoqetqhytksl` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text DEFAULT NULL,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vtjgrhpdwomzndpredfaupkgucrrtrgzjbuk` (`token`),
  KEY `idx_gcofsapssbjmehndwyqhsprfyofysrkikvan` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vxuxdipdtgakaplmxnfdkgfauhbanaoiryfm` (`handle`),
  KEY `idx_diurmvgxkskahotxmtdxumckslwhwwsiuleh` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nnrlllziijcswqvmxjuytccsmzluvzlkoaqa` (`groupId`,`userId`),
  KEY `idx_tqoufelsftlpcogzpznwamwbycgeirvdzwrs` (`userId`),
  CONSTRAINT `fk_kznmfyypdishlkhhcbsvjmbhqfgoqdpwloml` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mptoawbepkqbijfwfsxlhaxbwpefecjfszpg` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kkpkuwlxhmtmcbasaeipbvlzjnwgwdmbpcgb` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_btzwlqybcxhtxwyqljaktenlrpioqcfaiimg` (`permissionId`,`groupId`),
  KEY `idx_azokxfklirntubspxdvtyozbonnudaitgkzu` (`groupId`),
  CONSTRAINT `fk_okltkvrosoodnnuyxoehymevvqibpxlslyqs` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_shdejpwkrrtxurqsmpkjvvejpelafidftowf` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rugmjkpaxxxhlgurilonphaldgvtzqhlfxuz` (`permissionId`,`userId`),
  KEY `idx_esbapfmgovamjjgakqmzsjajchwcsqmagbif` (`userId`),
  CONSTRAINT `fk_fmpagkfoattlnnupeiosxeedzthtguqcrfhn` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wgrutjjkwacyhjfgeppkdmnxkldzujqgozcf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_uxlrmpukegvlabcfcctszotqlabgsqkehzig` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `pending` tinyint(1) NOT NULL DEFAULT 0,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `suspended` tinyint(1) NOT NULL DEFAULT 0,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT 0,
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT 0,
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gtcagvsduutbxgznsegclrkmwnhojiifubai` (`active`),
  KEY `idx_ckpbgszvtfjhtyuybzfxbcqivoxzakqztsqs` (`locked`),
  KEY `idx_pegxhehwvifdqfnxxfniervkuuyezezkpobo` (`pending`),
  KEY `idx_hwspbwuauvpvstrzbxqfdkevipacjzwwqnam` (`suspended`),
  KEY `idx_lttkubhjkwzkypepmbvsccdajiexegrkmtzu` (`verificationCode`),
  KEY `idx_lgiuqeihzogxqyhtsdygjmloxadcubinnrdt` (`email`),
  KEY `idx_jbjokvvysfbjxhsafdfoalprrayhqkzfmnsp` (`username`),
  KEY `fk_mtnrsovybomumwzhubalxlwrnkkjhlxgwlew` (`photoId`),
  CONSTRAINT `fk_mtnrsovybomumwzhubalxlwrnkkjhlxgwlew` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ytmvetsvqzizhzxiltaxujcvptzyvismahny` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_aljasegkbstinabdbrbdvypapxgzcoierdqm` (`name`,`parentId`,`volumeId`),
  KEY `idx_ndntqriwdrffgqnuiebnvgunsjvzdqiliqjb` (`parentId`),
  KEY `idx_rnrvaxcxwcphzezgbklfjqhdzurtbmcmrvyw` (`volumeId`),
  CONSTRAINT `fk_isteumnuypgvecrisuatpqstvhbvtzqozevz` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tmqbsrlnvcrirflgxtfqhgljyeyzeqvzdcvv` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wqrafktsvhvleqnumykmvsxrkvjqnyxfvnwq` (`name`),
  KEY `idx_iwohephcthyjzvzjarhaunwkizdyqkqehfnz` (`handle`),
  KEY `idx_fnxxpfefcbuxdisyfhcllekocrsgwneaxhfx` (`fieldLayoutId`),
  KEY `idx_wawetysdyelpwlcnwwgcvgdcbpffeqxmeeqj` (`dateDeleted`),
  CONSTRAINT `fk_trpbdudsmpanzopxwrtrheteebyrkpxmcjmp` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mgtcnvdwcorbihllyhdkidfqihkrqikvdmam` (`userId`),
  CONSTRAINT `fk_humkiblejwydhwbwhdnrbmbmatufnpaevjly` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-25 17:11:12
-- MariaDB dump 10.19  Distrib 10.5.15-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	10.3.35-MariaDB-1:10.3.35+maria~focal-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categorygroups` VALUES (1,1,6,'Product Categories','productCategories','end','2022-07-24 23:27:23','2022-07-24 23:27:23',NULL,'1b753347-9223-47d6-8349-fc1c7c290ea1');
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categorygroups_sites` VALUES (1,1,1,0,NULL,NULL,'2022-07-24 23:27:23','2022-07-24 23:27:23','07db1b93-6200-4d2d-bf3f-ed78d0244046');
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedattributes` VALUES (13,1,'slug','2022-07-25 00:40:42',0,1),(13,1,'uri','2022-07-25 00:40:42',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `changedfields` VALUES (13,1,1,'2022-07-25 00:40:42',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_coupons`
--

LOCK TABLES `commerce_coupons` WRITE;
/*!40000 ALTER TABLE `commerce_coupons` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_coupons` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_customer_discountuses`
--

LOCK TABLES `commerce_customer_discountuses` WRITE;
/*!40000 ALTER TABLE `commerce_customer_discountuses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_customer_discountuses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_customers`
--

LOCK TABLES `commerce_customers` WRITE;
/*!40000 ALTER TABLE `commerce_customers` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_customers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_discount_categories`
--

LOCK TABLES `commerce_discount_categories` WRITE;
/*!40000 ALTER TABLE `commerce_discount_categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_discount_categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_discount_purchasables`
--

LOCK TABLES `commerce_discount_purchasables` WRITE;
/*!40000 ALTER TABLE `commerce_discount_purchasables` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_discount_purchasables` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_discounts`
--

LOCK TABLES `commerce_discounts` WRITE;
/*!40000 ALTER TABLE `commerce_discounts` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_discounts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_donations`
--

LOCK TABLES `commerce_donations` WRITE;
/*!40000 ALTER TABLE `commerce_donations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_donations` VALUES (2,'DONATION-CC4',0,'2022-07-24 18:15:51','2022-07-24 18:15:51','c0f4296f-d503-4df5-a08b-d0e57165556a');
/*!40000 ALTER TABLE `commerce_donations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_email_discountuses`
--

LOCK TABLES `commerce_email_discountuses` WRITE;
/*!40000 ALTER TABLE `commerce_email_discountuses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_email_discountuses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_emails`
--

LOCK TABLES `commerce_emails` WRITE;
/*!40000 ALTER TABLE `commerce_emails` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_emails` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_gateways`
--

LOCK TABLES `commerce_gateways` WRITE;
/*!40000 ALTER TABLE `commerce_gateways` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_gateways` VALUES (1,'craft\\commerce\\gateways\\Dummy','Dummy','dummy',NULL,'purchase','1',1,'2022-07-25 17:06:35',4,'2022-07-24 18:15:51','2022-07-25 17:06:35','69d02abe-8711-4774-b44b-2da88ffb76e7'),(2,'craft\\commerce\\stripe\\gateways\\PaymentIntents','Stripe','stripe','{\"apiKey\":\"$STRIPE_SECRET_KEY\",\"publishableKey\":\"$STRIPE_PUB_KEY\",\"sendReceiptEmail\":\"$STRIPE_SEND_EMAIL\",\"signingSecret\":\"$STRIPE_WEBHOOK_SECRET\"}','purchase','$STRIPE_ENABLED',0,NULL,1,'2022-07-25 15:52:15','2022-07-25 16:45:07','6cbc0418-8b1f-411b-aa21-4937acf9bc1a'),(3,'craft\\commerce\\paypalcheckout\\gateways\\Gateway','PayPal','paypal','{\"_brandName\":\"$PAYPAL_BRAND\",\"brandName\":\"$PAYPAL_BRAND\",\"clientId\":\"$PAYPAL_CLIENT_ID\",\"landingPage\":\"BILLING\",\"secret\":\"$PAYPAL_SECRET\",\"sendCartInfo\":\"$PAYPAL_SEND_CART_INFO\",\"sendShippingInfo\":\"$PAYPAL_SEND_SHIIPING_INFO\",\"testMode\":\"$PAYPAL_TEST_MODE\"}','purchase','$PAYPAL_ENABLED',0,NULL,2,'2022-07-25 16:56:20','2022-07-25 16:56:25','56fd568a-e1bd-46d2-af2f-8a5b610e47bf'),(4,'craft\\commerce\\gateways\\Manual','Manual','manual','{\"onlyAllowForZeroPriceOrders\":true}','authorize','$MANUAL_ENABLED',0,NULL,3,'2022-07-25 17:04:51','2022-07-25 17:04:56','148bf625-3ed8-48e1-9a43-70fc218ce67c');
/*!40000 ALTER TABLE `commerce_gateways` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_lineitems`
--

LOCK TABLES `commerce_lineitems` WRITE;
/*!40000 ALTER TABLE `commerce_lineitems` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_lineitems` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_lineitemstatuses`
--

LOCK TABLES `commerce_lineitemstatuses` WRITE;
/*!40000 ALTER TABLE `commerce_lineitemstatuses` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_lineitemstatuses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_orderadjustments`
--

LOCK TABLES `commerce_orderadjustments` WRITE;
/*!40000 ALTER TABLE `commerce_orderadjustments` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_orderadjustments` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_orderhistories`
--

LOCK TABLES `commerce_orderhistories` WRITE;
/*!40000 ALTER TABLE `commerce_orderhistories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_orderhistories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_ordernotices`
--

LOCK TABLES `commerce_ordernotices` WRITE;
/*!40000 ALTER TABLE `commerce_ordernotices` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_ordernotices` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_orders`
--

LOCK TABLES `commerce_orders` WRITE;
/*!40000 ALTER TABLE `commerce_orders` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_orders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_orderstatus_emails`
--

LOCK TABLES `commerce_orderstatus_emails` WRITE;
/*!40000 ALTER TABLE `commerce_orderstatus_emails` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_orderstatus_emails` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_orderstatuses`
--

LOCK TABLES `commerce_orderstatuses` WRITE;
/*!40000 ALTER TABLE `commerce_orderstatuses` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_orderstatuses` VALUES (1,'New','new','green',NULL,NULL,99,1,'2022-07-24 18:15:51','2022-07-24 18:15:51','e4b25d4c-f8ee-4d1b-a77c-2e70560cb1d0');
/*!40000 ALTER TABLE `commerce_orderstatuses` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_paymentcurrencies`
--

LOCK TABLES `commerce_paymentcurrencies` WRITE;
/*!40000 ALTER TABLE `commerce_paymentcurrencies` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_paymentcurrencies` VALUES (1,'USD',1,1.0000,'2022-07-24 18:15:51','2022-07-24 18:15:51','6faae02c-e1e7-45d0-85db-4174bd998389');
/*!40000 ALTER TABLE `commerce_paymentcurrencies` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_paymentsources`
--

LOCK TABLES `commerce_paymentsources` WRITE;
/*!40000 ALTER TABLE `commerce_paymentsources` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_paymentsources` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_pdfs`
--

LOCK TABLES `commerce_pdfs` WRITE;
/*!40000 ALTER TABLE `commerce_pdfs` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_pdfs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_plans`
--

LOCK TABLES `commerce_plans` WRITE;
/*!40000 ALTER TABLE `commerce_plans` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_plans` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_products`
--

LOCK TABLES `commerce_products` WRITE;
/*!40000 ALTER TABLE `commerce_products` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_products` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_producttypes`
--

LOCK TABLES `commerce_producttypes` WRITE;
/*!40000 ALTER TABLE `commerce_producttypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_producttypes` VALUES (1,12,13,'Catalog','catalog',1,1,0,'{product.title} - {color} - {size}',1,'','CAT-{product.slug|upper}-{color|upper}-{size|upper}','{product.title} - {color} - {size}','2022-07-24 23:54:57','2022-07-24 23:54:57','8f9a9f81-cbc4-41eb-a70b-5eaeadea8840');
/*!40000 ALTER TABLE `commerce_producttypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_producttypes_shippingcategories`
--

LOCK TABLES `commerce_producttypes_shippingcategories` WRITE;
/*!40000 ALTER TABLE `commerce_producttypes_shippingcategories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_producttypes_shippingcategories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_producttypes_sites`
--

LOCK TABLES `commerce_producttypes_sites` WRITE;
/*!40000 ALTER TABLE `commerce_producttypes_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_producttypes_sites` VALUES (1,1,1,'{{alias(\"@nuxtBaseUrl\")}}/catalog/{slug}','index',1,'2022-07-24 23:54:57','2022-07-24 23:54:57','86309b48-002b-4c30-95c1-5bc9e1df086e');
/*!40000 ALTER TABLE `commerce_producttypes_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_producttypes_taxcategories`
--

LOCK TABLES `commerce_producttypes_taxcategories` WRITE;
/*!40000 ALTER TABLE `commerce_producttypes_taxcategories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_producttypes_taxcategories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_purchasables`
--

LOCK TABLES `commerce_purchasables` WRITE;
/*!40000 ALTER TABLE `commerce_purchasables` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_purchasables` VALUES (2,'DONATION-CC4',0.0000,'Donation','2022-07-24 18:15:51','2022-07-24 18:15:51','3267af62-a54a-4344-b5bf-0db45be1644e');
/*!40000 ALTER TABLE `commerce_purchasables` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_sale_categories`
--

LOCK TABLES `commerce_sale_categories` WRITE;
/*!40000 ALTER TABLE `commerce_sale_categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_sale_categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_sale_purchasables`
--

LOCK TABLES `commerce_sale_purchasables` WRITE;
/*!40000 ALTER TABLE `commerce_sale_purchasables` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_sale_purchasables` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_sale_usergroups`
--

LOCK TABLES `commerce_sale_usergroups` WRITE;
/*!40000 ALTER TABLE `commerce_sale_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_sale_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_sales`
--

LOCK TABLES `commerce_sales` WRITE;
/*!40000 ALTER TABLE `commerce_sales` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_sales` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_shippingcategories`
--

LOCK TABLES `commerce_shippingcategories` WRITE;
/*!40000 ALTER TABLE `commerce_shippingcategories` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_shippingcategories` VALUES (1,'General','general',NULL,1,'2022-07-24 18:15:51','2022-07-24 18:15:51','2614a500-289d-4207-9227-930f9d359533');
/*!40000 ALTER TABLE `commerce_shippingcategories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_shippingmethods`
--

LOCK TABLES `commerce_shippingmethods` WRITE;
/*!40000 ALTER TABLE `commerce_shippingmethods` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_shippingmethods` VALUES (1,'Free Shipping','freeShipping',1,0,'2022-07-24 18:15:51','2022-07-24 18:15:51','a9064f3c-7104-4100-b26b-dfec17d76d4d');
/*!40000 ALTER TABLE `commerce_shippingmethods` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_shippingrule_categories`
--

LOCK TABLES `commerce_shippingrule_categories` WRITE;
/*!40000 ALTER TABLE `commerce_shippingrule_categories` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_shippingrule_categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_shippingrules`
--

LOCK TABLES `commerce_shippingrules` WRITE;
/*!40000 ALTER TABLE `commerce_shippingrules` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_shippingrules` VALUES (1,NULL,1,'Free Everywhere','All countries, free shipping',0,1,NULL,0,0,0.0000,0.0000,'salePrice',0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0,'2022-07-24 18:15:51','2022-07-24 18:15:51','95c7bef6-771e-482d-9691-01ff45ff4373');
/*!40000 ALTER TABLE `commerce_shippingrules` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_shippingzones`
--

LOCK TABLES `commerce_shippingzones` WRITE;
/*!40000 ALTER TABLE `commerce_shippingzones` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_shippingzones` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_stores`
--

LOCK TABLES `commerce_stores` WRITE;
/*!40000 ALTER TABLE `commerce_stores` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_stores` VALUES (1,NULL,'[\"US\"]',NULL,'2022-07-24 18:15:51','2022-07-24 18:15:51','e99be706-c99c-42fa-adc2-ff9c9c707a1b');
/*!40000 ALTER TABLE `commerce_stores` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_subscriptions`
--

LOCK TABLES `commerce_subscriptions` WRITE;
/*!40000 ALTER TABLE `commerce_subscriptions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_taxcategories`
--

LOCK TABLES `commerce_taxcategories` WRITE;
/*!40000 ALTER TABLE `commerce_taxcategories` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `commerce_taxcategories` VALUES (1,'General','general',NULL,1,'2022-07-24 18:15:51','2022-07-24 18:15:51','99000dff-67f1-4eb8-95ba-5bd36cf1082c');
/*!40000 ALTER TABLE `commerce_taxcategories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_taxrates`
--

LOCK TABLES `commerce_taxrates` WRITE;
/*!40000 ALTER TABLE `commerce_taxrates` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_taxrates` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_taxzones`
--

LOCK TABLES `commerce_taxzones` WRITE;
/*!40000 ALTER TABLE `commerce_taxzones` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_taxzones` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_transactions`
--

LOCK TABLES `commerce_transactions` WRITE;
/*!40000 ALTER TABLE `commerce_transactions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_transactions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `commerce_variants`
--

LOCK TABLES `commerce_variants` WRITE;
/*!40000 ALTER TABLE `commerce_variants` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `commerce_variants` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `content` VALUES (1,1,1,NULL,'2022-07-24 18:09:58','2022-07-24 18:09:58','e5bf1ec1-79a9-4c2f-8570-4dfe2801fa23',NULL,NULL,NULL,NULL,NULL,NULL),(2,3,1,'Home','2022-07-24 23:29:19','2022-07-25 00:24:17','3621dd46-53bb-4ff2-abe6-e58aa1845540',NULL,NULL,NULL,NULL,NULL,NULL),(3,4,1,'Home','2022-07-24 23:29:19','2022-07-24 23:29:19','9448559e-0cf3-4411-84fe-e459a9f71343',NULL,NULL,NULL,NULL,NULL,NULL),(4,5,1,'Home','2022-07-24 23:29:19','2022-07-24 23:29:19','6c509230-44d6-4bb4-b952-4dbf03fc8680',NULL,NULL,NULL,NULL,NULL,NULL),(5,6,1,'Home','2022-07-24 23:30:35','2022-07-24 23:30:35','ed741487-ed23-4a41-87a0-69b2efea313b',NULL,NULL,NULL,NULL,NULL,NULL),(6,7,1,'Settings','2022-07-24 23:31:19','2022-07-24 23:40:26','f4d62f0d-f08f-4b03-af49-15bcac58e03c',NULL,NULL,NULL,NULL,NULL,NULL),(7,8,1,'Settings','2022-07-24 23:31:19','2022-07-24 23:31:19','8ebdf6b7-e171-4175-a767-990ad2f4bbae',NULL,NULL,NULL,NULL,NULL,NULL),(8,9,1,'Settings','2022-07-24 23:31:19','2022-07-24 23:31:19','74e8f814-118b-4642-aa39-799f6dc92a98',NULL,NULL,NULL,NULL,NULL,NULL),(9,10,1,'Settings','2022-07-24 23:40:26','2022-07-24 23:40:26','b032f7f2-e6b7-4fb6-80da-580f3d9a4fa8',NULL,NULL,NULL,NULL,NULL,NULL),(10,11,1,'Home','2022-07-24 23:58:00','2022-07-24 23:58:00','8d411444-91a9-408a-80cf-6d465e482557',NULL,NULL,NULL,NULL,NULL,NULL),(11,12,1,'Home','2022-07-25 00:24:17','2022-07-25 00:24:17','da707775-5d96-4508-a9bc-4b1c8841bb24',NULL,NULL,NULL,NULL,NULL,NULL),(12,13,1,NULL,'2022-07-25 00:40:24','2022-07-25 00:40:42','19c532c2-db4e-4937-8aa9-475523a15e8c',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `drafts` VALUES (1,NULL,1,0,'First draft','',0,NULL,1);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2022-07-24 18:09:58','2022-07-24 18:09:58',NULL,NULL,'c5efc630-2c04-449c-b7cb-c176afc61cf1'),(2,NULL,NULL,NULL,NULL,'craft\\commerce\\elements\\Donation',1,0,'2022-07-24 18:15:51','2022-07-24 18:15:51',NULL,NULL,'e621fd6e-16ce-470a-adf5-aab617c0951d'),(3,NULL,NULL,NULL,7,'craft\\elements\\Entry',1,0,'2022-07-24 23:29:19','2022-07-25 00:24:17',NULL,NULL,'cb17638c-b2b8-4362-92fb-57b1fb0d6900'),(4,3,NULL,1,7,'craft\\elements\\Entry',1,0,'2022-07-24 23:29:19','2022-07-24 23:29:19',NULL,NULL,'4008cfd9-b23c-45d5-b2e5-ec2bd20fb2bc'),(5,3,NULL,2,7,'craft\\elements\\Entry',1,0,'2022-07-24 23:29:19','2022-07-24 23:29:19',NULL,NULL,'710f3e59-710f-464a-bdbe-0f68aeeaf4d9'),(6,3,NULL,3,7,'craft\\elements\\Entry',1,0,'2022-07-24 23:30:35','2022-07-24 23:30:35',NULL,NULL,'13d2e5d7-c2fc-48d6-9026-72eac75ea83b'),(7,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2022-07-24 23:31:19','2022-07-24 23:40:26',NULL,NULL,'020a55ee-fb0a-4b17-b45b-eb28a9f97dc4'),(8,7,NULL,4,8,'craft\\elements\\Entry',1,0,'2022-07-24 23:31:19','2022-07-24 23:31:19',NULL,NULL,'855e0217-c619-44dc-b9be-ca85995c9f55'),(9,7,NULL,5,8,'craft\\elements\\Entry',1,0,'2022-07-24 23:31:19','2022-07-24 23:31:19',NULL,NULL,'fd1154c8-1b78-4bdc-9f73-0891d0a8f048'),(10,7,NULL,6,8,'craft\\elements\\Entry',1,0,'2022-07-24 23:40:26','2022-07-24 23:40:26',NULL,NULL,'9f9dd1d9-3d9d-4325-b93d-a26a3d40bc5c'),(11,3,NULL,7,7,'craft\\elements\\Entry',1,0,'2022-07-24 23:58:00','2022-07-24 23:58:00',NULL,NULL,'4db9e858-8e55-4249-b897-a010989b3bdc'),(12,3,NULL,8,7,'craft\\elements\\Entry',1,0,'2022-07-25 00:24:17','2022-07-25 00:24:17',NULL,NULL,'3285800f-bf02-4565-8b06-2fb016cda88d'),(13,NULL,1,NULL,10,'craft\\elements\\Entry',1,0,'2022-07-25 00:40:24','2022-07-25 00:40:42',NULL,'2022-07-25 00:40:50','4e2210ed-7747-4835-872c-19444cac8d53'),(14,NULL,NULL,NULL,4,'craft\\elements\\MatrixBlock',1,0,'2022-07-25 00:40:36','2022-07-25 00:40:36',NULL,'2022-07-25 00:40:42','398fb7f6-abd3-4ed9-8dbe-9d7233bdc3cc');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2022-07-24 18:09:58','2022-07-24 18:09:58','1c72ccd3-a9e3-47e9-850c-32ad1a6b2f4a'),(2,2,1,NULL,NULL,1,'2022-07-24 18:15:51','2022-07-24 18:15:51','7f33f4bb-a749-466a-8ffe-7e978576782c'),(3,3,1,'home','__home__',1,'2022-07-24 23:29:19','2022-07-24 23:29:19','ad5d1a3e-9060-44db-8cfe-7fedf094911f'),(4,4,1,'home','__home__',1,'2022-07-24 23:29:19','2022-07-24 23:29:19','8a96e1e7-0820-4208-9170-e1b9d8140a64'),(5,5,1,'home','__home__',1,'2022-07-24 23:29:19','2022-07-24 23:29:19','9aad9a6a-d473-4574-bd95-fde0e0d4732f'),(6,6,1,'home','__home__',1,'2022-07-24 23:30:35','2022-07-24 23:30:35','5079c322-ec00-4d9f-ac26-07778560cffe'),(7,7,1,'settings','settings',1,'2022-07-24 23:31:19','2022-07-24 23:31:19','c6cc8595-4b0e-4cd7-a178-952608466be4'),(8,8,1,'settings','settings',1,'2022-07-24 23:31:19','2022-07-24 23:31:19','09055a72-22a2-4346-acd9-5bd10e93b9f4'),(9,9,1,'settings','settings',1,'2022-07-24 23:31:19','2022-07-24 23:31:19','0506a416-6e5c-447e-bbec-3d72fbb48d01'),(10,10,1,'settings','settings',1,'2022-07-24 23:40:26','2022-07-24 23:40:26','8ec7a189-7e08-4405-95b3-890b5524838e'),(11,11,1,'home','__home__',1,'2022-07-24 23:58:00','2022-07-24 23:58:00','385f5a87-1637-4838-88d3-26110f1d67f3'),(12,12,1,'home','__home__',1,'2022-07-25 00:24:17','2022-07-25 00:24:17','ed4d82ea-7cc8-4c87-bba7-0ca178741a2e'),(13,13,1,'__temp_juvedvvcthrrrumnacemnfxsakdmptmsinlk','__temp_juvedvvcthrrrumnacemnfxsakdmptmsinlk',1,'2022-07-25 00:40:24','2022-07-25 00:40:42','98b0a81e-19cf-4845-b0ac-a3e25f416f7a'),(14,14,1,NULL,NULL,1,'2022-07-25 00:40:36','2022-07-25 00:40:36','723d5bbe-adc8-4d2a-b381-7128cd28fecc');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entries` VALUES (3,1,NULL,1,NULL,'2022-07-24 23:29:00',NULL,NULL,'2022-07-24 23:29:19','2022-07-24 23:29:19'),(4,1,NULL,1,NULL,'2022-07-24 23:29:00',NULL,NULL,'2022-07-24 23:29:19','2022-07-24 23:29:19'),(5,1,NULL,1,NULL,'2022-07-24 23:29:00',NULL,NULL,'2022-07-24 23:29:19','2022-07-24 23:29:19'),(6,1,NULL,1,NULL,'2022-07-24 23:29:00',NULL,NULL,'2022-07-24 23:30:35','2022-07-24 23:30:35'),(7,2,NULL,2,NULL,'2022-07-24 23:31:00',NULL,NULL,'2022-07-24 23:31:19','2022-07-24 23:31:19'),(8,2,NULL,2,NULL,'2022-07-24 23:31:00',NULL,NULL,'2022-07-24 23:31:19','2022-07-24 23:31:19'),(9,2,NULL,2,NULL,'2022-07-24 23:31:00',NULL,NULL,'2022-07-24 23:31:19','2022-07-24 23:31:19'),(10,2,NULL,2,NULL,'2022-07-24 23:31:00',NULL,NULL,'2022-07-24 23:40:26','2022-07-24 23:40:26'),(11,1,NULL,1,NULL,'2022-07-24 23:29:00',NULL,NULL,'2022-07-24 23:58:00','2022-07-24 23:58:00'),(12,1,NULL,1,NULL,'2022-07-24 23:29:00',NULL,NULL,'2022-07-25 00:24:17','2022-07-25 00:24:17'),(13,3,NULL,3,1,'2022-07-25 00:40:24',NULL,0,'2022-07-25 00:40:24','2022-07-25 00:40:24');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `entrytypes` VALUES (1,1,7,'Home','home',0,'site',NULL,'{section.name|raw}',1,'2022-07-24 23:29:19','2022-07-24 23:29:19',NULL,'d3951874-9e5b-4586-979e-c7e9c5b08d92'),(2,2,8,'Settings','settings',0,'site',NULL,'{section.name|raw}',1,'2022-07-24 23:31:19','2022-07-24 23:31:19',NULL,'05440641-857c-492e-bbb9-37ff03c88963'),(3,3,10,'General','general',1,'site',NULL,NULL,1,'2022-07-24 23:36:04','2022-07-24 23:36:52',NULL,'6e4128ef-78da-40a5-aca7-b52de59fbc3c'),(4,3,11,'Catalog','catalog',1,'site',NULL,NULL,2,'2022-07-24 23:38:31','2022-07-24 23:38:31',NULL,'4188fa88-45c2-4d45-bc06-3a135bab0725');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldgroups` VALUES (1,'Common','2022-07-24 18:09:58','2022-07-24 18:09:58','2022-07-24 23:17:26','83518c86-e1ee-4f0b-94c9-2611416da0a4'),(2,'Assets','2022-07-24 23:16:31','2022-07-24 23:16:31',NULL,'1bd188af-6bf7-4544-9e2e-f5e4052cefd1'),(3,'Text','2022-07-24 23:16:45','2022-07-24 23:16:45',NULL,'1b39f5a2-15c0-4af0-be7c-0735aba76665'),(4,'Options','2022-07-24 23:16:52','2022-07-24 23:16:52',NULL,'e0684c4e-4db6-49fe-b178-60bbc3750374'),(5,'Compound','2022-07-24 23:17:04','2022-07-24 23:17:04',NULL,'dee4f4f1-d8b0-4f5c-a6ff-b5f10e5a577f'),(6,'Relations','2022-07-24 23:17:18','2022-07-24 23:17:18',NULL,'652c2871-27c1-4b30-8190-0a05255eb19b'),(7,'Other','2022-07-24 23:17:36','2022-07-24 23:17:36',NULL,'81d425d5-6a7f-4da9-b64d-3752b8286594'),(8,'Product Categories','2022-07-24 23:27:41','2022-07-24 23:27:41','2022-07-24 23:27:47','95763f24-196b-45bf-9f08-6fe29baff23a');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayoutfields` VALUES (1,3,2,3,1,0,'2022-07-24 23:21:11','2022-07-24 23:21:11','c6eaf843-03ae-46e2-a4e0-83571d12c8d3'),(2,3,2,2,0,1,'2022-07-24 23:21:11','2022-07-24 23:21:11','e5287935-9861-4108-9d9e-08e276075fba'),(12,9,13,11,1,0,'2022-07-24 23:39:35','2022-07-24 23:39:35','28eee3bc-2312-4232-8aa8-841af68d26b6'),(13,8,14,10,0,1,'2022-07-24 23:40:26','2022-07-24 23:40:26','bccf8770-f003-4774-b1b3-8d83c926fedd'),(61,7,39,7,1,1,'2022-07-25 00:24:17','2022-07-25 00:24:17','81fceea9-1efd-4ead-bc3b-6863e3b53e3f'),(62,7,39,6,1,2,'2022-07-25 00:24:17','2022-07-25 00:24:17','608b5582-1f20-48c2-bcf4-6a46031262d6'),(63,7,39,1,1,3,'2022-07-25 00:24:17','2022-07-25 00:24:17','3e8ea206-c308-44d6-8ce9-02644c6f82af'),(64,7,40,12,1,0,'2022-07-25 00:24:17','2022-07-25 00:24:17','320e37e1-737a-4f7c-9c59-114ff7ea2b0c'),(65,7,40,17,0,1,'2022-07-25 00:24:17','2022-07-25 00:24:17','890192c0-d87f-49e5-aadc-c2f6bdb87815'),(66,7,40,13,0,2,'2022-07-25 00:24:17','2022-07-25 00:24:17','bf25148b-fcc8-4798-8728-fc7272607485'),(67,10,41,6,1,1,'2022-07-25 00:24:29','2022-07-25 00:24:29','156ff466-9db9-4a3f-9ebd-b22dc7612ac1'),(68,10,41,1,1,2,'2022-07-25 00:24:29','2022-07-25 00:24:29','d9d2425d-a717-4bb7-97f4-1fbd6a853fc3'),(69,10,42,12,1,0,'2022-07-25 00:24:29','2022-07-25 00:24:29','b9fcfafd-7266-4a8d-abd1-9484391b78c7'),(70,10,42,17,0,1,'2022-07-25 00:24:29','2022-07-25 00:24:29','a003db22-9a95-49b7-883f-e79632f981d0'),(71,10,42,13,0,2,'2022-07-25 00:24:29','2022-07-25 00:24:29','92611068-5045-456c-9d75-f42891038f25'),(72,11,43,6,1,1,'2022-07-25 00:24:38','2022-07-25 00:24:38','17e1a082-e42b-49aa-9721-8f0a66098512'),(73,11,43,9,0,2,'2022-07-25 00:24:38','2022-07-25 00:24:38','44c15d70-c184-498e-a512-2fc511fb9b7c'),(74,11,43,8,0,3,'2022-07-25 00:24:38','2022-07-25 00:24:38','fd9222c1-82de-429c-a417-35d356d07f27'),(75,11,44,12,1,0,'2022-07-25 00:24:38','2022-07-25 00:24:38','914f0dd3-c099-4458-bbd8-bc093b183620'),(76,11,44,17,0,1,'2022-07-25 00:24:38','2022-07-25 00:24:38','75dd6259-869b-4ba4-b449-d578677ba529'),(77,11,44,13,0,2,'2022-07-25 00:24:38','2022-07-25 00:24:38','fefea48e-7aed-41fe-91d7-72acc741f452'),(78,12,45,1,1,1,'2022-07-25 00:29:09','2022-07-25 00:29:09','edf0eb8f-d5a2-4eb5-97e4-e4d7b124819d'),(79,12,45,9,0,2,'2022-07-25 00:29:09','2022-07-25 00:29:09','9dfc3b05-c7cf-49bb-bf75-67ef765d726c'),(80,12,47,12,1,0,'2022-07-25 00:29:09','2022-07-25 00:29:09','aa95668e-efa7-4739-b3f5-0aa8fd2f256d'),(81,12,47,17,0,1,'2022-07-25 00:29:09','2022-07-25 00:29:09','63fc179a-7041-4e6d-be52-6841a4d3be3f'),(82,12,47,13,0,2,'2022-07-25 00:29:09','2022-07-25 00:29:09','1aabb4ad-e7a6-4c15-b980-a467b97ec2a6'),(83,13,48,6,1,1,'2022-07-25 00:29:09','2022-07-25 00:29:09','6db914dc-5945-4055-a589-c60410a78fb0'),(84,13,48,16,0,2,'2022-07-25 00:29:09','2022-07-25 00:29:09','2cef91b1-08df-454e-bbc2-f156fce8d706'),(85,13,48,15,0,3,'2022-07-25 00:29:09','2022-07-25 00:29:09','77531259-8a56-4dae-b25e-dd16db9363c2'),(86,13,48,14,0,4,'2022-07-25 00:29:09','2022-07-25 00:29:09','21c48a34-b452-497e-bb1a-56e31d300be2'),(87,4,49,4,1,0,'2022-07-25 00:40:18','2022-07-25 00:40:18','a1bc4f09-2ec4-486f-8508-590830d223a6'),(88,5,50,5,1,0,'2022-07-25 00:40:18','2022-07-25 00:40:18','5d2a7f46-c437-4ca6-be0d-4e87dd2539a4');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\commerce\\elements\\Order','2022-07-24 18:15:51','2022-07-24 18:15:51',NULL,'62fa84f5-af72-415d-bf1f-43487697e0d9'),(2,'craft\\elements\\Asset','2022-07-24 23:15:57','2022-07-24 23:15:57',NULL,'f0fd58c3-d239-4f1f-87cd-2631a1628cc5'),(3,'craft\\elements\\MatrixBlock','2022-07-24 23:21:11','2022-07-24 23:21:11',NULL,'19876a42-8f75-46f4-b62e-86c95491f049'),(4,'craft\\elements\\MatrixBlock','2022-07-24 23:21:11','2022-07-24 23:21:11',NULL,'20355f91-50e8-423b-84d3-ee3698bd450c'),(5,'craft\\elements\\MatrixBlock','2022-07-24 23:21:11','2022-07-24 23:21:11',NULL,'7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0'),(6,'craft\\elements\\Category','2022-07-24 23:27:23','2022-07-24 23:27:23',NULL,'4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2'),(7,'craft\\elements\\Entry','2022-07-24 23:29:19','2022-07-24 23:29:19',NULL,'c93dbc56-7a4d-4ddc-a134-160207914d32'),(8,'craft\\elements\\Entry','2022-07-24 23:31:19','2022-07-24 23:31:19',NULL,'f820c502-38c3-4639-8fca-dcd920d95009'),(9,'craft\\elements\\MatrixBlock','2022-07-24 23:33:37','2022-07-24 23:33:37',NULL,'f730a51b-08c5-4ffa-bff5-bd529d8fc9ba'),(10,'craft\\elements\\Entry','2022-07-24 23:36:04','2022-07-24 23:36:04',NULL,'53c7d4af-a5bf-4822-9517-81a0f29980ba'),(11,'craft\\elements\\Entry','2022-07-24 23:38:31','2022-07-24 23:38:31',NULL,'0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895'),(12,'craft\\commerce\\elements\\Product','2022-07-24 23:54:57','2022-07-24 23:54:57',NULL,'1a024e00-ff0e-4a6c-b2d5-e79329391f82'),(13,'craft\\commerce\\elements\\Variant','2022-07-24 23:54:57','2022-07-24 23:54:57',NULL,'0ee86279-568d-443a-af9d-f1e1a8cb86e9');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fieldlayouttabs` VALUES (1,2,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"1085b130-4ba3-48cc-956c-a4447af07c34\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\",\"attribute\":\"alt\",\"requirable\":true,\"class\":null,\"rows\":null,\"cols\":null,\"name\":null,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"19c17c4c-17c8-4f33-b7c7-26c197fb36f0\",\"userCondition\":null,\"elementCondition\":null}]',1,'2022-07-24 23:15:57','2022-07-24 23:15:57','abce75a7-89ae-4212-847b-4d5b7e806f8e'),(2,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"61f8c76a-d464-43be-8fa2-d2a8fe972a32\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"0491950d-ac35-4f01-a408-29e979b6dd19\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"4501929b-c21d-42cb-a2ea-485a3e9f420f\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"4dc80b48-acd0-45f5-abdd-abe4eadce58e\"}]',1,'2022-07-24 23:21:11','2022-07-24 23:21:11','b624725d-3e5e-491d-ace5-93db86a470bb'),(5,6,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\TitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"40cd8982-a8ef-4dda-955a-067f9fc8727d\",\"userCondition\":null,\"elementCondition\":null}]',1,'2022-07-24 23:27:23','2022-07-24 23:27:23','41c288bf-41f9-4a0c-95c3-3ef3c78051e6'),(13,9,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"4ca86130-56e3-4bfe-8d4a-bcd97639809f\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"8151dd06-ae31-4c45-bd7e-47e7adbafd1b\"}]',1,'2022-07-24 23:39:35','2022-07-24 23:39:35','476e1b40-d827-4c76-bb56-62f49f22a58d'),(14,8,'Navigation','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"30bf0f48-8080-445d-adda-e3d099aed548\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"73baeb77-970b-40f9-a685-dc722d0e7e02\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"df62c394-9de1-4e87-baf3-56bc70321894\"}]',1,'2022-07-24 23:40:26','2022-07-24 23:40:26','75547dbd-df26-44f0-8485-b1e676a3ac0f'),(39,7,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"3ca2d446-1add-4557-9caf-3e8a919ccad3\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"f36b2228-116b-49e0-a5d5-fde5a22d3301\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"0f2c6c9a-3092-47f2-b0dc-46d8ce11c178\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":\"Hero Image\",\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"1708239f-de70-450f-a7dd-9e7844dbf30f\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"9c475876-3670-4452-82c1-8274c5cbccb2\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"33f8fa6d-4279-40bb-b3bf-19d44b6b7c63\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"8aa229ec-7643-48c3-947d-9d2c1882b8f2\"}]',1,'2022-07-25 00:24:17','2022-07-25 00:24:17','e3263060-a5e9-45bf-b644-6f1bbce344fa'),(40,7,'SEO / Meta','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"9d975506-3005-454c-8bcc-8b1151b8c502\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"66830969-da65-4137-bbfa-98dd011cc191\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"8cb1c451-7de4-4b6b-90a6-aa245a513964\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a9b1834c-4af7-44b5-81de-00dc035a0515\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"10d57449-d562-4c41-92a7-7ba42c8933e6\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"7434a2d9-23f7-4206-84fa-f1bbad8be64f\"}]',2,'2022-07-25 00:24:17','2022-07-25 00:24:17','6b9ebed3-fae2-4cd7-806e-a10771ba1c18'),(41,10,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"1472c9af-3363-485c-9f41-2f1c21209c5b\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":\"Header Image\",\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"425aec96-ba05-4025-9325-41732ea1f997\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"9c475876-3670-4452-82c1-8274c5cbccb2\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"cf0c479d-8227-411e-9cbe-d9314c6ebdf4\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"8aa229ec-7643-48c3-947d-9d2c1882b8f2\"}]',1,'2022-07-25 00:24:29','2022-07-25 00:24:29','a1b753b4-a531-4e4c-9e1b-71112e9bca04'),(42,10,'SEO / Meta','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"f8863841-3fca-426e-b4d5-3a96084aedf8\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"66830969-da65-4137-bbfa-98dd011cc191\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"e52d8bb2-52c7-41e9-9d01-136b9d0dda44\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a9b1834c-4af7-44b5-81de-00dc035a0515\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"4da59ace-4bee-4cdb-a521-c3a58d784648\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"7434a2d9-23f7-4206-84fa-f1bbad8be64f\"}]',2,'2022-07-25 00:24:29','2022-07-25 00:24:29','64590c52-2dfe-4bd1-8b39-fcc47c2f7de1'),(43,11,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"2d0e6902-d08d-436c-82e8-1b8df7066cfc\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":\"Header Image\",\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"b6f9f139-e19b-4454-9476-063f84469fc7\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"9c475876-3670-4452-82c1-8274c5cbccb2\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":\"Select the categories to filter products on. Leave blank to display all products.\",\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"328d1728-d526-4382-8723-9bc750ae21a8\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"d7d54391-72ab-425b-87f9-d3b982cbd69d\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"86b9dbfc-2109-4d31-9418-c366dd4d69af\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"7a24de90-6ecf-4386-b258-7e1b8d1671f4\"}]',1,'2022-07-25 00:24:38','2022-07-25 00:24:38','3e4c41a3-bbf6-4f97-9c10-fd08d7aedcb3'),(44,11,'SEO / Meta','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"23437dae-9e55-4025-a6d0-5096b45c46e2\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"66830969-da65-4137-bbfa-98dd011cc191\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"d0f2f8bf-0d0a-452e-b953-fba8572170a8\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a9b1834c-4af7-44b5-81de-00dc035a0515\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"820865c3-fb9a-4131-b7fa-6eaa0e7604d0\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"7434a2d9-23f7-4206-84fa-f1bbad8be64f\"}]',2,'2022-07-25 00:24:38','2022-07-25 00:24:38','37118b48-517e-4af2-86ef-7d920d7dcaad'),(45,12,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\commerce\\\\fieldlayoutelements\\\\ProductTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"12acf916-d888-4aff-b737-5c040721aec9\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":\"Product Description\",\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"a05937a7-1bf9-4e33-aab5-df8afe43e945\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"8aa229ec-7643-48c3-947d-9d2c1882b8f2\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"30f49bec-4c8e-4a27-b40f-6d1bd42aba1d\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"d7d54391-72ab-425b-87f9-d3b982cbd69d\"}]',1,'2022-07-25 00:29:09','2022-07-25 00:29:09','3307efff-7105-4e42-8af0-d5f88b786d27'),(46,12,'Variants','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\commerce\\\\fieldlayoutelements\\\\VariantsField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"uid\":\"7224ab79-9dec-46cf-b989-f684f7bad0f6\",\"userCondition\":null,\"elementCondition\":null}]',2,'2022-07-25 00:29:09','2022-07-25 00:29:09','7e00adcb-cf38-4694-a2c1-074c45b36314'),(47,12,'SEO / Meta','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"c75f272d-2f1e-4452-85b7-b620bee1785d\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"66830969-da65-4137-bbfa-98dd011cc191\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"8b393704-896e-44f9-84bd-0ea3addc7805\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a9b1834c-4af7-44b5-81de-00dc035a0515\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"0aed8bf1-ee5a-4d7d-b82d-ba03feb902fa\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"7434a2d9-23f7-4206-84fa-f1bbad8be64f\"}]',3,'2022-07-25 00:29:09','2022-07-25 00:29:09','47eb4655-19ff-43cb-993a-024a34b6b85d'),(48,13,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\commerce\\\\fieldlayoutelements\\\\VariantTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"fc45a020-850c-4edb-ba67-5c937831374e\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":\"Primary Image\",\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"d4759c95-9f91-4e85-a3a4-129381abe002\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"9c475876-3670-4452-82c1-8274c5cbccb2\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":\"Image Gallery\",\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"ab929b61-c627-441a-bca3-9824cd94242e\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"79086cc3-2cc6-4433-b251-eb6b65e115c8\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":50,\"uid\":\"7f88c82a-1e75-46a5-acb0-fec39a562cc6\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"47f75540-4c56-4e84-9946-3fba7ad7d9f1\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":50,\"uid\":\"aef720c1-6b20-4d65-9a3c-bf9ad7fb1d81\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1\"}]',1,'2022-07-25 00:29:09','2022-07-25 00:29:09','16f80699-3a80-4e62-b456-3e62a1db7f06'),(49,4,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"402e89e8-cc62-407b-bb96-30b9863899b5\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a1b271b7-b466-4c87-8201-986bcb728a78\"}]',1,'2022-07-25 00:40:18','2022-07-25 00:40:18','af7165b1-705a-4116-ab2b-64d17bebae25'),(50,5,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"e0771271-7c2f-4162-a0c9-465f9b04b34d\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"a1418b5d-f2c0-4a47-a789-f6ce3f3b0387\"}]',1,'2022-07-25 00:40:18','2022-07-25 00:40:18','658ac757-d60a-47fd-959c-5feb00c6cc61');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fields` VALUES (1,5,'Content Blocks','contentBlocks','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"minBlocks\":null,\"maxBlocks\":null,\"contentTable\":\"{{%matrixcontent_contentblocks}}\",\"propagationMethod\":\"all\",\"propagationKeyFormat\":null}','2022-07-24 23:21:10','2022-07-25 00:40:18','8aa229ec-7643-48c3-947d-9d2c1882b8f2'),(2,NULL,'Size','size','matrixBlockType:76a9bb5d-1499-4e0d-afff-29da6dde9d01','fvusojty',NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"Small\",\"value\":\"small\",\"default\":\"\"},{\"label\":\"Medium\",\"value\":\"medium\",\"default\":\"1\"},{\"label\":\"Large\",\"value\":\"large\",\"default\":\"\"}]}','2022-07-24 23:21:11','2022-07-24 23:21:11','4dc80b48-acd0-45f5-abdd-abe4eadce58e'),(3,NULL,'Heading','heading','matrixBlockType:76a9bb5d-1499-4e0d-afff-29da6dde9d01','jpsldsyc',NULL,1,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2022-07-24 23:21:11','2022-07-24 23:21:11','0491950d-ac35-4f01-a408-29e979b6dd19'),(4,NULL,'Rich Text','richText','matrixBlockType:63057f3f-d739-4b88-9252-46dc4d1d283a','ncfavohf',NULL,0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":null,\"purifyHtml\":true,\"redactorConfig\":\"Content.json\",\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}','2022-07-24 23:21:11','2022-07-25 00:40:18','a1b271b7-b466-4c87-8201-986bcb728a78'),(5,NULL,'Image','image','matrixBlockType:e629d7f3-088b-4db7-96f2-b32c33036226',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"defaultUploadLocationSource\":\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":\"Add an image\",\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"source\":null,\"sources\":[\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2022-07-24 23:21:11','2022-07-25 00:40:18','a1418b5d-f2c0-4a47-a789-f6ce3f3b0387'),(6,2,'Image','image','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"defaultUploadLocationSource\":\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":\"Add an image\",\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"source\":null,\"sources\":[\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2022-07-24 23:22:12','2022-07-24 23:22:12','9c475876-3670-4452-82c1-8274c5cbccb2'),(7,3,'Heading','heading','global','kfvlhjpo',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2022-07-24 23:22:30','2022-07-24 23:22:30','0f2c6c9a-3092-47f2-b0dc-46d8ce11c178'),(8,4,'Results per page','pagination','global','peazjrid',NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"3\",\"value\":\"3\",\"default\":\"\"},{\"label\":\"6\",\"value\":\"6\",\"default\":\"\"},{\"label\":\"9\",\"value\":\"9\",\"default\":\"1\"},{\"label\":\"12\",\"value\":\"12\",\"default\":\"\"},{\"label\":\"24\",\"value\":\"24\",\"default\":\"\"},{\"label\":\"30\",\"value\":\"30\",\"default\":\"\"}]}','2022-07-24 23:24:16','2022-07-24 23:24:16','7a24de90-6ecf-4386-b258-7e1b8d1671f4'),(9,6,'Categories','categories','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Categories','{\"allowLimit\":false,\"allowMultipleSources\":false,\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":null,\"showSiteMenu\":true,\"source\":\"group:1b753347-9223-47d6-8349-fc1c7c290ea1\",\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2022-07-24 23:28:18','2022-07-24 23:42:08','d7d54391-72ab-425b-87f9-d3b982cbd69d'),(10,5,'Primary Navigation','primaryNavigation','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Matrix','{\"contentTable\":\"{{%matrixcontent_primarynavigation}}\",\"maxBlocks\":null,\"minBlocks\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\"}','2022-07-24 23:33:36','2022-07-24 23:41:04','df62c394-9de1-4e87-baf3-56bc70321894'),(11,NULL,'Navigation Link','navLink','matrixBlockType:430acb24-9641-4661-b62e-0cdc21c0fe56',NULL,NULL,0,'none',NULL,'lenz\\linkfield\\fields\\LinkField','{\"allowCustomText\":true,\"allowTarget\":false,\"autoNoReferrer\":false,\"customTextMaxLength\":0,\"customTextRequired\":false,\"defaultLinkName\":\"asset\",\"defaultText\":\"\",\"enableAllLinkTypes\":false,\"enableAriaLabel\":false,\"enableElementCache\":false,\"enableTitle\":false,\"typeSettings\":{\"asset\":{\"allowCrossSiteLink\":false,\"allowCustomQuery\":false,\"enabled\":false,\"sources\":\"*\"},\"category\":{\"allowCrossSiteLink\":false,\"allowCustomQuery\":false,\"enabled\":false,\"sources\":\"*\"},\"craftCommerce-product\":{\"allowCrossSiteLink\":false,\"allowCustomQuery\":false,\"enabled\":true,\"sources\":\"*\"},\"custom\":{\"allowAliases\":false,\"disableValidation\":false,\"enabled\":false},\"email\":{\"allowAliases\":false,\"disableValidation\":false,\"enabled\":false},\"entry\":{\"allowCrossSiteLink\":false,\"allowCustomQuery\":false,\"enabled\":true,\"sources\":[\"section:3f16d68f-cda8-49f7-8564-ba9db1855669\"]},\"site\":{\"enabled\":false,\"sites\":\"*\"},\"tel\":{\"allowAliases\":false,\"disableValidation\":false,\"enabled\":false},\"url\":{\"allowAliases\":false,\"disableValidation\":false,\"enabled\":true},\"user\":{\"allowCrossSiteLink\":false,\"allowCustomQuery\":false,\"enabled\":false,\"sources\":\"*\"}}}','2022-07-24 23:33:36','2022-07-24 23:39:35','8151dd06-ae31-4c45-bd7e-47e7adbafd1b'),(12,2,'Preview Image','previewImage','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"defaultUploadLocationSource\":\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":null,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"source\":null,\"sources\":[\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2022-07-24 23:34:45','2022-07-24 23:34:45','66830969-da65-4137-bbfa-98dd011cc191'),(13,3,'Keywords','keywords','global','uzxqvjtt',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2022-07-24 23:34:57','2022-07-24 23:34:57','7434a2d9-23f7-4206-84fa-f1bbad8be64f'),(14,4,'Color','color','global','iyxiwocv',NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"None\",\"value\":\"none\",\"default\":\"1\"},{\"label\":\"White\",\"value\":\"white\",\"default\":\"\"},{\"label\":\"Gray\",\"value\":\"gray\",\"default\":\"\"},{\"label\":\"Black\",\"value\":\"black\",\"default\":\"\"},{\"label\":\"Red\",\"value\":\"red\",\"default\":\"\"},{\"label\":\"Green\",\"value\":\"green\",\"default\":\"\"},{\"label\":\"Blue\",\"value\":\"blue\",\"default\":\"\"},{\"label\":\"Yellow\",\"value\":\"yellow\",\"default\":\"\"},{\"label\":\"Orange\",\"value\":\"orange\",\"default\":\"\"}]}','2022-07-24 23:47:52','2022-07-24 23:49:22','8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1'),(15,4,'Size','size','global','ydwihhqh',NULL,0,'none',NULL,'craft\\fields\\Dropdown','{\"options\":[{\"label\":\"XXS\",\"value\":\"xxs\",\"default\":\"\"},{\"label\":\"XS\",\"value\":\"xs\",\"default\":\"\"},{\"label\":\"S\",\"value\":\"s\",\"default\":\"\"},{\"label\":\"M\",\"value\":\"m\",\"default\":\"1\"},{\"label\":\"L\",\"value\":\"l\",\"default\":\"\"},{\"label\":\"XL\",\"value\":\"xl\",\"default\":\"\"},{\"label\":\"XXL\",\"value\":\"xxl\",\"default\":\"\"}]}','2022-07-24 23:48:40','2022-07-24 23:48:40','47f75540-4c56-4e84-9946-3fba7ad7d9f1'),(16,2,'Images','images','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"defaultUploadLocationSource\":\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maxRelations\":null,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":\"Add an image\",\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"source\":null,\"sources\":[\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"large\"}','2022-07-24 23:56:47','2022-07-24 23:56:47','79086cc3-2cc6-4433-b251-eb6b65e115c8'),(17,3,'Preview Text','previewText','global','qeshyjtt',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2022-07-25 00:24:01','2022-07-25 00:24:01','a9b1834c-4af7-44b5-81de-00dc035a0515');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2022-07-25 00:32:48','2022-07-25 00:32:48','36672673-27b1-406e-b81f-41a1cf1b2c7c');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `info` VALUES (1,'4.1.4.1','4.0.0.9',0,'wvqhhaljxfxa','3@ycapthtgwh','2022-07-24 18:09:58','2022-07-25 17:06:35','998198e0-b90f-45bd-a1f8-0ef5d0354d73');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `lenz_linkfield`
--

LOCK TABLES `lenz_linkfield` WRITE;
/*!40000 ALTER TABLE `lenz_linkfield` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `lenz_linkfield` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks` VALUES (14,13,1,2,0,'2022-07-25 00:40:36','2022-07-25 00:40:36');
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocks_owners` VALUES (14,13,1);
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixblocktypes` VALUES (1,1,3,'Heading','heading',1,'2022-07-24 23:21:11','2022-07-24 23:21:11','76a9bb5d-1499-4e0d-afff-29da6dde9d01'),(2,1,4,'Copy','copy',2,'2022-07-24 23:21:11','2022-07-24 23:21:11','63057f3f-d739-4b88-9252-46dc4d1d283a'),(3,1,5,'Image','image',3,'2022-07-24 23:21:11','2022-07-24 23:21:11','e629d7f3-088b-4db7-96f2-b32c33036226'),(4,10,9,'Menu Item','menuItem',1,'2022-07-24 23:33:37','2022-07-24 23:33:37','430acb24-9641-4661-b62e-0cdc21c0fe56');
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_contentblocks`
--

LOCK TABLES `matrixcontent_contentblocks` WRITE;
/*!40000 ALTER TABLE `matrixcontent_contentblocks` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `matrixcontent_contentblocks` VALUES (1,14,1,'2022-07-25 00:40:36','2022-07-25 00:40:36','ae3f0e59-a06d-4c9f-8e30-4c16ac5758a4',NULL,NULL,NULL);
/*!40000 ALTER TABLE `matrixcontent_contentblocks` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `matrixcontent_primarynavigation`
--

LOCK TABLES `matrixcontent_primarynavigation` WRITE;
/*!40000 ALTER TABLE `matrixcontent_primarynavigation` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `matrixcontent_primarynavigation` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `migrations` VALUES (1,'craft','Install','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','bf6ecae5-f145-40f4-b013-65cb5db961aa'),(2,'craft','m210121_145800_asset_indexing_changes','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','9f48fd2d-041f-4ef9-9c08-d7dd0f76d295'),(3,'craft','m210624_222934_drop_deprecated_tables','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','937129b0-54ab-4505-9edf-a29e3a587930'),(4,'craft','m210724_180756_rename_source_cols','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','8965e2e5-6324-46c6-8591-febb852a066b'),(5,'craft','m210809_124211_remove_superfluous_uids','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','934db150-d090-4a37-8e9e-e951aeb41534'),(6,'craft','m210817_014201_universal_users','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','c08160f4-d4c2-4035-ae18-514916ed45b6'),(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','58fcee9b-023b-4572-a374-06906049ade8'),(8,'craft','m211115_135500_image_transformers','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','c6845161-0e9f-40fc-8591-0a5c031941ab'),(9,'craft','m211201_131000_filesystems','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','5ca3045c-8b0b-4707-9f66-22a03020b1de'),(10,'craft','m220103_043103_tab_conditions','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','4948e813-1845-4eb7-892d-9f83d869fb98'),(11,'craft','m220104_003433_asset_alt_text','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','2539fbc9-ab48-4f6e-a6b3-cb31fbff1114'),(12,'craft','m220123_213619_update_permissions','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','fd1cd208-d602-4657-b1ad-d8f3072ce629'),(13,'craft','m220126_003432_addresses','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','07297d96-06e9-4813-8c8b-8bec3a2d3ed7'),(14,'craft','m220209_095604_add_indexes','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','3f55d4d2-bc29-4cbe-bde9-7f3175f8878b'),(15,'craft','m220213_015220_matrixblocks_owners_table','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','85321966-cbcf-4b19-9c02-3f24701042f6'),(16,'craft','m220214_000000_truncate_sessions','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','5980eed4-fb47-4950-a6fb-daa985cb30c1'),(17,'craft','m220222_122159_full_names','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','ef5bea3f-1911-4bd9-840c-e1ce19be4f7a'),(18,'craft','m220223_180559_nullable_address_owner','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','30fe8f53-a6ab-4a7d-9eed-83823031f0d3'),(19,'craft','m220225_165000_transform_filesystems','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','8396be36-62b6-4d79-8479-a7e1f751ebbc'),(20,'craft','m220309_152006_rename_field_layout_elements','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','8dbf37b2-cf0a-4eeb-83f2-c94886492b56'),(21,'craft','m220314_211928_field_layout_element_uids','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','4f620030-20a8-4dd3-82ea-28cc7db02b3a'),(22,'craft','m220316_123800_transform_fs_subpath','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','7ee966da-25ae-40de-af73-9ef20570e065'),(23,'craft','m220317_174250_release_all_jobs','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','660f012a-2c5b-43df-9339-837f2732002d'),(24,'craft','m220330_150000_add_site_gql_schema_components','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','9477ac29-8589-4880-b424-fc9a90edb26a'),(25,'craft','m220413_024536_site_enabled_string','2022-07-24 18:10:01','2022-07-24 18:10:01','2022-07-24 18:10:01','7e06d43f-cc17-433d-aa69-0263eaa2e200'),(26,'plugin:commerce','Install','2022-07-24 18:15:51','2022-07-24 18:15:51','2022-07-24 18:15:51','c65cea78-e98c-477f-aca1-6af61070a9e7'),(27,'plugin:commerce','m210614_073359_detailed_permission','2022-07-24 18:15:51','2022-07-24 18:15:51','2022-07-24 18:15:51','0da16ac7-0eff-4d06-bf20-4a6e1a0cd8eb'),(28,'plugin:commerce','m210831_080542_rename_variant_title_format_field','2022-07-24 18:15:51','2022-07-24 18:15:51','2022-07-24 18:15:51','550d9940-55c7-4013-849f-54e415039a6e'),(29,'plugin:commerce','m210901_211323_not_null_booleans','2022-07-24 18:15:51','2022-07-24 18:15:51','2022-07-24 18:15:51','f5e8083e-c299-4df3-8492-634ebae021c1'),(30,'plugin:commerce','m210922_133729_add_discount_order_condition_builder','2022-07-24 18:15:51','2022-07-24 18:15:51','2022-07-24 18:15:51','2cf84b46-646d-43f2-9608-bbffb8afa61c'),(31,'plugin:commerce','m211118_101920_split_coupon_codes','2022-07-24 18:15:51','2022-07-24 18:15:51','2022-07-24 18:15:51','ae1cdb54-02c2-464d-aeed-da5c41322f14'),(32,'plugin:commerce','m220301_022054_user_addresses','2022-07-24 18:15:51','2022-07-24 18:15:51','2022-07-24 18:15:51','641e0424-bf9e-4543-a9d0-08f6feb00d8e'),(33,'plugin:commerce','m220302_133730_add_discount_user_addresses_condition_builders','2022-07-24 18:15:51','2022-07-24 18:15:51','2022-07-24 18:15:51','561df8cd-31f1-40b8-9119-43087c6ba18f'),(34,'plugin:commerce','m220304_094835_discount_conditions','2022-07-24 18:15:51','2022-07-24 18:15:51','2022-07-24 18:15:51','74bad905-8d12-4537-8cee-c6f77cd390ed'),(35,'plugin:commerce','m220308_221717_orderhistory_name','2022-07-24 18:15:51','2022-07-24 18:15:51','2022-07-24 18:15:51','e56ed4df-1633-41cc-86c3-a11f3b18efd5'),(36,'plugin:commerce','m220329_075053_convert_gateway_frontend_enabled_column','2022-07-24 18:15:51','2022-07-24 18:15:51','2022-07-24 18:15:51','029cfcf1-bdd0-45c2-922a-bcdf08079ec7'),(37,'plugin:commerce','m220706_132118_add_purchasable_tax_type','2022-07-24 18:15:51','2022-07-24 18:15:51','2022-07-24 18:15:51','71a72bf5-8d6d-4255-ad80-61429d7d714c'),(38,'plugin:redactor','m180430_204710_remove_old_plugins','2022-07-24 18:47:33','2022-07-24 18:47:33','2022-07-24 18:47:33','444a696a-3924-4f15-a627-5492efd2fc70'),(39,'plugin:redactor','Install','2022-07-24 18:47:33','2022-07-24 18:47:33','2022-07-24 18:47:33','e85d3e43-0b84-406f-926e-f3f368557914'),(40,'plugin:redactor','m190225_003922_split_cleanup_html_settings','2022-07-24 18:47:33','2022-07-24 18:47:33','2022-07-24 18:47:33','9291668d-885c-4027-aa7d-1a35e29da661'),(41,'plugin:commerce-stripe','Install','2022-07-24 18:49:17','2022-07-24 18:49:17','2022-07-24 18:49:17','10bfad7e-df50-45c1-a248-28a1274c449e'),(42,'plugin:commerce-stripe','m190502_153000_payment_intents','2022-07-24 18:49:17','2022-07-24 18:49:17','2022-07-24 18:49:17','4d6af822-fb00-4653-aa73-1c6e95a0def3'),(43,'plugin:commerce-stripe','m210903_040320_payment_intent_unique_on_transaction','2022-07-24 18:49:17','2022-07-24 18:49:17','2022-07-24 18:49:17','9903f79a-d8a9-49cc-9bb6-064ab551feb0'),(44,'plugin:commerce-stripe','m220406_160425_remove_charge_gateway_references','2022-07-24 18:49:17','2022-07-24 18:49:17','2022-07-24 18:49:17','dfcd2c84-112b-4e41-9098-94e98092db49'),(45,'plugin:typedlinkfield','Install','2022-07-24 22:43:51','2022-07-24 22:43:51','2022-07-24 22:43:51','c3dffa6e-42e0-4c76-a056-243553202853'),(46,'plugin:typedlinkfield','m190417_202153_migrateDataToTable','2022-07-24 22:43:51','2022-07-24 22:43:51','2022-07-24 22:43:51','c60c7417-3762-4fdc-b2d6-c901dce98ecb'),(47,'plugin:seomatic','Install','2022-07-25 00:21:43','2022-07-25 00:21:43','2022-07-25 00:21:43','8781b0e4-34c8-4459-a2e2-491c7aafd7f4'),(48,'plugin:seomatic','m180314_002755_field_type','2022-07-25 00:21:43','2022-07-25 00:21:43','2022-07-25 00:21:43','da57b399-92e3-4b98-8871-2c9582bbb8ab'),(49,'plugin:seomatic','m180314_002756_base_install','2022-07-25 00:21:43','2022-07-25 00:21:43','2022-07-25 00:21:43','c2088578-4198-4622-a71b-86ede8a8179c'),(50,'plugin:seomatic','m180502_202319_remove_field_metabundles','2022-07-25 00:21:43','2022-07-25 00:21:43','2022-07-25 00:21:43','9ab7b982-fcf8-43d4-9dcc-f68e9a385933'),(51,'plugin:seomatic','m180711_024947_commerce_products','2022-07-25 00:21:43','2022-07-25 00:21:43','2022-07-25 00:21:43','a8968040-2794-4191-aec7-853ca9d55a94'),(52,'plugin:seomatic','m190401_220828_longer_handles','2022-07-25 00:21:43','2022-07-25 00:21:43','2022-07-25 00:21:43','f27947b7-f83d-40e9-a426-87ea1d26641f'),(53,'plugin:seomatic','m190518_030221_calendar_events','2022-07-25 00:21:43','2022-07-25 00:21:43','2022-07-25 00:21:43','cd0a7218-e8f3-4e21-8dea-0c84ba37eec1'),(54,'plugin:seomatic','m200419_203444_add_type_id','2022-07-25 00:21:43','2022-07-25 00:21:43','2022-07-25 00:21:43','bf2e4cad-0b08-4001-b752-d3c86addc812'),(55,'plugin:seomatic','m210603_213100_add_gql_schema_components','2022-07-25 00:21:43','2022-07-25 00:21:43','2022-07-25 00:21:43','a55d11db-12f4-4de2-a7d6-102871372bea'),(56,'plugin:seomatic','m210817_230853_announcement_v3_4','2022-07-25 00:21:43','2022-07-25 00:21:43','2022-07-25 00:21:43','ec029c1d-4686-4596-b1d9-592f368ab93d');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `plugins` VALUES (1,'commerce','4.1.0','4.1.0','trial',NULL,'2022-07-24 18:15:46','2022-07-24 18:15:46','2022-07-25 00:36:46','993fe447-6c3f-49ce-b121-52cb66d148e0'),(2,'redactor','3.0.2','2.3.0','unknown',NULL,'2022-07-24 18:47:33','2022-07-24 18:47:33','2022-07-25 00:36:46','84d16971-689e-4481-b2eb-5d0ba306dae9'),(3,'commerce-stripe','3.0.1','3.0.0','unknown',NULL,'2022-07-24 18:49:17','2022-07-24 18:49:17','2022-07-25 00:36:46','fcacdb5b-260c-4e97-b540-239fa7704a4c'),(4,'commerce-paypal-checkout','2.1.0.1','1.0','unknown',NULL,'2022-07-24 18:52:12','2022-07-24 18:52:12','2022-07-25 00:36:46','282c0fe3-79ab-435a-a392-f1f6ffeafeb3'),(5,'typedlinkfield','2.1.3-rc','2.0.0','unknown',NULL,'2022-07-24 22:43:51','2022-07-24 22:43:51','2022-07-25 00:36:46','c7136c12-6e70-4e7e-9bf8-b34ca05f4347'),(6,'seomatic','4.0.7','3.0.11','trial',NULL,'2022-07-25 00:21:42','2022-07-25 00:21:42','2022-07-25 00:36:46','240a4fd6-f61a-474e-85be-4f1c6387ddd1');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `projectconfig` VALUES ('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.defaultPlacement','\"end\"'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elementCondition','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.autocapitalize','true'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.autocomplete','false'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.autocorrect','true'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.class','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.disabled','false'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.elementCondition','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.id','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.instructions','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.label','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.max','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.min','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.name','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.orientation','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.placeholder','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.readonly','false'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.requirable','false'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.size','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.step','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.tip','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.title','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\TitleField\"'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.uid','\"40cd8982-a8ef-4dda-955a-067f9fc8727d\"'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.userCondition','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.warning','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.elements.0.width','100'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.name','\"Content\"'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.uid','\"41c288bf-41f9-4a0c-95c3-3ef3c78051e6\"'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.fieldLayouts.4ecf4e1d-8b68-4e78-b16b-d6c3cc9a78c2.tabs.0.userCondition','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.handle','\"productCategories\"'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.name','\"Product Categories\"'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.hasUrls','false'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.template','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.uriFormat','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.structure.maxLevels','null'),('categoryGroups.1b753347-9223-47d6-8349-fc1c7c290ea1.structure.uid','\"1c741add-2650-4095-a422-47bd2ba29393\"'),('commerce.gateways.148bf625-3ed8-48e1-9a43-70fc218ce67c.handle','\"manual\"'),('commerce.gateways.148bf625-3ed8-48e1-9a43-70fc218ce67c.isFrontendEnabled','\"$MANUAL_ENABLED\"'),('commerce.gateways.148bf625-3ed8-48e1-9a43-70fc218ce67c.name','\"Manual\"'),('commerce.gateways.148bf625-3ed8-48e1-9a43-70fc218ce67c.paymentType','\"authorize\"'),('commerce.gateways.148bf625-3ed8-48e1-9a43-70fc218ce67c.settings.onlyAllowForZeroPriceOrders','true'),('commerce.gateways.148bf625-3ed8-48e1-9a43-70fc218ce67c.sortOrder','3'),('commerce.gateways.148bf625-3ed8-48e1-9a43-70fc218ce67c.type','\"craft\\\\commerce\\\\gateways\\\\Manual\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.handle','\"paypal\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.isFrontendEnabled','\"$PAYPAL_ENABLED\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.name','\"PayPal\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.paymentType','\"purchase\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.settings.brandName','\"$PAYPAL_BRAND\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.settings.clientId','\"$PAYPAL_CLIENT_ID\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.settings.landingPage','\"BILLING\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.settings.secret','\"$PAYPAL_SECRET\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.settings.sendCartInfo','\"$PAYPAL_SEND_CART_INFO\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.settings.sendShippingInfo','\"$PAYPAL_SEND_SHIIPING_INFO\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.settings.testMode','\"$PAYPAL_TEST_MODE\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.settings._brandName','\"$PAYPAL_BRAND\"'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.sortOrder','2'),('commerce.gateways.56fd568a-e1bd-46d2-af2f-8a5b610e47bf.type','\"craft\\\\commerce\\\\paypalcheckout\\\\gateways\\\\Gateway\"'),('commerce.gateways.6cbc0418-8b1f-411b-aa21-4937acf9bc1a.handle','\"stripe\"'),('commerce.gateways.6cbc0418-8b1f-411b-aa21-4937acf9bc1a.isFrontendEnabled','\"$STRIPE_ENABLED\"'),('commerce.gateways.6cbc0418-8b1f-411b-aa21-4937acf9bc1a.name','\"Stripe\"'),('commerce.gateways.6cbc0418-8b1f-411b-aa21-4937acf9bc1a.paymentType','\"purchase\"'),('commerce.gateways.6cbc0418-8b1f-411b-aa21-4937acf9bc1a.settings.apiKey','\"$STRIPE_SECRET_KEY\"'),('commerce.gateways.6cbc0418-8b1f-411b-aa21-4937acf9bc1a.settings.publishableKey','\"$STRIPE_PUB_KEY\"'),('commerce.gateways.6cbc0418-8b1f-411b-aa21-4937acf9bc1a.settings.sendReceiptEmail','\"$STRIPE_SEND_EMAIL\"'),('commerce.gateways.6cbc0418-8b1f-411b-aa21-4937acf9bc1a.settings.signingSecret','\"$STRIPE_WEBHOOK_SECRET\"'),('commerce.gateways.6cbc0418-8b1f-411b-aa21-4937acf9bc1a.sortOrder','1'),('commerce.gateways.6cbc0418-8b1f-411b-aa21-4937acf9bc1a.type','\"craft\\\\commerce\\\\stripe\\\\gateways\\\\PaymentIntents\"'),('commerce.orderStatuses.e4b25d4c-f8ee-4d1b-a77c-2e70560cb1d0.color','\"green\"'),('commerce.orderStatuses.e4b25d4c-f8ee-4d1b-a77c-2e70560cb1d0.default','true'),('commerce.orderStatuses.e4b25d4c-f8ee-4d1b-a77c-2e70560cb1d0.description','null'),('commerce.orderStatuses.e4b25d4c-f8ee-4d1b-a77c-2e70560cb1d0.handle','\"new\"'),('commerce.orderStatuses.e4b25d4c-f8ee-4d1b-a77c-2e70560cb1d0.name','\"New\"'),('commerce.orderStatuses.e4b25d4c-f8ee-4d1b-a77c-2e70560cb1d0.sortOrder','99'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.descriptionFormat','\"{product.title} - {color} - {size}\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.handle','\"catalog\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.hasDimensions','true'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.hasProductTitleField','true'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.hasVariants','true'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.hasVariantTitleField','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.name','\"Catalog\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.autocapitalize','true'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.autocomplete','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.autocorrect','true'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.class','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.disabled','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.id','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.instructions','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.label','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.max','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.min','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.name','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.orientation','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.placeholder','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.readonly','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.requirable','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.size','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.step','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.tip','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.title','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\ProductTitleField\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.uid','\"12acf916-d888-4aff-b737-5c040721aec9\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.warning','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.0.width','100'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.1.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.1.fieldUid','\"8aa229ec-7643-48c3-947d-9d2c1882b8f2\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.1.instructions','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.1.label','\"Product Description\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.1.required','true'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.1.tip','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.1.uid','\"a05937a7-1bf9-4e33-aab5-df8afe43e945\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.1.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.1.warning','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.1.width','100'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.2.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.2.fieldUid','\"d7d54391-72ab-425b-87f9-d3b982cbd69d\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.2.instructions','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.2.label','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.2.required','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.2.tip','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.2.uid','\"30f49bec-4c8e-4a27-b40f-6d1bd42aba1d\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.2.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.2.warning','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.elements.2.width','100'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.name','\"Content\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.uid','\"3307efff-7105-4e42-8af0-d5f88b786d27\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.0.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.elements.0.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.elements.0.instructions','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.elements.0.label','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.elements.0.required','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.elements.0.tip','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.elements.0.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\VariantsField\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.elements.0.uid','\"7224ab79-9dec-46cf-b989-f684f7bad0f6\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.elements.0.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.elements.0.warning','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.name','\"Variants\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.uid','\"7e00adcb-cf38-4694-a2c1-074c45b36314\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.1.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.0.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.0.fieldUid','\"66830969-da65-4137-bbfa-98dd011cc191\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.0.instructions','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.0.label','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.0.required','true'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.0.tip','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.0.uid','\"c75f272d-2f1e-4452-85b7-b620bee1785d\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.0.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.0.warning','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.0.width','100'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.1.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.1.fieldUid','\"a9b1834c-4af7-44b5-81de-00dc035a0515\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.1.instructions','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.1.label','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.1.required','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.1.tip','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.1.uid','\"8b393704-896e-44f9-84bd-0ea3addc7805\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.1.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.1.warning','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.1.width','100'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.2.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.2.fieldUid','\"7434a2d9-23f7-4206-84fa-f1bbad8be64f\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.2.instructions','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.2.label','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.2.required','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.2.tip','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.2.uid','\"0aed8bf1-ee5a-4d7d-b82d-ba03feb902fa\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.2.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.2.warning','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.elements.2.width','100'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.name','\"SEO / Meta\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.uid','\"47eb4655-19ff-43cb-993a-024a34b6b85d\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productFieldLayouts.1a024e00-ff0e-4a6c-b2d5-e79329391f82.tabs.2.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.productTitleFormat','\"\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.hasUrls','true'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.template','\"index\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.uriFormat','\"{{alias(\\\"@nuxtBaseUrl\\\")}}/catalog/{slug}\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.skuFormat','\"CAT-{product.slug|upper}-{color|upper}-{size|upper}\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.autocapitalize','true'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.autocomplete','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.autocorrect','true'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.class','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.disabled','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.id','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.instructions','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.label','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.max','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.min','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.name','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.orientation','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.placeholder','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.readonly','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.requirable','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.size','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.step','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.tip','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.title','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.type','\"craft\\\\commerce\\\\fieldlayoutelements\\\\VariantTitleField\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.uid','\"fc45a020-850c-4edb-ba67-5c937831374e\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.warning','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.0.width','100'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.1.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.1.fieldUid','\"9c475876-3670-4452-82c1-8274c5cbccb2\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.1.instructions','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.1.label','\"Primary Image\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.1.required','true'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.1.tip','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.1.uid','\"d4759c95-9f91-4e85-a3a4-129381abe002\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.1.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.1.warning','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.1.width','100'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.2.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.2.fieldUid','\"79086cc3-2cc6-4433-b251-eb6b65e115c8\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.2.instructions','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.2.label','\"Image Gallery\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.2.required','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.2.tip','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.2.uid','\"ab929b61-c627-441a-bca3-9824cd94242e\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.2.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.2.warning','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.2.width','100'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.3.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.3.fieldUid','\"47f75540-4c56-4e84-9946-3fba7ad7d9f1\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.3.instructions','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.3.label','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.3.required','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.3.tip','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.3.uid','\"7f88c82a-1e75-46a5-acb0-fec39a562cc6\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.3.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.3.warning','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.3.width','50'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.4.elementCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.4.fieldUid','\"8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.4.instructions','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.4.label','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.4.required','false'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.4.tip','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.4.uid','\"aef720c1-6b20-4d65-9a3c-bf9ad7fb1d81\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.4.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.4.warning','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.elements.4.width','50'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.name','\"Content\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.uid','\"16f80699-3a80-4e62-b456-3e62a1db7f06\"'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantFieldLayouts.0ee86279-568d-443a-af9d-f1e1a8cb86e9.tabs.0.userCondition','null'),('commerce.productTypes.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840.variantTitleFormat','\"{product.title} - {color} - {size}\"'),('dateModified','1658768795'),('email.fromEmail','\"admin@fostercommerce.com\"'),('email.fromName','\"Foster Commerce Dot All 2022\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elementCondition','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.autocapitalize','true'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.autocomplete','false'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.autocorrect','true'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.class','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.disabled','false'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.elementCondition','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.id','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.instructions','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.label','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.max','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.min','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.name','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.orientation','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.placeholder','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.readonly','false'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.requirable','false'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.size','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.step','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.tip','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.title','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.uid','\"30bf0f48-8080-445d-adda-e3d099aed548\"'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.userCondition','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.warning','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.0.width','100'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.1.elementCondition','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.1.fieldUid','\"df62c394-9de1-4e87-baf3-56bc70321894\"'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.1.instructions','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.1.label','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.1.required','false'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.1.tip','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.1.uid','\"73baeb77-970b-40f9-a685-dc722d0e7e02\"'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.1.userCondition','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.1.warning','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.elements.1.width','100'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.name','\"Navigation\"'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.uid','\"75547dbd-df26-44f0-8485-b1e676a3ac0f\"'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.fieldLayouts.f820c502-38c3-4639-8fca-dcd920d95009.tabs.0.userCondition','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.handle','\"settings\"'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.hasTitleField','false'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.name','\"Settings\"'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.section','\"f96300ba-530d-42dd-94d6-b086b49639ec\"'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.sortOrder','1'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.titleFormat','\"{section.name|raw}\"'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.titleTranslationKeyFormat','null'),('entryTypes.05440641-857c-492e-bbb9-37ff03c88963.titleTranslationMethod','\"site\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elementCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.autocapitalize','true'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.autocomplete','false'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.autocorrect','true'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.class','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.disabled','false'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.elementCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.id','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.instructions','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.label','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.max','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.min','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.name','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.orientation','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.placeholder','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.readonly','false'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.requirable','false'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.size','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.step','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.tip','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.title','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.uid','\"2d0e6902-d08d-436c-82e8-1b8df7066cfc\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.userCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.warning','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.0.width','100'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.1.elementCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.1.fieldUid','\"9c475876-3670-4452-82c1-8274c5cbccb2\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.1.instructions','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.1.label','\"Header Image\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.1.required','true'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.1.tip','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.1.uid','\"b6f9f139-e19b-4454-9476-063f84469fc7\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.1.userCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.1.warning','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.1.width','100'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.2.elementCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.2.fieldUid','\"d7d54391-72ab-425b-87f9-d3b982cbd69d\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.2.instructions','\"Select the categories to filter products on. Leave blank to display all products.\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.2.label','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.2.required','false'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.2.tip','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.2.uid','\"328d1728-d526-4382-8723-9bc750ae21a8\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.2.userCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.2.warning','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.2.width','100'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.3.elementCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.3.fieldUid','\"7a24de90-6ecf-4386-b258-7e1b8d1671f4\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.3.instructions','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.3.label','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.3.required','false'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.3.tip','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.3.uid','\"86b9dbfc-2109-4d31-9418-c366dd4d69af\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.3.userCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.3.warning','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.elements.3.width','100'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.name','\"Content\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.uid','\"3e4c41a3-bbf6-4f97-9c10-fd08d7aedcb3\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.0.userCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elementCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.0.elementCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.0.fieldUid','\"66830969-da65-4137-bbfa-98dd011cc191\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.0.instructions','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.0.label','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.0.required','true'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.0.tip','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.0.uid','\"23437dae-9e55-4025-a6d0-5096b45c46e2\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.0.userCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.0.warning','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.0.width','100'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.1.elementCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.1.fieldUid','\"a9b1834c-4af7-44b5-81de-00dc035a0515\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.1.instructions','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.1.label','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.1.required','false'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.1.tip','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.1.uid','\"d0f2f8bf-0d0a-452e-b953-fba8572170a8\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.1.userCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.1.warning','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.1.width','100'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.2.elementCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.2.fieldUid','\"7434a2d9-23f7-4206-84fa-f1bbad8be64f\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.2.instructions','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.2.label','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.2.required','false'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.2.tip','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.2.uid','\"820865c3-fb9a-4131-b7fa-6eaa0e7604d0\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.2.userCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.2.warning','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.elements.2.width','100'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.name','\"SEO / Meta\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.uid','\"37118b48-517e-4af2-86ef-7d920d7dcaad\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.fieldLayouts.0217c0aa-5f8d-4e8f-9b01-7ee4d69cf895.tabs.1.userCondition','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.handle','\"catalog\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.hasTitleField','true'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.name','\"Catalog\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.section','\"3f16d68f-cda8-49f7-8564-ba9db1855669\"'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.sortOrder','2'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.titleFormat','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.titleTranslationKeyFormat','null'),('entryTypes.4188fa88-45c2-4d45-bc06-3a135bab0725.titleTranslationMethod','\"site\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elementCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.autocapitalize','true'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.autocomplete','false'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.autocorrect','true'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.class','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.disabled','false'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.elementCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.id','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.instructions','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.label','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.max','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.min','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.name','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.orientation','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.placeholder','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.readonly','false'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.requirable','false'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.size','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.step','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.tip','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.title','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.uid','\"1472c9af-3363-485c-9f41-2f1c21209c5b\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.userCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.warning','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.0.width','100'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.1.elementCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.1.fieldUid','\"9c475876-3670-4452-82c1-8274c5cbccb2\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.1.instructions','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.1.label','\"Header Image\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.1.required','true'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.1.tip','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.1.uid','\"425aec96-ba05-4025-9325-41732ea1f997\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.1.userCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.1.warning','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.1.width','100'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.2.elementCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.2.fieldUid','\"8aa229ec-7643-48c3-947d-9d2c1882b8f2\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.2.instructions','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.2.label','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.2.required','true'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.2.tip','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.2.uid','\"cf0c479d-8227-411e-9cbe-d9314c6ebdf4\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.2.userCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.2.warning','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.elements.2.width','100'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.name','\"Content\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.uid','\"a1b753b4-a531-4e4c-9e1b-71112e9bca04\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.0.userCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elementCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.0.elementCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.0.fieldUid','\"66830969-da65-4137-bbfa-98dd011cc191\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.0.instructions','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.0.label','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.0.required','true'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.0.tip','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.0.uid','\"f8863841-3fca-426e-b4d5-3a96084aedf8\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.0.userCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.0.warning','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.0.width','100'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.1.elementCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.1.fieldUid','\"a9b1834c-4af7-44b5-81de-00dc035a0515\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.1.instructions','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.1.label','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.1.required','false'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.1.tip','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.1.uid','\"e52d8bb2-52c7-41e9-9d01-136b9d0dda44\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.1.userCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.1.warning','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.1.width','100'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.2.elementCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.2.fieldUid','\"7434a2d9-23f7-4206-84fa-f1bbad8be64f\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.2.instructions','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.2.label','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.2.required','false'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.2.tip','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.2.uid','\"4da59ace-4bee-4cdb-a521-c3a58d784648\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.2.userCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.2.warning','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.elements.2.width','100'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.name','\"SEO / Meta\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.uid','\"64590c52-2dfe-4bd1-8b39-fcc47c2f7de1\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.fieldLayouts.53c7d4af-a5bf-4822-9517-81a0f29980ba.tabs.1.userCondition','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.handle','\"general\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.hasTitleField','true'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.name','\"General\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.section','\"3f16d68f-cda8-49f7-8564-ba9db1855669\"'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.sortOrder','1'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.titleFormat','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.titleTranslationKeyFormat','null'),('entryTypes.6e4128ef-78da-40a5-aca7-b52de59fbc3c.titleTranslationMethod','\"site\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elementCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.autocapitalize','true'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.autocomplete','false'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.autocorrect','true'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.class','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.disabled','false'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.elementCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.id','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.instructions','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.label','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.max','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.min','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.name','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.orientation','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.placeholder','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.readonly','false'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.requirable','false'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.size','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.step','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.tip','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.title','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.uid','\"3ca2d446-1add-4557-9caf-3e8a919ccad3\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.userCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.warning','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.0.width','100'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.1.elementCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.1.fieldUid','\"0f2c6c9a-3092-47f2-b0dc-46d8ce11c178\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.1.instructions','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.1.label','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.1.required','true'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.1.tip','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.1.uid','\"f36b2228-116b-49e0-a5d5-fde5a22d3301\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.1.userCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.1.warning','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.1.width','100'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.2.elementCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.2.fieldUid','\"9c475876-3670-4452-82c1-8274c5cbccb2\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.2.instructions','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.2.label','\"Hero Image\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.2.required','true'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.2.tip','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.2.uid','\"1708239f-de70-450f-a7dd-9e7844dbf30f\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.2.userCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.2.warning','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.2.width','100'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.3.elementCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.3.fieldUid','\"8aa229ec-7643-48c3-947d-9d2c1882b8f2\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.3.instructions','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.3.label','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.3.required','true'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.3.tip','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.3.uid','\"33f8fa6d-4279-40bb-b3bf-19d44b6b7c63\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.3.userCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.3.warning','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.elements.3.width','100'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.name','\"Content\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.uid','\"e3263060-a5e9-45bf-b644-6f1bbce344fa\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.0.userCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elementCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.0.elementCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.0.fieldUid','\"66830969-da65-4137-bbfa-98dd011cc191\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.0.instructions','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.0.label','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.0.required','true'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.0.tip','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.0.uid','\"9d975506-3005-454c-8bcc-8b1151b8c502\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.0.userCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.0.warning','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.0.width','100'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.1.elementCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.1.fieldUid','\"a9b1834c-4af7-44b5-81de-00dc035a0515\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.1.instructions','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.1.label','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.1.required','false'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.1.tip','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.1.uid','\"8cb1c451-7de4-4b6b-90a6-aa245a513964\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.1.userCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.1.warning','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.1.width','100'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.2.elementCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.2.fieldUid','\"7434a2d9-23f7-4206-84fa-f1bbad8be64f\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.2.instructions','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.2.label','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.2.required','false'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.2.tip','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.2.uid','\"10d57449-d562-4c41-92a7-7ba42c8933e6\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.2.userCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.2.warning','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.elements.2.width','100'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.name','\"SEO / Meta\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.uid','\"6b9ebed3-fae2-4cd7-806e-a10771ba1c18\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.fieldLayouts.c93dbc56-7a4d-4ddc-a134-160207914d32.tabs.1.userCondition','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.handle','\"home\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.hasTitleField','false'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.name','\"Home\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.section','\"9685ed87-31a4-435c-9f18-ba478320023a\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.sortOrder','1'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.titleFormat','\"{section.name|raw}\"'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.titleTranslationKeyFormat','null'),('entryTypes.d3951874-9e5b-4586-979e-c7e9c5b08d92.titleTranslationMethod','\"site\"'),('fieldGroups.1b39f5a2-15c0-4af0-be7c-0735aba76665.name','\"Text\"'),('fieldGroups.1bd188af-6bf7-4544-9e2e-f5e4052cefd1.name','\"Assets\"'),('fieldGroups.652c2871-27c1-4b30-8190-0a05255eb19b.name','\"Relations\"'),('fieldGroups.81d425d5-6a7f-4da9-b64d-3752b8286594.name','\"Other\"'),('fieldGroups.dee4f4f1-d8b0-4f5c-a6ff-b5f10e5a577f.name','\"Compound\"'),('fieldGroups.e0684c4e-4db6-49fe-b178-60bbc3750374.name','\"Options\"'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.columnSuffix','\"kfvlhjpo\"'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.contentColumnType','\"text\"'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.fieldGroup','\"1b39f5a2-15c0-4af0-be7c-0735aba76665\"'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.handle','\"heading\"'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.instructions','null'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.name','\"Heading\"'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.searchable','false'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.settings.byteLimit','null'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.settings.charLimit','null'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.settings.code','false'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.settings.columnType','null'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.settings.initialRows','4'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.settings.multiline','false'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.settings.placeholder','null'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.settings.uiMode','\"normal\"'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.translationKeyFormat','null'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.translationMethod','\"none\"'),('fields.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178.type','\"craft\\\\fields\\\\PlainText\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.columnSuffix','\"ydwihhqh\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.contentColumnType','\"string\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.fieldGroup','\"e0684c4e-4db6-49fe-b178-60bbc3750374\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.handle','\"size\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.instructions','null'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.name','\"Size\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.searchable','false'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.0.__assoc__.0.0','\"label\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.0.__assoc__.0.1','\"XXS\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.0.__assoc__.1.0','\"value\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.0.__assoc__.1.1','\"xxs\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.0.__assoc__.2.0','\"default\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.0.__assoc__.2.1','\"\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.1.__assoc__.0.0','\"label\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.1.__assoc__.0.1','\"XS\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.1.__assoc__.1.0','\"value\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.1.__assoc__.1.1','\"xs\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.1.__assoc__.2.0','\"default\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.1.__assoc__.2.1','\"\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.2.__assoc__.0.0','\"label\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.2.__assoc__.0.1','\"S\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.2.__assoc__.1.0','\"value\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.2.__assoc__.1.1','\"s\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.2.__assoc__.2.0','\"default\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.2.__assoc__.2.1','\"\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.3.__assoc__.0.0','\"label\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.3.__assoc__.0.1','\"M\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.3.__assoc__.1.0','\"value\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.3.__assoc__.1.1','\"m\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.3.__assoc__.2.0','\"default\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.3.__assoc__.2.1','\"1\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.4.__assoc__.0.0','\"label\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.4.__assoc__.0.1','\"L\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.4.__assoc__.1.0','\"value\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.4.__assoc__.1.1','\"l\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.4.__assoc__.2.0','\"default\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.4.__assoc__.2.1','\"\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.5.__assoc__.0.0','\"label\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.5.__assoc__.0.1','\"XL\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.5.__assoc__.1.0','\"value\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.5.__assoc__.1.1','\"xl\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.5.__assoc__.2.0','\"default\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.5.__assoc__.2.1','\"\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.6.__assoc__.0.0','\"label\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.6.__assoc__.0.1','\"XXL\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.6.__assoc__.1.0','\"value\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.6.__assoc__.1.1','\"xxl\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.6.__assoc__.2.0','\"default\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.settings.options.6.__assoc__.2.1','\"\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.translationKeyFormat','null'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.translationMethod','\"none\"'),('fields.47f75540-4c56-4e84-9946-3fba7ad7d9f1.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.columnSuffix','null'),('fields.66830969-da65-4137-bbfa-98dd011cc191.contentColumnType','\"string\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.fieldGroup','\"1bd188af-6bf7-4544-9e2e-f5e4052cefd1\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.handle','\"previewImage\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.instructions','null'),('fields.66830969-da65-4137-bbfa-98dd011cc191.name','\"Preview Image\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.searchable','false'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.allowedKinds.0','\"image\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.allowSelfRelations','false'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.allowSubfolders','false'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.allowUploads','true'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.defaultUploadLocationSource','\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.defaultUploadLocationSubpath','null'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.localizeRelations','false'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.maxRelations','1'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.minRelations','null'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.previewMode','\"full\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.restrictedDefaultUploadSubpath','null'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.restrictedLocationSource','\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.restrictedLocationSubpath','null'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.restrictFiles','true'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.restrictLocation','false'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.selectionLabel','null'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.showSiteMenu','false'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.showUnpermittedFiles','false'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.showUnpermittedVolumes','false'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.source','null'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.sources.0','\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.targetSiteId','null'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.validateRelatedElements','false'),('fields.66830969-da65-4137-bbfa-98dd011cc191.settings.viewMode','\"large\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.translationKeyFormat','null'),('fields.66830969-da65-4137-bbfa-98dd011cc191.translationMethod','\"site\"'),('fields.66830969-da65-4137-bbfa-98dd011cc191.type','\"craft\\\\fields\\\\Assets\"'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.columnSuffix','\"uzxqvjtt\"'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.contentColumnType','\"text\"'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.fieldGroup','\"1b39f5a2-15c0-4af0-be7c-0735aba76665\"'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.handle','\"keywords\"'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.instructions','null'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.name','\"Keywords\"'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.searchable','false'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.settings.byteLimit','null'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.settings.charLimit','null'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.settings.code','false'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.settings.columnType','null'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.settings.initialRows','4'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.settings.multiline','false'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.settings.placeholder','null'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.settings.uiMode','\"normal\"'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.translationKeyFormat','null'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.translationMethod','\"none\"'),('fields.7434a2d9-23f7-4206-84fa-f1bbad8be64f.type','\"craft\\\\fields\\\\PlainText\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.columnSuffix','null'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.contentColumnType','\"string\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.fieldGroup','\"1bd188af-6bf7-4544-9e2e-f5e4052cefd1\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.handle','\"images\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.instructions','null'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.name','\"Images\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.searchable','false'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.allowedKinds.0','\"image\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.allowSelfRelations','false'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.allowSubfolders','false'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.allowUploads','true'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.defaultUploadLocationSource','\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.defaultUploadLocationSubpath','null'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.localizeRelations','false'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.maxRelations','null'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.minRelations','null'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.previewMode','\"full\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.restrictedDefaultUploadSubpath','null'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.restrictedLocationSource','\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.restrictedLocationSubpath','null'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.restrictFiles','true'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.restrictLocation','false'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.selectionLabel','\"Add an image\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.showSiteMenu','false'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.showUnpermittedFiles','false'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.showUnpermittedVolumes','false'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.source','null'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.sources.0','\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.targetSiteId','null'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.validateRelatedElements','false'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.settings.viewMode','\"large\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.translationKeyFormat','null'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.translationMethod','\"site\"'),('fields.79086cc3-2cc6-4433-b251-eb6b65e115c8.type','\"craft\\\\fields\\\\Assets\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.columnSuffix','\"peazjrid\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.contentColumnType','\"string\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.fieldGroup','\"e0684c4e-4db6-49fe-b178-60bbc3750374\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.handle','\"pagination\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.instructions','null'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.name','\"Results per page\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.searchable','false'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.0.__assoc__.0.0','\"label\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.0.__assoc__.0.1','\"3\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.0.__assoc__.1.0','\"value\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.0.__assoc__.1.1','\"3\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.0.__assoc__.2.0','\"default\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.0.__assoc__.2.1','\"\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.1.__assoc__.0.0','\"label\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.1.__assoc__.0.1','\"6\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.1.__assoc__.1.0','\"value\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.1.__assoc__.1.1','\"6\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.1.__assoc__.2.0','\"default\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.1.__assoc__.2.1','\"\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.2.__assoc__.0.0','\"label\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.2.__assoc__.0.1','\"9\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.2.__assoc__.1.0','\"value\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.2.__assoc__.1.1','\"9\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.2.__assoc__.2.0','\"default\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.2.__assoc__.2.1','\"1\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.3.__assoc__.0.0','\"label\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.3.__assoc__.0.1','\"12\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.3.__assoc__.1.0','\"value\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.3.__assoc__.1.1','\"12\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.3.__assoc__.2.0','\"default\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.3.__assoc__.2.1','\"\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.4.__assoc__.0.0','\"label\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.4.__assoc__.0.1','\"24\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.4.__assoc__.1.0','\"value\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.4.__assoc__.1.1','\"24\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.4.__assoc__.2.0','\"default\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.4.__assoc__.2.1','\"\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.5.__assoc__.0.0','\"label\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.5.__assoc__.0.1','\"30\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.5.__assoc__.1.0','\"value\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.5.__assoc__.1.1','\"30\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.5.__assoc__.2.0','\"default\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.settings.options.5.__assoc__.2.1','\"\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.translationKeyFormat','null'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.translationMethod','\"none\"'),('fields.7a24de90-6ecf-4386-b258-7e1b8d1671f4.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.columnSuffix','null'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.contentColumnType','\"string\"'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.fieldGroup','\"dee4f4f1-d8b0-4f5c-a6ff-b5f10e5a577f\"'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.handle','\"contentBlocks\"'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.instructions','null'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.name','\"Content Blocks\"'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.searchable','false'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.settings.contentTable','\"{{%matrixcontent_contentblocks}}\"'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.settings.maxBlocks','null'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.settings.minBlocks','null'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.settings.propagationKeyFormat','null'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.settings.propagationMethod','\"all\"'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.translationKeyFormat','null'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.translationMethod','\"site\"'),('fields.8aa229ec-7643-48c3-947d-9d2c1882b8f2.type','\"craft\\\\fields\\\\Matrix\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.columnSuffix','\"iyxiwocv\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.contentColumnType','\"string\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.fieldGroup','\"e0684c4e-4db6-49fe-b178-60bbc3750374\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.handle','\"color\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.instructions','null'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.name','\"Color\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.searchable','false'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.0.__assoc__.0.0','\"label\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.0.__assoc__.0.1','\"None\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.0.__assoc__.1.0','\"value\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.0.__assoc__.1.1','\"none\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.0.__assoc__.2.0','\"default\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.0.__assoc__.2.1','\"1\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.1.__assoc__.0.0','\"label\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.1.__assoc__.0.1','\"White\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.1.__assoc__.1.0','\"value\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.1.__assoc__.1.1','\"white\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.1.__assoc__.2.0','\"default\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.1.__assoc__.2.1','\"\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.2.__assoc__.0.0','\"label\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.2.__assoc__.0.1','\"Gray\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.2.__assoc__.1.0','\"value\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.2.__assoc__.1.1','\"gray\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.2.__assoc__.2.0','\"default\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.2.__assoc__.2.1','\"\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.3.__assoc__.0.0','\"label\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.3.__assoc__.0.1','\"Black\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.3.__assoc__.1.0','\"value\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.3.__assoc__.1.1','\"black\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.3.__assoc__.2.0','\"default\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.3.__assoc__.2.1','\"\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.4.__assoc__.0.0','\"label\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.4.__assoc__.0.1','\"Red\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.4.__assoc__.1.0','\"value\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.4.__assoc__.1.1','\"red\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.4.__assoc__.2.0','\"default\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.4.__assoc__.2.1','\"\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.5.__assoc__.0.0','\"label\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.5.__assoc__.0.1','\"Green\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.5.__assoc__.1.0','\"value\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.5.__assoc__.1.1','\"green\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.5.__assoc__.2.0','\"default\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.5.__assoc__.2.1','\"\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.6.__assoc__.0.0','\"label\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.6.__assoc__.0.1','\"Blue\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.6.__assoc__.1.0','\"value\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.6.__assoc__.1.1','\"blue\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.6.__assoc__.2.0','\"default\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.6.__assoc__.2.1','\"\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.7.__assoc__.0.0','\"label\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.7.__assoc__.0.1','\"Yellow\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.7.__assoc__.1.0','\"value\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.7.__assoc__.1.1','\"yellow\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.7.__assoc__.2.0','\"default\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.7.__assoc__.2.1','\"\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.8.__assoc__.0.0','\"label\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.8.__assoc__.0.1','\"Orange\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.8.__assoc__.1.0','\"value\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.8.__assoc__.1.1','\"orange\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.8.__assoc__.2.0','\"default\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.settings.options.8.__assoc__.2.1','\"\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.translationKeyFormat','null'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.translationMethod','\"none\"'),('fields.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1.type','\"craft\\\\fields\\\\Dropdown\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.columnSuffix','null'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.contentColumnType','\"string\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.fieldGroup','\"1bd188af-6bf7-4544-9e2e-f5e4052cefd1\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.handle','\"image\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.instructions','null'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.name','\"Image\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.searchable','false'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.allowedKinds.0','\"image\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.allowSelfRelations','false'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.allowSubfolders','false'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.allowUploads','true'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.defaultUploadLocationSource','\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.defaultUploadLocationSubpath','null'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.localizeRelations','false'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.maxRelations','1'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.minRelations','null'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.previewMode','\"full\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.restrictedDefaultUploadSubpath','null'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.restrictedLocationSource','\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.restrictedLocationSubpath','null'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.restrictFiles','true'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.restrictLocation','false'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.selectionLabel','\"Add an image\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.showSiteMenu','false'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.showUnpermittedFiles','false'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.showUnpermittedVolumes','false'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.source','null'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.sources.0','\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.targetSiteId','null'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.validateRelatedElements','false'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.settings.viewMode','\"large\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.translationKeyFormat','null'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.translationMethod','\"site\"'),('fields.9c475876-3670-4452-82c1-8274c5cbccb2.type','\"craft\\\\fields\\\\Assets\"'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.columnSuffix','\"qeshyjtt\"'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.contentColumnType','\"text\"'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.fieldGroup','\"1b39f5a2-15c0-4af0-be7c-0735aba76665\"'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.handle','\"previewText\"'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.instructions','null'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.name','\"Preview Text\"'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.searchable','false'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.settings.byteLimit','null'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.settings.charLimit','null'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.settings.code','false'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.settings.columnType','null'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.settings.initialRows','4'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.settings.multiline','true'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.settings.placeholder','null'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.settings.uiMode','\"normal\"'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.translationKeyFormat','null'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.translationMethod','\"none\"'),('fields.a9b1834c-4af7-44b5-81de-00dc035a0515.type','\"craft\\\\fields\\\\PlainText\"'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.columnSuffix','null'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.contentColumnType','\"string\"'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.fieldGroup','\"652c2871-27c1-4b30-8190-0a05255eb19b\"'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.handle','\"categories\"'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.instructions','null'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.name','\"Categories\"'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.searchable','false'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.allowLimit','false'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.allowMultipleSources','false'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.allowSelfRelations','false'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.branchLimit','null'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.localizeRelations','false'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.maxRelations','null'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.minRelations','null'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.selectionLabel','null'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.showSiteMenu','true'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.source','\"group:1b753347-9223-47d6-8349-fc1c7c290ea1\"'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.sources','\"*\"'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.targetSiteId','null'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.validateRelatedElements','false'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.settings.viewMode','null'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.translationKeyFormat','null'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.translationMethod','\"site\"'),('fields.d7d54391-72ab-425b-87f9-d3b982cbd69d.type','\"craft\\\\fields\\\\Categories\"'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.columnSuffix','null'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.contentColumnType','\"string\"'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.fieldGroup','\"dee4f4f1-d8b0-4f5c-a6ff-b5f10e5a577f\"'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.handle','\"primaryNavigation\"'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.instructions','null'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.name','\"Primary Navigation\"'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.searchable','false'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.settings.contentTable','\"{{%matrixcontent_primarynavigation}}\"'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.settings.maxBlocks','null'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.settings.minBlocks','null'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.settings.propagationKeyFormat','null'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.settings.propagationMethod','\"all\"'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.translationKeyFormat','null'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.translationMethod','\"site\"'),('fields.df62c394-9de1-4e87-baf3-56bc70321894.type','\"craft\\\\fields\\\\Matrix\"'),('fs.localAssetImages.hasUrls','true'),('fs.localAssetImages.name','\"Local Asset Images\"'),('fs.localAssetImages.settings.path','\"@assetBasePath/images\"'),('fs.localAssetImages.type','\"craft\\\\fs\\\\Local\"'),('fs.localAssetImages.url','\"@assetBaseUrl/images\"'),('graphql.schemas.36672673-27b1-406e-b81f-41a1cf1b2c7c.isPublic','true'),('graphql.schemas.36672673-27b1-406e-b81f-41a1cf1b2c7c.name','\"Public Schema\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.field','\"df62c394-9de1-4e87-baf3-56bc70321894\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.elementCondition','null'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.elements.0.fieldUid','\"8151dd06-ae31-4c45-bd7e-47e7adbafd1b\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.elements.0.label','null'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.elements.0.required','true'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.elements.0.tip','null'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.elements.0.uid','\"4ca86130-56e3-4bfe-8d4a-bcd97639809f\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.elements.0.warning','null'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.elements.0.width','100'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.name','\"Content\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.uid','\"476e1b40-d827-4c76-bb56-62f49f22a58d\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fieldLayouts.f730a51b-08c5-4ffa-bff5-bd529d8fc9ba.tabs.0.userCondition','null'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.columnSuffix','null'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.contentColumnType','\"string\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.fieldGroup','null'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.handle','\"navLink\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.instructions','null'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.name','\"Navigation Link\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.searchable','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.allowCustomText','true'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.allowTarget','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.autoNoReferrer','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.customTextMaxLength','0'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.customTextRequired','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.defaultLinkName','\"asset\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.defaultText','\"\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.enableAllLinkTypes','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.enableAriaLabel','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.enableElementCache','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.enableTitle','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.asset.allowCrossSiteLink','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.asset.allowCustomQuery','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.asset.enabled','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.asset.sources','\"*\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.category.allowCrossSiteLink','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.category.allowCustomQuery','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.category.enabled','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.category.sources','\"*\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.craftCommerce-product.allowCrossSiteLink','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.craftCommerce-product.allowCustomQuery','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.craftCommerce-product.enabled','true'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.craftCommerce-product.sources','\"*\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.custom.allowAliases','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.custom.disableValidation','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.custom.enabled','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.email.allowAliases','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.email.disableValidation','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.email.enabled','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.entry.allowCrossSiteLink','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.entry.allowCustomQuery','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.entry.enabled','true'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.entry.sources.0','\"section:3f16d68f-cda8-49f7-8564-ba9db1855669\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.site.enabled','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.site.sites','\"*\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.tel.allowAliases','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.tel.disableValidation','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.tel.enabled','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.url.allowAliases','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.url.disableValidation','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.url.enabled','true'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.user.allowCrossSiteLink','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.user.allowCustomQuery','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.user.enabled','false'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.settings.typeSettings.user.sources','\"*\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.translationKeyFormat','null'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.translationMethod','\"none\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.fields.8151dd06-ae31-4c45-bd7e-47e7adbafd1b.type','\"lenz\\\\linkfield\\\\fields\\\\LinkField\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.handle','\"menuItem\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.name','\"Menu Item\"'),('matrixBlockTypes.430acb24-9641-4661-b62e-0cdc21c0fe56.sortOrder','1'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.field','\"8aa229ec-7643-48c3-947d-9d2c1882b8f2\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.elementCondition','null'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.elements.0.fieldUid','\"a1b271b7-b466-4c87-8201-986bcb728a78\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.elements.0.label','null'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.elements.0.required','true'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.elements.0.tip','null'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.elements.0.uid','\"402e89e8-cc62-407b-bb96-30b9863899b5\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.elements.0.warning','null'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.elements.0.width','100'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.name','\"Content\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.uid','\"af7165b1-705a-4116-ab2b-64d17bebae25\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fieldLayouts.20355f91-50e8-423b-84d3-ee3698bd450c.tabs.0.userCondition','null'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.columnSuffix','\"ncfavohf\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.contentColumnType','\"text\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.fieldGroup','null'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.handle','\"richText\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.instructions','null'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.name','\"Rich Text\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.searchable','false'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.availableTransforms','\"*\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.availableVolumes','\"*\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.columnType','\"text\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.configSelectionMode','\"choose\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.defaultTransform','\"\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.manualConfig','\"\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.purifierConfig','null'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.purifyHtml','true'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.redactorConfig','\"Content.json\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.removeEmptyTags','false'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.removeInlineStyles','false'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.removeNbsp','false'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.showHtmlButtonForNonAdmins','false'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.showUnpermittedFiles','false'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.settings.uiMode','\"enlarged\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.translationKeyFormat','null'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.translationMethod','\"none\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.fields.a1b271b7-b466-4c87-8201-986bcb728a78.type','\"craft\\\\redactor\\\\Field\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.handle','\"copy\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.name','\"Copy\"'),('matrixBlockTypes.63057f3f-d739-4b88-9252-46dc4d1d283a.sortOrder','2'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.field','\"8aa229ec-7643-48c3-947d-9d2c1882b8f2\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elementCondition','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.0.fieldUid','\"0491950d-ac35-4f01-a408-29e979b6dd19\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.0.label','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.0.required','true'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.0.tip','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.0.uid','\"61f8c76a-d464-43be-8fa2-d2a8fe972a32\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.0.warning','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.0.width','100'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.1.elementCondition','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.1.fieldUid','\"4dc80b48-acd0-45f5-abdd-abe4eadce58e\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.1.instructions','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.1.label','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.1.required','false'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.1.tip','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.1.uid','\"4501929b-c21d-42cb-a2ea-485a3e9f420f\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.1.userCondition','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.1.warning','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.elements.1.width','100'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.name','\"Content\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.uid','\"b624725d-3e5e-491d-ace5-93db86a470bb\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fieldLayouts.19876a42-8f75-46f4-b62e-86c95491f049.tabs.0.userCondition','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.columnSuffix','\"jpsldsyc\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.contentColumnType','\"text\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.fieldGroup','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.handle','\"heading\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.instructions','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.name','\"Heading\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.searchable','true'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.settings.byteLimit','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.settings.charLimit','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.settings.code','false'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.settings.columnType','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.settings.initialRows','4'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.settings.multiline','false'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.settings.placeholder','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.settings.uiMode','\"normal\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.translationKeyFormat','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.translationMethod','\"none\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.0491950d-ac35-4f01-a408-29e979b6dd19.type','\"craft\\\\fields\\\\PlainText\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.columnSuffix','\"fvusojty\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.contentColumnType','\"string\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.fieldGroup','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.handle','\"size\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.instructions','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.name','\"Size\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.searchable','false'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.0.__assoc__.0.0','\"label\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.0.__assoc__.0.1','\"Small\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.0.__assoc__.1.0','\"value\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.0.__assoc__.1.1','\"small\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.0.__assoc__.2.0','\"default\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.0.__assoc__.2.1','\"\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.1.__assoc__.0.0','\"label\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.1.__assoc__.0.1','\"Medium\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.1.__assoc__.1.0','\"value\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.1.__assoc__.1.1','\"medium\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.1.__assoc__.2.0','\"default\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.1.__assoc__.2.1','\"1\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.2.__assoc__.0.0','\"label\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.2.__assoc__.0.1','\"Large\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.2.__assoc__.1.0','\"value\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.2.__assoc__.1.1','\"large\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.2.__assoc__.2.0','\"default\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.settings.options.2.__assoc__.2.1','\"\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.translationKeyFormat','null'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.translationMethod','\"none\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.fields.4dc80b48-acd0-45f5-abdd-abe4eadce58e.type','\"craft\\\\fields\\\\Dropdown\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.handle','\"heading\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.name','\"Heading\"'),('matrixBlockTypes.76a9bb5d-1499-4e0d-afff-29da6dde9d01.sortOrder','1'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.field','\"8aa229ec-7643-48c3-947d-9d2c1882b8f2\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.elementCondition','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.elements.0.elementCondition','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.elements.0.fieldUid','\"a1418b5d-f2c0-4a47-a789-f6ce3f3b0387\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.elements.0.instructions','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.elements.0.label','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.elements.0.required','true'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.elements.0.tip','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.elements.0.uid','\"e0771271-7c2f-4162-a0c9-465f9b04b34d\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.elements.0.userCondition','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.elements.0.warning','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.elements.0.width','100'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.name','\"Content\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.uid','\"658ac757-d60a-47fd-959c-5feb00c6cc61\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fieldLayouts.7e2a3200-8ee2-49b4-9fdf-ab4da4d2c2c0.tabs.0.userCondition','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.columnSuffix','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.contentColumnType','\"string\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.fieldGroup','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.handle','\"image\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.instructions','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.name','\"Image\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.searchable','false'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.allowedKinds.0','\"image\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.allowSelfRelations','false'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.allowSubfolders','false'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.allowUploads','true'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.defaultUploadLocationSource','\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.defaultUploadLocationSubpath','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.localizeRelations','false'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.maxRelations','1'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.minRelations','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.previewMode','\"full\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.restrictedDefaultUploadSubpath','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.restrictedLocationSource','\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.restrictedLocationSubpath','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.restrictFiles','true'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.restrictLocation','false'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.selectionCondition.__assoc__.1.1','\"global\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.selectionCondition.__assoc__.2.0','\"class\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.selectionLabel','\"Add an image\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.showSiteMenu','true'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.showUnpermittedFiles','false'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.showUnpermittedVolumes','false'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.source','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.sources.0','\"volume:6208c751-b47b-4315-ac54-cd1f33debd7a\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.targetSiteId','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.validateRelatedElements','false'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.settings.viewMode','\"large\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.translationKeyFormat','null'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.translationMethod','\"site\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.fields.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387.type','\"craft\\\\fields\\\\Assets\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.handle','\"image\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.name','\"Image\"'),('matrixBlockTypes.e629d7f3-088b-4db7-96f2-b32c33036226.sortOrder','3'),('meta.__names__.0491950d-ac35-4f01-a408-29e979b6dd19','\"Heading\"'),('meta.__names__.05440641-857c-492e-bbb9-37ff03c88963','\"Settings\"'),('meta.__names__.0f2c6c9a-3092-47f2-b0dc-46d8ce11c178','\"Heading\"'),('meta.__names__.148bf625-3ed8-48e1-9a43-70fc218ce67c','\"Manual\"'),('meta.__names__.1b39f5a2-15c0-4af0-be7c-0735aba76665','\"Text\"'),('meta.__names__.1b753347-9223-47d6-8349-fc1c7c290ea1','\"Product Categories\"'),('meta.__names__.1bd188af-6bf7-4544-9e2e-f5e4052cefd1','\"Assets\"'),('meta.__names__.36672673-27b1-406e-b81f-41a1cf1b2c7c','\"Public Schema\"'),('meta.__names__.3f16d68f-cda8-49f7-8564-ba9db1855669','\"Pages\"'),('meta.__names__.4188fa88-45c2-4d45-bc06-3a135bab0725','\"Catalog\"'),('meta.__names__.430acb24-9641-4661-b62e-0cdc21c0fe56','\"Menu Item\"'),('meta.__names__.47f75540-4c56-4e84-9946-3fba7ad7d9f1','\"Size\"'),('meta.__names__.4dc80b48-acd0-45f5-abdd-abe4eadce58e','\"Size\"'),('meta.__names__.56fd568a-e1bd-46d2-af2f-8a5b610e47bf','\"PayPal\"'),('meta.__names__.6208c751-b47b-4315-ac54-cd1f33debd7a','\"Images\"'),('meta.__names__.63057f3f-d739-4b88-9252-46dc4d1d283a','\"Copy\"'),('meta.__names__.652c2871-27c1-4b30-8190-0a05255eb19b','\"Relations\"'),('meta.__names__.66830969-da65-4137-bbfa-98dd011cc191','\"Preview Image\"'),('meta.__names__.6cbc0418-8b1f-411b-aa21-4937acf9bc1a','\"Stripe\"'),('meta.__names__.6e4128ef-78da-40a5-aca7-b52de59fbc3c','\"General\"'),('meta.__names__.7434a2d9-23f7-4206-84fa-f1bbad8be64f','\"Keywords\"'),('meta.__names__.76a9bb5d-1499-4e0d-afff-29da6dde9d01','\"Heading\"'),('meta.__names__.79086cc3-2cc6-4433-b251-eb6b65e115c8','\"Images\"'),('meta.__names__.7a24de90-6ecf-4386-b258-7e1b8d1671f4','\"Results per page\"'),('meta.__names__.8151dd06-ae31-4c45-bd7e-47e7adbafd1b','\"Navigation Link\"'),('meta.__names__.81d425d5-6a7f-4da9-b64d-3752b8286594','\"Other\"'),('meta.__names__.8aa229ec-7643-48c3-947d-9d2c1882b8f2','\"Content Blocks\"'),('meta.__names__.8c7805a4-e8b6-4f6b-b433-d777d7d2a6c1','\"Color\"'),('meta.__names__.8f9a9f81-cbc4-41eb-a70b-5eaeadea8840','\"Catalog\"'),('meta.__names__.96429840-47c0-490f-a057-4565f9d9d895','\"Foster Commerce Dot All 2022\"'),('meta.__names__.9685ed87-31a4-435c-9f18-ba478320023a','\"Home\"'),('meta.__names__.9c475876-3670-4452-82c1-8274c5cbccb2','\"Image\"'),('meta.__names__.a1418b5d-f2c0-4a47-a789-f6ce3f3b0387','\"Image\"'),('meta.__names__.a1b271b7-b466-4c87-8201-986bcb728a78','\"Rich Text\"'),('meta.__names__.a9b1834c-4af7-44b5-81de-00dc035a0515','\"Preview Text\"'),('meta.__names__.d3951874-9e5b-4586-979e-c7e9c5b08d92','\"Home\"'),('meta.__names__.d7d54391-72ab-425b-87f9-d3b982cbd69d','\"Categories\"'),('meta.__names__.dee4f4f1-d8b0-4f5c-a6ff-b5f10e5a577f','\"Compound\"'),('meta.__names__.df62c394-9de1-4e87-baf3-56bc70321894','\"Primary Navigation\"'),('meta.__names__.e0684c4e-4db6-49fe-b178-60bbc3750374','\"Options\"'),('meta.__names__.e4b25d4c-f8ee-4d1b-a77c-2e70560cb1d0','\"New\"'),('meta.__names__.e629d7f3-088b-4db7-96f2-b32c33036226','\"Image\"'),('meta.__names__.f8a2a825-4c38-46e8-853b-b3ee5d46969b','\"Foster Commerce Dot All 2022\"'),('meta.__names__.f96300ba-530d-42dd-94d6-b086b49639ec','\"Settings\"'),('plugins.commerce-paypal-checkout.edition','\"standard\"'),('plugins.commerce-paypal-checkout.enabled','true'),('plugins.commerce-paypal-checkout.schemaVersion','\"1.0\"'),('plugins.commerce-stripe.edition','\"standard\"'),('plugins.commerce-stripe.enabled','true'),('plugins.commerce-stripe.schemaVersion','\"3.0.0\"'),('plugins.commerce.edition','\"pro\"'),('plugins.commerce.enabled','true'),('plugins.commerce.licenseKey','\"BC5L8V3XR0KWNFDDARH9GPUI\"'),('plugins.commerce.schemaVersion','\"4.1.0\"'),('plugins.redactor.edition','\"standard\"'),('plugins.redactor.enabled','true'),('plugins.redactor.schemaVersion','\"2.3.0\"'),('plugins.seomatic.edition','\"standard\"'),('plugins.seomatic.enabled','true'),('plugins.seomatic.licenseKey','\"AC6UHUHJ1XLDA9R2BZWH8F9H\"'),('plugins.seomatic.schemaVersion','\"3.0.11\"'),('plugins.seomatic.settings.addHrefLang','true'),('plugins.seomatic.settings.addPaginatedHreflang','true'),('plugins.seomatic.settings.addXDefaultHrefLang','true'),('plugins.seomatic.settings.alwaysIncludeCanonicalUrls','false'),('plugins.seomatic.settings.cpTitlePrefix','\"⚙ \"'),('plugins.seomatic.settings.cspNonce','\"\"'),('plugins.seomatic.settings.cspScriptSrcPolicies.0.__assoc__.0.0','\"policy\"'),('plugins.seomatic.settings.cspScriptSrcPolicies.0.__assoc__.0.1','\"\'self\'\"'),('plugins.seomatic.settings.devModeCpTitlePrefix','\"&#x1f6a7;⚙ \"'),('plugins.seomatic.settings.devModeTitlePrefix','\"&#x1f6a7; \"'),('plugins.seomatic.settings.displayAnalysisSidebar','true'),('plugins.seomatic.settings.displayPreviewSidebar','true'),('plugins.seomatic.settings.enableJsonLdEndpoint','false'),('plugins.seomatic.settings.enableMetaContainerEndpoint','false'),('plugins.seomatic.settings.enableSeoFileLinkEndpoint','false'),('plugins.seomatic.settings.environment','\"live\"'),('plugins.seomatic.settings.excludeNonCanonicalUrls','false'),('plugins.seomatic.settings.generatorEnabled','true'),('plugins.seomatic.settings.headersEnabled','true'),('plugins.seomatic.settings.includeHomepageInBreadcrumbs','true'),('plugins.seomatic.settings.lowercaseCanonicalUrl','true'),('plugins.seomatic.settings.manuallySetEnvironment','false'),('plugins.seomatic.settings.maxDescriptionLength','155'),('plugins.seomatic.settings.maxTitleLength','70'),('plugins.seomatic.settings.metaCacheDuration','0'),('plugins.seomatic.settings.pluginName','\"SEO\"'),('plugins.seomatic.settings.regenerateSitemapsAutomatically','true'),('plugins.seomatic.settings.renderEnabled','true'),('plugins.seomatic.settings.separatorChar','\"|\"'),('plugins.seomatic.settings.sidebarDisplayPreviewTypes.0','\"google\"'),('plugins.seomatic.settings.sidebarDisplayPreviewTypes.1','\"twitter\"'),('plugins.seomatic.settings.sidebarDisplayPreviewTypes.2','\"facebook\"'),('plugins.seomatic.settings.siteGroupsSeparate','true'),('plugins.seomatic.settings.sitemapsEnabled','true'),('plugins.seomatic.settings.siteUrlOverride','\"\"'),('plugins.seomatic.settings.socialMediaPreviewTarget','true'),('plugins.seomatic.settings.submitSitemaps','true'),('plugins.seomatic.settings.truncateDescriptionTags','true'),('plugins.seomatic.settings.truncateTitleTags','true'),('plugins.typedlinkfield.edition','\"standard\"'),('plugins.typedlinkfield.enabled','true'),('plugins.typedlinkfield.schemaVersion','\"2.0.0\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.defaultPlacement','\"end\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.enableVersioning','true'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.handle','\"pages\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.name','\"Pages\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.previewTargets.0.__assoc__.1.1','\"{{alias(\\\"@nuxtBaseUrl\\\")}}/{uri}\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.propagationMethod','\"all\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.enabledByDefault','true'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.hasUrls','true'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.template','\"index\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.uriFormat','\"{parent.uri}/{slug}\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.structure.maxLevels','null'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.structure.uid','\"31df17bf-3c53-4a00-a46f-014c47f15584\"'),('sections.3f16d68f-cda8-49f7-8564-ba9db1855669.type','\"structure\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.defaultPlacement','\"end\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.enableVersioning','true'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.handle','\"home\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.name','\"Home\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.previewTargets.0.__assoc__.1.1','\"{{alias(\\\"@nuxtBaseUrl\\\")}}\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.propagationMethod','\"all\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.enabledByDefault','true'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.hasUrls','true'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.template','\"index\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.uriFormat','\"__home__\"'),('sections.9685ed87-31a4-435c-9f18-ba478320023a.type','\"single\"'),('sections.f96300ba-530d-42dd-94d6-b086b49639ec.defaultPlacement','\"end\"'),('sections.f96300ba-530d-42dd-94d6-b086b49639ec.enableVersioning','true'),('sections.f96300ba-530d-42dd-94d6-b086b49639ec.handle','\"settings\"'),('sections.f96300ba-530d-42dd-94d6-b086b49639ec.name','\"Settings\"'),('sections.f96300ba-530d-42dd-94d6-b086b49639ec.propagationMethod','\"all\"'),('sections.f96300ba-530d-42dd-94d6-b086b49639ec.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.enabledByDefault','true'),('sections.f96300ba-530d-42dd-94d6-b086b49639ec.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.hasUrls','true'),('sections.f96300ba-530d-42dd-94d6-b086b49639ec.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.template','null'),('sections.f96300ba-530d-42dd-94d6-b086b49639ec.siteSettings.f8a2a825-4c38-46e8-853b-b3ee5d46969b.uriFormat','\"settings\"'),('sections.f96300ba-530d-42dd-94d6-b086b49639ec.type','\"single\"'),('siteGroups.96429840-47c0-490f-a057-4565f9d9d895.name','\"Foster Commerce Dot All 2022\"'),('sites.f8a2a825-4c38-46e8-853b-b3ee5d46969b.baseUrl','\"$CRAFT_BASE_URL\"'),('sites.f8a2a825-4c38-46e8-853b-b3ee5d46969b.enabled','true'),('sites.f8a2a825-4c38-46e8-853b-b3ee5d46969b.handle','\"default\"'),('sites.f8a2a825-4c38-46e8-853b-b3ee5d46969b.hasUrls','true'),('sites.f8a2a825-4c38-46e8-853b-b3ee5d46969b.language','\"en-US\"'),('sites.f8a2a825-4c38-46e8-853b-b3ee5d46969b.name','\"Foster Commerce Dot All 2022\"'),('sites.f8a2a825-4c38-46e8-853b-b3ee5d46969b.primary','true'),('sites.f8a2a825-4c38-46e8-853b-b3ee5d46969b.siteGroup','\"96429840-47c0-490f-a057-4565f9d9d895\"'),('sites.f8a2a825-4c38-46e8-853b-b3ee5d46969b.sortOrder','1'),('system.edition','\"pro\"'),('system.live','true'),('system.name','\"Foster Commerce Dot All 2022\"'),('system.schemaVersion','\"4.0.0.9\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elementCondition','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.autocapitalize','true'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.autocomplete','false'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.autocorrect','true'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.class','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.disabled','false'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.elementCondition','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.id','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.instructions','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.label','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.max','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.min','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.name','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.orientation','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.placeholder','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.readonly','false'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.requirable','false'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.size','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.step','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.tip','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.title','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.uid','\"1085b130-4ba3-48cc-956c-a4447af07c34\"'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.userCondition','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.warning','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.0.width','100'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.attribute','\"alt\"'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.class','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.cols','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.disabled','false'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.elementCondition','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.id','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.instructions','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.label','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.name','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.orientation','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.placeholder','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.readonly','false'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.requirable','true'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.required','false'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.rows','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.tip','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.title','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\"'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.uid','\"19c17c4c-17c8-4f33-b7c7-26c197fb36f0\"'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.userCondition','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.warning','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.elements.1.width','100'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.name','\"Content\"'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.uid','\"abce75a7-89ae-4212-847b-4d5b7e806f8e\"'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fieldLayouts.f0fd58c3-d239-4f1f-87cd-2631a1628cc5.tabs.0.userCondition','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.fs','\"localAssetImages\"'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.handle','\"images\"'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.name','\"Images\"'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.sortOrder','1'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.titleTranslationKeyFormat','null'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.titleTranslationMethod','\"site\"'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.transformFs','\"\"'),('volumes.6208c751-b47b-4315-ac54-cd1f33debd7a.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `revisions` VALUES (1,3,1,1,NULL),(2,3,1,2,NULL),(3,3,1,3,NULL),(4,7,1,1,NULL),(5,7,1,2,NULL),(6,7,1,3,NULL),(7,3,1,4,NULL),(8,3,1,5,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `searchindex` VALUES (1,'username',0,1,' admin '),(1,'fullname',0,1,''),(1,'firstname',0,1,''),(1,'lastname',0,1,''),(1,'email',0,1,' admin fostercommerce com '),(1,'slug',0,1,''),(2,'slug',0,1,''),(3,'slug',0,1,' home '),(3,'title',0,1,' home '),(7,'slug',0,1,' settings '),(7,'title',0,1,' settings '),(13,'slug',0,1,' temp juvedvvcthrrrumnacemnfxsakdmptmsinlk '),(13,'title',0,1,'');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections` VALUES (1,NULL,'Home','home','single',1,'all','end','[{\"label\":\"Primary entry page\",\"urlFormat\":\"{{alias(\\\"@nuxtBaseUrl\\\")}}\",\"refresh\":\"1\"}]','2022-07-24 23:29:19','2022-07-24 23:29:19',NULL,'9685ed87-31a4-435c-9f18-ba478320023a'),(2,NULL,'Settings','settings','single',1,'all','end',NULL,'2022-07-24 23:31:19','2022-07-24 23:31:19',NULL,'f96300ba-530d-42dd-94d6-b086b49639ec'),(3,2,'Pages','pages','structure',1,'all','end','[{\"label\":\"Primary entry page\",\"urlFormat\":\"{{alias(\\\"@nuxtBaseUrl\\\")}}/{uri}\",\"refresh\":\"1\"}]','2022-07-24 23:36:04','2022-07-24 23:36:04',NULL,'3f16d68f-cda8-49f7-8564-ba9db1855669');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','index',1,'2022-07-24 23:29:19','2022-07-24 23:29:19','e4912850-ad73-4ef0-be2f-37cf98824716'),(2,2,1,1,'settings',NULL,1,'2022-07-24 23:31:19','2022-07-24 23:31:19','04087906-135f-4cc7-a320-22916dbbbb3c'),(3,3,1,1,'{parent.uri}/{slug}','index',1,'2022-07-24 23:36:04','2022-07-24 23:36:04','35f187ec-abee-4dea-9b1b-d9ebf5707ab8');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `seomatic_metabundles`
--

LOCK TABLES `seomatic_metabundles` WRITE;
/*!40000 ALTER TABLE `seomatic_metabundles` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `seomatic_metabundles` VALUES (1,'2022-07-25 00:21:43','2022-07-25 00:29:39','7dfb1371-8305-480f-b801-ca83d73db722','1.0.61','__GLOBAL_BUNDLE__',1,'__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__','__GLOBAL_BUNDLE__',NULL,'',1,'[]','2022-07-25 00:29:39','{\"language\":null,\"mainEntityOfPage\":\"WebSite\",\"seoTitle\":\"\",\"siteNamePosition\":\"after\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{{ seomatic.helper.safeCanonicalUrl() }}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{{ seomatic.meta.seoTitle }}\",\"ogSiteNamePosition\":\"none\",\"ogDescription\":\"{{ seomatic.meta.seoDescription }}\",\"ogImage\":\"\",\"ogImageWidth\":\"\",\"ogImageHeight\":\"\",\"ogImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"twitterCard\":\"summary\",\"twitterCreator\":\"{{ seomatic.site.twitterHandle }}\",\"twitterTitle\":\"{{ seomatic.meta.seoTitle }}\",\"twitterSiteNamePosition\":\"none\",\"twitterDescription\":\"{{ seomatic.meta.seoDescription }}\",\"twitterImage\":\"\",\"twitterImageWidth\":\"\",\"twitterImageHeight\":\"\",\"twitterImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"inherited\":[],\"overrides\":[]}','{\"siteName\":\"Foster Commerce Dot All 2022\",\"identity\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"creator\":{\"siteType\":\"Organization\",\"siteSubType\":\"LocalBusiness\",\"siteSpecificType\":\"\",\"computedType\":\"Organization\",\"genericName\":\"\",\"genericAlternateName\":\"\",\"genericDescription\":\"\",\"genericUrl\":\"\",\"genericImage\":\"\",\"genericImageWidth\":\"\",\"genericImageHeight\":\"\",\"genericImageIds\":[],\"genericTelephone\":\"\",\"genericEmail\":\"\",\"genericStreetAddress\":\"\",\"genericAddressLocality\":\"\",\"genericAddressRegion\":\"\",\"genericPostalCode\":\"\",\"genericAddressCountry\":\"\",\"genericGeoLatitude\":\"\",\"genericGeoLongitude\":\"\",\"personGender\":\"\",\"personBirthPlace\":\"\",\"organizationDuns\":\"\",\"organizationFounder\":\"\",\"organizationFoundingDate\":\"\",\"organizationFoundingLocation\":\"\",\"organizationContactPoints\":[],\"corporationTickerSymbol\":\"\",\"localBusinessPriceRange\":\"\",\"localBusinessOpeningHours\":[],\"restaurantServesCuisine\":\"\",\"restaurantMenuUrl\":\"\",\"restaurantReservationsUrl\":\"\"},\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":{\"twitter\":{\"siteName\":\"Twitter\",\"handle\":\"twitter\",\"url\":\"\"},\"facebook\":{\"siteName\":\"Facebook\",\"handle\":\"facebook\",\"url\":\"\"},\"wikipedia\":{\"siteName\":\"Wikipedia\",\"handle\":\"wikipedia\",\"url\":\"\"},\"linkedin\":{\"siteName\":\"LinkedIn\",\"handle\":\"linkedin\",\"url\":\"\"},\"googleplus\":{\"siteName\":\"Google+\",\"handle\":\"googleplus\",\"url\":\"\"},\"youtube\":{\"siteName\":\"YouTube\",\"handle\":\"youtube\",\"url\":\"\"},\"instagram\":{\"siteName\":\"Instagram\",\"handle\":\"instagram\",\"url\":\"\"},\"pinterest\":{\"siteName\":\"Pinterest\",\"handle\":\"pinterest\",\"url\":\"\"},\"github\":{\"siteName\":\"GitHub\",\"handle\":\"github\",\"url\":\"\"},\"vimeo\":{\"siteName\":\"Vimeo\",\"handle\":\"vimeo\",\"url\":\"\"}},\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}],\"inherited\":[],\"overrides\":[]}','{\"MetaTagContainergeneral\":{\"data\":{\"generator\":{\"charset\":\"\",\"content\":\"SEOmatic\",\"httpEquiv\":\"\",\"name\":\"generator\",\"property\":null,\"include\":true,\"key\":\"generator\",\"environment\":null,\"dependencies\":{\"config\":[\"generatorEnabled\"]},\"tagAttrs\":[]},\"keywords\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.seoKeywords }}\",\"httpEquiv\":\"\",\"name\":\"keywords\",\"property\":null,\"include\":true,\"key\":\"keywords\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"description\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.seoDescription }}\",\"httpEquiv\":\"\",\"name\":\"description\",\"property\":null,\"include\":true,\"key\":\"description\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"referrer\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.referrer }}\",\"httpEquiv\":\"\",\"name\":\"referrer\",\"property\":null,\"include\":true,\"key\":\"referrer\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"robots\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.robots }}\",\"httpEquiv\":\"\",\"name\":\"robots\",\"property\":null,\"include\":true,\"key\":\"robots\",\"environment\":{\"live\":{\"content\":\"{{ seomatic.meta.robots }}\"},\"staging\":{\"content\":\"none\"},\"local\":{\"content\":\"none\"}},\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":{\"fb:profile_id\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.facebookProfileId }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:profile_id\",\"include\":true,\"key\":\"fb:profile_id\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"fb:app_id\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.facebookAppId }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"fb:app_id\",\"include\":true,\"key\":\"fb:app_id\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:locale\":{\"charset\":\"\",\"content\":\"{{ craft.app.language |replace({\\\"-\\\": \\\"_\\\"}) }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale\",\"include\":true,\"key\":\"og:locale\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:locale:alternate\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:locale:alternate\",\"include\":true,\"key\":\"og:locale:alternate\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:site_name\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.siteName }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:site_name\",\"include\":true,\"key\":\"og:site_name\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:type\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogType }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:type\",\"include\":true,\"key\":\"og:type\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:url\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.canonicalUrl }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:url\",\"include\":true,\"key\":\"og:url\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:title\":{\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.ogSiteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogTitle }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:title\",\"include\":true,\"key\":\"og:title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:description\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogDescription }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:description\",\"include\":true,\"key\":\"og:description\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:image\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogImage }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image\",\"include\":true,\"key\":\"og:image\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"og:image:width\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogImageWidth }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:width\",\"include\":true,\"key\":\"og:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]},\"tagAttrs\":[]},\"og:image:height\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogImageHeight }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:height\",\"include\":true,\"key\":\"og:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]},\"tagAttrs\":[]},\"og:image:alt\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.ogImageDescription }}\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:image:alt\",\"include\":true,\"key\":\"og:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"og:image\"]},\"tagAttrs\":[]},\"og:see_also\":{\"charset\":\"\",\"content\":\"\",\"httpEquiv\":\"\",\"name\":\"\",\"property\":\"og:see_also\",\"include\":true,\"key\":\"og:see_also\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"facebook-site-verification\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.facebookSiteVerification }}\",\"httpEquiv\":\"\",\"name\":\"facebook-domain-verification\",\"property\":null,\"include\":true,\"key\":\"facebook-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"facebookSiteVerification\"]},\"tagAttrs\":[]}},\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":{\"twitter:card\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterCard }}\",\"httpEquiv\":\"\",\"name\":\"twitter:card\",\"property\":null,\"include\":true,\"key\":\"twitter:card\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:site\":{\"charset\":\"\",\"content\":\"@{{ seomatic.site.twitterHandle }}\",\"httpEquiv\":\"\",\"name\":\"twitter:site\",\"property\":null,\"include\":true,\"key\":\"twitter:site\",\"environment\":null,\"dependencies\":{\"site\":[\"twitterHandle\"]},\"tagAttrs\":[]},\"twitter:creator\":{\"charset\":\"\",\"content\":\"@{{ seomatic.meta.twitterCreator }}\",\"httpEquiv\":\"\",\"name\":\"twitter:creator\",\"property\":null,\"include\":true,\"key\":\"twitter:creator\",\"environment\":null,\"dependencies\":{\"meta\":[\"twitterCreator\"]},\"tagAttrs\":[]},\"twitter:title\":{\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.twitterSiteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterTitle }}\",\"httpEquiv\":\"\",\"name\":\"twitter:title\",\"property\":null,\"include\":true,\"key\":\"twitter:title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:description\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterDescription }}\",\"httpEquiv\":\"\",\"name\":\"twitter:description\",\"property\":null,\"include\":true,\"key\":\"twitter:description\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:image\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterImage }}\",\"httpEquiv\":\"\",\"name\":\"twitter:image\",\"property\":null,\"include\":true,\"key\":\"twitter:image\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"twitter:image:width\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterImageWidth }}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:width\",\"property\":null,\"include\":true,\"key\":\"twitter:image:width\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]},\"tagAttrs\":[]},\"twitter:image:height\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterImageHeight }}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:height\",\"property\":null,\"include\":true,\"key\":\"twitter:image:height\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]},\"tagAttrs\":[]},\"twitter:image:alt\":{\"charset\":\"\",\"content\":\"{{ seomatic.meta.twitterImageDescription }}\",\"httpEquiv\":\"\",\"name\":\"twitter:image:alt\",\"property\":null,\"include\":true,\"key\":\"twitter:image:alt\",\"environment\":null,\"dependencies\":{\"tag\":[\"twitter:image\"]},\"tagAttrs\":[]}},\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":{\"site\":[\"twitterHandle\"]},\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":{\"google-site-verification\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.googleSiteVerification }}\",\"httpEquiv\":\"\",\"name\":\"google-site-verification\",\"property\":null,\"include\":true,\"key\":\"google-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"googleSiteVerification\"]},\"tagAttrs\":[]},\"bing-site-verification\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.bingSiteVerification }}\",\"httpEquiv\":\"\",\"name\":\"msvalidate.01\",\"property\":null,\"include\":true,\"key\":\"bing-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"bingSiteVerification\"]},\"tagAttrs\":[]},\"pinterest-site-verification\":{\"charset\":\"\",\"content\":\"{{ seomatic.site.pinterestSiteVerification }}\",\"httpEquiv\":\"\",\"name\":\"p:domain_verify\",\"property\":null,\"include\":true,\"key\":\"pinterest-site-verification\",\"environment\":null,\"dependencies\":{\"site\":[\"pinterestSiteVerification\"]},\"tagAttrs\":[]}},\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":{\"canonical\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.meta.canonicalUrl }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"canonical\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"canonical\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"home\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"/\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"home\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"home\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]},\"author\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.helper.siteUrl(\\\"/humans.txt\\\") }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"author\",\"sizes\":\"\",\"type\":\"text/plain\",\"include\":true,\"key\":\"author\",\"environment\":null,\"dependencies\":{\"frontend_template\":[\"humans\"]},\"tagAttrs\":[]},\"publisher\":{\"crossorigin\":\"\",\"href\":\"{{ seomatic.site.googlePublisherLink }}\",\"hreflang\":\"\",\"media\":\"\",\"rel\":\"publisher\",\"sizes\":\"\",\"type\":\"\",\"include\":true,\"key\":\"publisher\",\"environment\":null,\"dependencies\":{\"site\":[\"googlePublisherLink\"]},\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":{\"gtag\":{\"name\":\"Google gtag.js\",\"description\":\"The global site tag (gtag.js) is a JavaScript tagging framework and API that allows you to send event data to AdWords, DoubleClick, and Google Analytics. Instead of having to manage multiple tags for different products, you can use gtag.js and more easily benefit from the latest tracking features and integrations as they become available. [Learn More](https://developers.google.com/gtagjs/)\",\"templatePath\":\"_frontend/scripts/gtagHead.twig\",\"templateString\":\"{% set gtagProperty = googleAnalyticsId.value ??? googleAdWordsId.value ??? dcFloodlightId.value ??? null %}\\n{% if gtagProperty %}\\nwindow.dataLayer = window.dataLayer || [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\nfunction gtag(){dataLayer.push(arguments)};\\ngtag(\'js\', new Date());\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if googleAnalyticsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'anonymize_ip\': #{ipAnonymization.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'link_attribution\': #{enhancedLinkAttribution.value ? \'true\' : \'false\'},\\\"\\n    ~ \\\"\'allow_display_features\': #{displayFeatures.value ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAnalyticsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if googleAdWordsId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ googleAdWordsId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% if dcFloodlightId.value %}\\n{%- set gtagConfig = \\\"{\\\"\\n    ~ \\\"\'send_page_view\': #{pageView ? \'true\' : \'false\'}\\\"\\n    ~ \\\"}\\\"\\n-%}\\ngtag(\'config\', \'{{ dcFloodlightId.value }}\', {{ gtagConfig }});\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/gtagBody.twig\",\"bodyTemplateString\":\"{% set gtagProperty = googleAnalyticsId.value ??? googleAdWordsId.value ??? dcFloodlightId.value ??? null %}\\n{% if gtagProperty %}\\n<script async src=\\\"{{ gtagScriptUrl.value }}?id={{ gtagProperty }}\\\"></script>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleAnalyticsId\":{\"title\":\"Google Analytics Measurement/Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `G-XXXXXXXXXX` or `UA-XXXXXX-XX`, not the entire script code. [Learn More](https://support.google.com/analytics/answer/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"googleAdWordsId\":{\"title\":\"AdWords Conversion ID\",\"instructions\":\"Only enter the ID, e.g.: `AW-XXXXXXXX`, not the entire script code. [Learn More](https://developers.google.com/adwords-remarketing-tag/)\",\"type\":\"string\",\"value\":\"\"},\"dcFloodlightId\":{\"title\":\"DoubleClick Floodlight ID\",\"instructions\":\"Only enter the ID, e.g.: `DC-XXXXXXXX`, not the entire script code. [Learn More](https://support.google.com/dcm/partner/answer/7568534)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send PageView\",\"instructions\":\"Controls whether the `gtag.js` script automatically sends a PageView to Google Analytics, AdWords, and DoubleClick Floodlight when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"In some cases, you might need to anonymize the IP addresses of hits sent to Google Analytics. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/ip-anonymization)\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Google Analytics Display Features\",\"instructions\":\"The display features plugin for gtag.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/display-features)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Google Analytics Enhanced Link Attribution\",\"instructions\":\"Enhanced link attribution improves click track reporting by automatically differentiating between multiple link clicks that have the same URL on a given page. [Learn More](https://developers.google.com/analytics/devguides/collection/gtagjs/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"gtagScriptUrl\":{\"title\":\"Google gtag.js Script URL\",\"instructions\":\"The URL to the Google gtag.js tracking script. Normally this should not be changed, unless you locally cache it. The JavaScript `dataLayer` will automatically be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/gtag/js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"gtag\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"googleTagManager\":{\"name\":\"Google Tag Manager\",\"description\":\"Google Tag Manager is a tag management system that allows you to quickly and easily update tags and code snippets on your website. Once the Tag Manager snippet has been added to your website or mobile app, you can configure tags via a web-based user interface without having to alter and deploy additional code. [Learn More](https://support.google.com/tagmanager/answer/6102821?hl=en)\",\"templatePath\":\"_frontend/scripts/googleTagManagerHead.twig\",\"templateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not seomatic.helper.isPreview %}\\n{{ dataLayerVariableName.value }} = [{% if dataLayer is defined and dataLayer %}{{ dataLayer |json_encode() |raw }}{% endif %}];\\n(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({\'gtm.start\':\\nnew Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)[0],\\nj=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src=\\n\'{{ googleTagManagerUrl.value }}?id=\'+i+dl;f.parentNode.insertBefore(j,f);\\n})(window,document,\'script\',\'{{ dataLayerVariableName.value }}\',\'{{ googleTagManagerId.value }}\');\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/googleTagManagerBody.twig\",\"bodyTemplateString\":\"{% if googleTagManagerId.value is defined and googleTagManagerId.value and not seomatic.helper.isPreview %}\\n<noscript><iframe src=\\\"{{ googleTagManagerNoScriptUrl.value }}?id={{ googleTagManagerId.value }}\\\"\\nheight=\\\"0\\\" width=\\\"0\\\" style=\\\"display:none;visibility:hidden\\\"></iframe></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"googleTagManagerId\":{\"title\":\"Google Tag Manager ID\",\"instructions\":\"Only enter the ID, e.g.: `GTM-XXXXXX`, not the entire script code. [Learn More](https://developers.google.com/tag-manager/quickstart)\",\"type\":\"string\",\"value\":\"\"},\"dataLayerVariableName\":{\"title\":\"DataLayer Variable Name\",\"instructions\":\"The name to use for the JavaScript DataLayer variable. The value of this variable will be set to the `dataLayer` Twig template variable.\",\"type\":\"string\",\"value\":\"dataLayer\"},\"googleTagManagerUrl\":{\"title\":\"Google Tag Manager Script URL\",\"instructions\":\"The URL to the Google Tag Manager script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/gtm.js\"},\"googleTagManagerNoScriptUrl\":{\"title\":\"Google Tag Manager Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Google Tag Manager `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.googletagmanager.com/ns.html\"}},\"dataLayer\":[],\"include\":false,\"key\":\"googleTagManager\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"facebookPixel\":{\"name\":\"Facebook Pixel\",\"description\":\"The Facebook pixel is an analytics tool that helps you measure the effectiveness of your advertising. You can use the Facebook pixel to understand the actions people are taking on your website and reach audiences you care about. [Learn More](https://www.facebook.com/business/help/651294705016616)\",\"templatePath\":\"_frontend/scripts/facebookPixelHead.twig\",\"templateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?\\nn.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;\\nn.push=n;n.loaded=!0;n.version=\'2.0\';n.queue=[];t=b.createElement(e);t.async=!0;\\nt.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,\\ndocument,\'script\',\'{{ facebookPixelUrl.value }}\');\\nfbq(\'init\', \'{{ facebookPixelId.value }}\');\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\nfbq(\'track\', \'PageView\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/facebookPixelBody.twig\",\"bodyTemplateString\":\"{% if facebookPixelId.value is defined and facebookPixelId.value %}\\n<noscript><img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none\\\"\\nsrc=\\\"{{ facebookPixelNoScriptUrl.value }}?id={{ facebookPixelId.value }}&ev=PageView&noscript=1\\\" /></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"facebookPixelId\":{\"title\":\"Facebook Pixel ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://developers.facebook.com/docs/facebook-pixel/api-reference)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Facebook Pixel PageView\",\"instructions\":\"Controls whether the Facebook Pixel script automatically sends a PageView to Facebook Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"facebookPixelUrl\":{\"title\":\"Facebook Pixel Script URL\",\"instructions\":\"The URL to the Facebook Pixel script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://connect.facebook.net/en_US/fbevents.js\"},\"facebookPixelNoScriptUrl\":{\"title\":\"Facebook Pixel Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Facebook Pixel `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.facebook.com/tr\"}},\"dataLayer\":[],\"include\":false,\"key\":\"facebookPixel\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"linkedInInsight\":{\"name\":\"LinkedIn Insight\",\"description\":\"The LinkedIn Insight Tag is a lightweight JavaScript tag that powers conversion tracking, retargeting, and web analytics for LinkedIn ad campaigns.\",\"templatePath\":\"_frontend/scripts/linkedInInsightHead.twig\",\"templateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n_linkedin_data_partner_id = \\\"{{ dataPartnerId.value }}\\\";\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/linkedInInsightBody.twig\",\"bodyTemplateString\":\"{% if dataPartnerId.value is defined and dataPartnerId.value %}\\n<script type=\\\"text/javascript\\\">\\n(function(){var s = document.getElementsByTagName(\\\"script\\\")[0];\\n    var b = document.createElement(\\\"script\\\");\\n    b.type = \\\"text/javascript\\\";b.async = true;\\n    b.src = \\\"{{ linkedInInsightUrl.value }}\\\";\\n    s.parentNode.insertBefore(b, s);})();\\n</script>\\n<noscript>\\n<img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none;\\\" alt=\\\"\\\" src=\\\"{{ linkedInInsightNoScriptUrl.value }}?pid={{ dataPartnerId.value }}&fmt=gif\\\" />\\n</noscript>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"dataPartnerId\":{\"title\":\"LinkedIn Data Partner ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://www.linkedin.com/help/lms/answer/65513/adding-the-linkedin-insight-tag-to-your-website?lang=en)\",\"type\":\"string\",\"value\":\"\"},\"linkedInInsightUrl\":{\"title\":\"LinkedIn Insight Script URL\",\"instructions\":\"The URL to the LinkedIn Insight script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://snap.licdn.com/li.lms-analytics/insight.min.js\"},\"linkedInInsightNoScriptUrl\":{\"title\":\"LinkedIn Insight &lt;noscript&gt; URL\",\"instructions\":\"The URL to the LinkedIn Insight `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://dc.ads.linkedin.com/collect/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"linkedInInsight\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"hubSpot\":{\"name\":\"HubSpot\",\"description\":\"If you\'re not hosting your entire website on HubSpot, or have pages on your website that are not hosted on HubSpot, you\'ll need to install the HubSpot tracking code on your non-HubSpot pages in order to capture those analytics.\",\"templatePath\":null,\"templateString\":null,\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/hubSpotBody.twig\",\"bodyTemplateString\":\"{% if hubSpotId.value is defined and hubSpotId.value %}\\n<script type=\\\"text/javascript\\\" id=\\\"hs-script-loader\\\" async defer src=\\\"{{ hubSpotUrl.value }}{{ hubSpotId.value }}.js\\\"></script>\\n{% endif %}\\n\",\"bodyPosition\":3,\"vars\":{\"hubSpotId\":{\"title\":\"HubSpot ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://knowledge.hubspot.com/articles/kcs_article/reports/install-the-hubspot-tracking-code)\",\"type\":\"string\",\"value\":\"\"},\"hubSpotUrl\":{\"title\":\"HubSpot Script URL\",\"instructions\":\"The URL to the HubSpot script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"//js.hs-scripts.com/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"hubSpot\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"pinterestTag\":{\"name\":\"Pinterest Tag\",\"description\":\"The Pinterest tag allows you to track actions people take on your website after viewing your Promoted Pin. You can use this information to measure return on ad spend (RoAS) and create audiences to target on your Promoted Pins. [Learn More](https://help.pinterest.com/en/business/article/track-conversions-with-pinterest-tag)\",\"templatePath\":\"_frontend/scripts/pinterestTagHead.twig\",\"templateString\":\"{% if pinterestTagId.value is defined and pinterestTagId.value %}\\n!function(e){if(!window.pintrk){window.pintrk=function(){window.pintrk.queue.push(\\nArray.prototype.slice.call(arguments))};var\\nn=window.pintrk;n.queue=[],n.version=\\\"3.0\\\";var\\nt=document.createElement(\\\"script\\\");t.async=!0,t.src=e;var\\nr=document.getElementsByTagName(\\\"script\\\")[0];r.parentNode.insertBefore(t,r)}}(\\\"{{ pinterestTagUrl.value }}\\\");\\npintrk(\'load\', \'{{ pinterestTagId.value }}\');\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\npintrk(\'page\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":\"_frontend/scripts/pinterestTagBody.twig\",\"bodyTemplateString\":\"{% if pinterestTagId.value is defined and pinterestTagId.value %}\\n<noscript><img height=\\\"1\\\" width=\\\"1\\\" style=\\\"display:none;\\\" alt=\\\"\\\" src=\\\"{{ pinterestTagNoScriptUrl.value }}?tid={{ pinterestTagId.value }}&noscript=1\\\" /></noscript>\\n{% endif %}\\n\",\"bodyPosition\":2,\"vars\":{\"pinterestTagId\":{\"title\":\"Pinterest Tag ID\",\"instructions\":\"Only enter the ID, e.g.: `XXXXXXXXXX`, not the entire script code. [Learn More](https://developers.pinterest.com/docs/ad-tools/conversion-tag/)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Pinterest Tag PageView\",\"instructions\":\"Controls whether the Pinterest Tag script automatically sends a PageView to when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"pinterestTagUrl\":{\"title\":\"Pinterest Tag Script URL\",\"instructions\":\"The URL to the Pinterest Tag script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://s.pinimg.com/ct/core.js\"},\"pinterestTagNoScriptUrl\":{\"title\":\"Pinterest Tag Script &lt;noscript&gt; URL\",\"instructions\":\"The URL to the Pinterest Tag `&lt;noscript&gt;`. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://ct.pinterest.com/v3/\"}},\"dataLayer\":[],\"include\":false,\"key\":\"pinterestTag\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"fathom\":{\"name\":\"Fathom\",\"description\":\"Fathom is a simple, light-weight, privacy-first alternative to Google Analytics. So, stop scrolling through pages of reports and collecting gobs of personal data about your visitors, both of which you probably don’t need. [Learn More](https://usefathom.com/)\",\"templatePath\":\"_frontend/scripts/fathomAnalytics.twig\",\"templateString\":\"{% if siteId.value is defined and siteId.value %}\\n(function() {\\nvar tag = document.createElement(\'script\');\\ntag.src = \\\"{{ scriptUrl.value }}\\\";\\ntag.defer = true;\\ntag.setAttribute(\\\"data-site\\\", \\\"{{ siteId.value | raw }}\\\");\\n{% if honorDnt.value %}\\ntag.setAttribute(\\\"data-honor-dnt\\\", \\\"true\\\");\\n{% endif %}\\n{% if disableAutoTracking.value %}\\ntag.setAttribute(\\\"data-auto\\\", \\\"false\\\");\\n{% endif %}\\n{% if ignoreCanonicals.value %}\\ntag.setAttribute(\\\"data-canonical\\\", \\\"false\\\");\\n{% endif %}\\n{% if excludedDomains.value | length %}\\ntag.setAttribute(\\\"data-excluded-domains\\\", \\\"{{ excludedDomains.value | raw }}\\\");\\n{% endif %}\\n{% if includedDomains.value | length %}\\ntag.setAttribute(\\\"data-included-domains\\\", \\\"{{ includedDomains.value | raw }}\\\");\\n{% endif %}\\nvar firstScriptTag = document.getElementsByTagName(\'script\')[0];\\nfirstScriptTag.parentNode.insertBefore(tag, firstScriptTag);\\n})();\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"siteId\":{\"title\":\"Site ID\",\"instructions\":\"Only enter the Site ID, not the entire script code. [Learn More](https://usefathom.com/support/tracking)\",\"type\":\"string\",\"value\":\"\"},\"honorDnt\":{\"title\":\"Honoring Do Not Track (DNT)\",\"instructions\":\"By default we track every visitor to your website, regardless of them having DNT turned on or not. [Learn More](https://usefathom.com/support/tracking-advanced)\",\"type\":\"bool\",\"value\":false},\"disableAutoTracking\":{\"title\":\"Disable automatic tracking\",\"instructions\":\"By default, we track a page view every time a visitor to your website loads a page with our script on it. [Learn More](https://usefathom.com/support/tracking-advanced)\",\"type\":\"bool\",\"value\":false},\"ignoreCanonicals\":{\"title\":\"Ignore canonicals\",\"instructions\":\"If there’s a canonical URL in place, then by default we use it instead of the current URL. [Learn More](https://usefathom.com/support/tracking-advanced)\",\"type\":\"bool\",\"value\":false},\"excludedDomains\":{\"title\":\"Excluded Domains\",\"instructions\":\"You exclude one or several domains, so our tracker will track things on every domain, except the ones excluded. [Learn More](https://usefathom.com/support/tracking-advanced)\",\"type\":\"string\",\"value\":\"\"},\"includedDomains\":{\"title\":\"Included Domains\",\"instructions\":\"If you want to go in the opposite direction and only track stats on a specific domain. [Learn More](https://usefathom.com/support/tracking-advanced)\",\"type\":\"string\",\"value\":\"\"},\"scriptUrl\":{\"title\":\"Fathom Script URL\",\"instructions\":\"The URL to the Fathom tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://cdn.usefathom.com/script.js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"fathom\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"matomo\":{\"name\":\"Matomo\",\"description\":\"Matomo is a Google Analytics alternative that protects your data and your customers\' privacy [Learn More](https://matomo.org/)\",\"templatePath\":\"_frontend/scripts/matomoAnalytics.twig\",\"templateString\":\"{% if siteId.value is defined and siteId.value and scriptUrl.value is defined and scriptUrl.value | length %}\\nvar _paq = window._paq = window._paq || [];\\n{% if sendPageView.value %}\\n_paq.push([\'trackPageView\']);\\n{% endif %}\\n{% if sendPageView.value %}\\n_paq.push([\'enableLinkTracking\']);\\n{% endif %}\\n(function() {\\nvar u=\\\"{{ scriptUrl.value }}\\\";\\n_paq.push([\'setTrackerUrl\', u+\'matomo.php\']);\\n_paq.push([\'setSiteId\', {{ siteId.value }}]);\\nvar d=document, g=d.createElement(\'script\'), s=d.getElementsByTagName(\'script\')[0];\\ng.type=\'text/javascript\'; g.async=true; g.src=u+\'matomo.js\'; s.parentNode.insertBefore(g,s);\\n})();\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"siteId\":{\"title\":\"Site ID\",\"instructions\":\"Only enter the Site ID, not the entire script code. [Learn More](https://developer.matomo.org/guides/tracking-javascript-guide)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Matomo PageView\",\"instructions\":\"Controls whether the Matomo script automatically sends a PageView when your pages are loaded. [Learn More](https://developer.matomo.org/api-reference/tracking-javascript)\",\"type\":\"bool\",\"value\":true},\"enableLinkTracking\":{\"title\":\"Enable Link Tracking\",\"instructions\":\"Install link tracking on all applicable link elements. [Learn More](https://developer.matomo.org/api-reference/tracking-javascript)\",\"type\":\"bool\",\"value\":true},\"scriptUrl\":{\"title\":\"Matomo Script URL\",\"instructions\":\"The URL to the Matomo tracking script. This will vary depending on whether you are using Matomo Cloud or Matomo On-Premise. [Learn More](https://developer.matomo.org/guides/tracking-javascript-guide)\",\"type\":\"string\",\"value\":\"\"}},\"dataLayer\":[],\"include\":false,\"key\":\"matomo\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"plausible\":{\"name\":\"Plausible\",\"description\":\"Plausible is a lightweight and open-source website analytics tool. No cookies and fully compliant with GDPR, CCPA and PECR. [Learn More](https://plausible.io/)\",\"templatePath\":\"_frontend/scripts/plausibleAnalytics.twig\",\"templateString\":\"{% if siteDomain.value is defined and siteDomain.value %}\\n(function() {\\nvar tag = document.createElement(\'script\');\\ntag.src = \\\"{{ scriptUrl.value }}\\\";\\ntag.defer = true;\\ntag.setAttribute(\\\"data-domain\\\", \\\"{{ siteDomain.value | raw }}\\\");\\nvar firstScriptTag = document.getElementsByTagName(\'script\')[0];\\nfirstScriptTag.parentNode.insertBefore(tag, firstScriptTag);\\n})();\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"siteDomain\":{\"title\":\"Site Domain\",\"instructions\":\"Only enter the site domain, not the entire script code. [Learn More](https://plausible.io/docs/plausible-script)\",\"type\":\"string\",\"value\":\"\"},\"scriptUrl\":{\"title\":\"Plausible Script URL\",\"instructions\":\"The URL to the Plausible tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://plausible.io/js/plausible.js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"plausible\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null},\"googleAnalytics\":{\"name\":\"Google Analytics (old)\",\"description\":\"Google Analytics gives you the digital analytics tools you need to analyze data from all touchpoints in one place, for a deeper understanding of the customer experience. You can then share the insights that matter with your whole organization. [Learn More](https://www.google.com/analytics/analytics/)\",\"templatePath\":\"_frontend/scripts/googleAnalytics.twig\",\"templateString\":\"{% if trackingId.value is defined and trackingId.value %}\\n(function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){\\n(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),\\nm=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)\\n})(window,document,\'script\',\'{{ analyticsUrl.value }}\',\'ga\');\\nga(\'create\', \'{{ trackingId.value |raw }}\', \'auto\'{% if linker.value %}, {allowLinker: true}{% endif %});\\n{% if ipAnonymization.value %}\\nga(\'set\', \'anonymizeIp\', true);\\n{% endif %}\\n{% if displayFeatures.value %}\\nga(\'require\', \'displayfeatures\');\\n{% endif %}\\n{% if ecommerce.value %}\\nga(\'require\', \'ecommerce\');\\n{% endif %}\\n{% if enhancedEcommerce.value %}\\nga(\'require\', \'ec\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linkid\');\\n{% endif %}\\n{% if enhancedLinkAttribution.value %}\\nga(\'require\', \'linker\');\\n{% endif %}\\n{% set pageView = (sendPageView.value and not seomatic.helper.isPreview) %}\\n{% if pageView %}\\nga(\'send\', \'pageview\');\\n{% endif %}\\n{% endif %}\\n\",\"position\":1,\"bodyTemplatePath\":null,\"bodyTemplateString\":null,\"bodyPosition\":2,\"vars\":{\"trackingId\":{\"title\":\"Google Analytics Tracking ID\",\"instructions\":\"Only enter the ID, e.g.: `UA-XXXXXX-XX`, not the entire script code. [Learn More](https://support.google.com/analytics/answer/1032385?hl=e)\",\"type\":\"string\",\"value\":\"\"},\"sendPageView\":{\"title\":\"Automatically send Google Analytics PageView\",\"instructions\":\"Controls whether the Google Analytics script automatically sends a PageView to Google Analytics when your pages are loaded.\",\"type\":\"bool\",\"value\":true},\"ipAnonymization\":{\"title\":\"Google Analytics IP Anonymization\",\"instructions\":\"When a customer of Analytics requests IP address anonymization, Analytics anonymizes the address as soon as technically feasible at the earliest possible stage of the collection network.\",\"type\":\"bool\",\"value\":false},\"displayFeatures\":{\"title\":\"Display Features\",\"instructions\":\"The display features plugin for analytics.js can be used to enable Advertising Features in Google Analytics, such as Remarketing, Demographics and Interest Reporting, and more. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/display-features)\",\"type\":\"bool\",\"value\":false},\"ecommerce\":{\"title\":\"Ecommerce\",\"instructions\":\"Ecommerce tracking allows you to measure the number of transactions and revenue that your website generates. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedEcommerce\":{\"title\":\"Enhanced Ecommerce\",\"instructions\":\"The enhanced ecommerce plug-in for analytics.js enables the measurement of user interactions with products on ecommerce websites across the user\'s shopping experience, including: product impressions, product clicks, viewing product details, adding a product to a shopping cart, initiating the checkout process, transactions, and refunds. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/enhanced-ecommerce)\",\"type\":\"bool\",\"value\":false},\"enhancedLinkAttribution\":{\"title\":\"Enhanced Link Attribution\",\"instructions\":\"Enhanced Link Attribution improves the accuracy of your In-Page Analytics report by automatically differentiating between multiple links to the same URL on a single page by using link element IDs. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/enhanced-link-attribution)\",\"type\":\"bool\",\"value\":false},\"linker\":{\"title\":\"Linker\",\"instructions\":\"The linker plugin simplifies the process of implementing cross-domain tracking as described in the Cross-domain Tracking guide for analytics.js. [Learn More](https://developers.google.com/analytics/devguides/collection/analyticsjs/linker)\",\"type\":\"bool\",\"value\":false},\"analyticsUrl\":{\"title\":\"Google Analytics Script URL\",\"instructions\":\"The URL to the Google Analytics tracking script. Normally this should not be changed, unless you locally cache it.\",\"type\":\"string\",\"value\":\"https://www.google-analytics.com/analytics.js\"}},\"dataLayer\":[],\"include\":false,\"key\":\"googleAnalytics\",\"environment\":{\"staging\":{\"include\":false},\"local\":{\"include\":false}},\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null}},\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"context\":\"http://schema.org\",\"type\":\"{{ seomatic.meta.mainEntityOfPage }}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"issn\":null,\"teaches\":null,\"educationalLevel\":null,\"abstract\":null,\"creativeWorkStatus\":null,\"expires\":null,\"contentReferenceTime\":null,\"material\":null,\"review\":null,\"fileFormat\":null,\"text\":null,\"translator\":null,\"award\":null,\"assesses\":null,\"copyrightNotice\":null,\"schemaVersion\":null,\"countryOfOrigin\":null,\"pattern\":null,\"accountablePerson\":null,\"funding\":null,\"educationalUse\":null,\"genre\":null,\"keywords\":null,\"position\":null,\"accessibilityHazard\":null,\"alternativeHeadline\":null,\"audience\":null,\"offers\":null,\"locationCreated\":null,\"associatedMedia\":null,\"materialExtent\":null,\"mainEntity\":null,\"copyrightHolder\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"awards\":null,\"contentLocation\":null,\"sdDatePublished\":null,\"producer\":null,\"spatial\":null,\"publisher\":null,\"sourceOrganization\":null,\"character\":null,\"funder\":null,\"exampleOfWork\":null,\"usageInfo\":null,\"provider\":null,\"sdPublisher\":null,\"comment\":null,\"accessibilityFeature\":null,\"publication\":null,\"translationOfWork\":null,\"interactivityType\":null,\"commentCount\":null,\"accessMode\":null,\"aggregateRating\":null,\"timeRequired\":null,\"typicalAgeRange\":null,\"interactionStatistic\":null,\"copyrightYear\":null,\"isBasedOn\":null,\"workExample\":null,\"publishingPrinciples\":null,\"discussionUrl\":null,\"releasedEvent\":null,\"dateCreated\":null,\"workTranslation\":null,\"editor\":null,\"creditText\":null,\"recordedAt\":null,\"editEIDR\":null,\"author\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"dateModified\":null,\"sponsor\":null,\"accessibilitySummary\":null,\"encodingFormat\":null,\"maintainer\":null,\"educationalAlignment\":null,\"acquireLicensePage\":null,\"isAccessibleForFree\":null,\"datePublished\":null,\"spatialCoverage\":null,\"sdLicense\":null,\"conditionsOfAccess\":null,\"correction\":null,\"contentRating\":null,\"size\":null,\"isPartOf\":null,\"temporal\":null,\"thumbnailUrl\":null,\"inLanguage\":\"{{ seomatic.meta.language }}\",\"license\":null,\"creator\":{\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\"},\"reviews\":null,\"about\":null,\"isFamilyFriendly\":null,\"headline\":null,\"accessibilityAPI\":null,\"publisherImprint\":null,\"isBasedOnUrl\":null,\"encodings\":null,\"interpretedAsClaim\":null,\"accessibilityControl\":null,\"citation\":null,\"version\":null,\"archivedAt\":null,\"learningResourceType\":null,\"encoding\":null,\"audio\":null,\"mentions\":null,\"accessModeSufficient\":null,\"hasPart\":null,\"temporalCoverage\":null,\"contributor\":null,\"video\":null,\"mainEntityOfPage\":\"{{ seomatic.meta.canonicalUrl }}\",\"alternateName\":null,\"name\":\"{{ seomatic.meta.seoTitle }}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":{\"type\":\"EntryPoint\",\"urlTemplate\":\"{{ seomatic.site.siteLinksSearchTarget }}\"},\"query-input\":\"{{ seomatic.helper.siteLinksQueryInput() }}\"},\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.meta.seoImage }}\"},\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"description\":\"{{ seomatic.meta.seoDescription }}\",\"subjectOf\":null,\"additionalType\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"identifier\":null},\"identity\":{\"context\":\"http://schema.org\",\"type\":\"{{ seomatic.site.identity.computedType }}\",\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\",\"graph\":null,\"include\":true,\"key\":\"identity\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"ownershipFundingInfo\":null,\"hasCredential\":null,\"founders\":null,\"telephone\":\"{{ seomatic.site.identity.genericTelephone }}\",\"review\":null,\"knowsAbout\":null,\"award\":null,\"member\":null,\"employee\":null,\"dissolutionDate\":null,\"funding\":null,\"vatID\":null,\"globalLocationNumber\":null,\"keywords\":null,\"contactPoints\":[],\"subOrganization\":null,\"awards\":null,\"numberOfEmployees\":null,\"funder\":null,\"makesOffer\":null,\"legalName\":null,\"correctionsPolicy\":null,\"aggregateRating\":null,\"interactionStatistic\":null,\"location\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{{ seomatic.site.identity.genericStreetAddress }}\",\"addressLocality\":\"{{ seomatic.site.identity.genericAddressLocality }}\",\"addressRegion\":\"{{ seomatic.site.identity.genericAddressRegion }}\",\"postalCode\":\"{{ seomatic.site.identity.genericPostalCode }}\",\"addressCountry\":\"{{ seomatic.site.identity.genericAddressCountry }}\"},\"memberOf\":null,\"publishingPrinciples\":null,\"diversityStaffingReport\":null,\"diversityPolicy\":null,\"email\":\"{{ seomatic.site.identity.genericEmail }}\",\"employees\":null,\"nonprofitStatus\":null,\"slogan\":null,\"ethicsPolicy\":null,\"brand\":null,\"sponsor\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.helper.socialTransform(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\") }}\",\"width\":\"{{ seomatic.helper.socialTransformWidth(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\") }}\",\"height\":\"{{ seomatic.helper.socialTransformHeight(seomatic.site.identity.genericImageIds[0], \\\"schema-logo\\\") }}\"},\"actionableFeedbackPolicy\":null,\"naics\":null,\"contactPoint\":null,\"serviceArea\":null,\"isicV4\":null,\"hasMerchantReturnPolicy\":null,\"hasPOS\":null,\"founder\":\"{{ seomatic.site.identity.organizationFounder }}\",\"unnamedSourcesPolicy\":null,\"foundingLocation\":\"{{ seomatic.site.identity.organizationFoundingLocation }}\",\"duns\":\"{{ seomatic.site.identity.organizationDuns }}\",\"parentOrganization\":null,\"alumni\":null,\"leiCode\":null,\"areaServed\":null,\"foundingDate\":\"{{ seomatic.site.identity.organizationFoundingDate }}\",\"knowsLanguage\":null,\"reviews\":null,\"seeks\":null,\"taxID\":null,\"owns\":null,\"hasOfferCatalog\":null,\"members\":null,\"events\":null,\"iso6523Code\":null,\"department\":null,\"faxNumber\":null,\"event\":null,\"mainEntityOfPage\":null,\"alternateName\":\"{{ seomatic.site.identity.genericAlternateName }}\",\"name\":\"{{ seomatic.site.identity.genericName }}\",\"potentialAction\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.site.identity.genericImage }}\",\"width\":\"{{ seomatic.site.identity.genericImageWidth }}\",\"height\":\"{{ seomatic.site.identity.genericImageHeight }}\"},\"url\":\"{{ seomatic.site.identity.genericUrl }}\",\"description\":\"{{ seomatic.site.identity.genericDescription }}\",\"subjectOf\":null,\"additionalType\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"identifier\":null},\"creator\":{\"context\":\"http://schema.org\",\"type\":\"{{ seomatic.site.creator.computedType }}\",\"id\":\"{{ parseEnv(seomatic.site.creator.genericUrl) }}#creator\",\"graph\":null,\"include\":true,\"key\":\"creator\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"ownershipFundingInfo\":null,\"hasCredential\":null,\"founders\":null,\"telephone\":\"{{ seomatic.site.creator.genericTelephone }}\",\"review\":null,\"knowsAbout\":null,\"award\":null,\"member\":null,\"employee\":null,\"dissolutionDate\":null,\"funding\":null,\"vatID\":null,\"globalLocationNumber\":null,\"keywords\":null,\"contactPoints\":[],\"subOrganization\":null,\"awards\":null,\"numberOfEmployees\":null,\"funder\":null,\"makesOffer\":null,\"legalName\":null,\"correctionsPolicy\":null,\"aggregateRating\":null,\"interactionStatistic\":null,\"location\":null,\"address\":{\"type\":\"PostalAddress\",\"streetAddress\":\"{{ seomatic.site.creator.genericStreetAddress }}\",\"addressLocality\":\"{{ seomatic.site.creator.genericAddressLocality }}\",\"addressRegion\":\"{{ seomatic.site.creator.genericAddressRegion }}\",\"postalCode\":\"{{ seomatic.site.creator.genericPostalCode }}\",\"addressCountry\":\"{{ seomatic.site.creator.genericAddressCountry }}\"},\"memberOf\":null,\"publishingPrinciples\":null,\"diversityStaffingReport\":null,\"diversityPolicy\":null,\"email\":\"{{ seomatic.site.creator.genericEmail }}\",\"employees\":null,\"nonprofitStatus\":null,\"slogan\":null,\"ethicsPolicy\":null,\"brand\":null,\"sponsor\":null,\"logo\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.helper.socialTransform(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\") }}\",\"width\":\"{{ seomatic.helper.socialTransformWidth(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\") }}\",\"height\":\"{{ seomatic.helper.socialTransformHeight(seomatic.site.creator.genericImageIds[0], \\\"schema-logo\\\") }}\"},\"actionableFeedbackPolicy\":null,\"naics\":null,\"contactPoint\":null,\"serviceArea\":null,\"isicV4\":null,\"hasMerchantReturnPolicy\":null,\"hasPOS\":null,\"founder\":\"{{ seomatic.site.creator.organizationFounder }}\",\"unnamedSourcesPolicy\":null,\"foundingLocation\":\"{{ seomatic.site.creator.organizationFoundingLocation }}\",\"duns\":\"{{ seomatic.site.creator.organizationDuns }}\",\"parentOrganization\":null,\"alumni\":null,\"leiCode\":null,\"areaServed\":null,\"foundingDate\":\"{{ seomatic.site.creator.organizationFoundingDate }}\",\"knowsLanguage\":null,\"reviews\":null,\"seeks\":null,\"taxID\":null,\"owns\":null,\"hasOfferCatalog\":null,\"members\":null,\"events\":null,\"iso6523Code\":null,\"department\":null,\"faxNumber\":null,\"event\":null,\"mainEntityOfPage\":null,\"alternateName\":\"{{ seomatic.site.creator.genericAlternateName }}\",\"name\":\"{{ seomatic.site.creator.genericName }}\",\"potentialAction\":null,\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.site.creator.genericImage }}\",\"width\":\"{{ seomatic.site.creator.genericImageWidth }}\",\"height\":\"{{ seomatic.site.creator.genericImageHeight }}\"},\"url\":\"{{ seomatic.site.creator.genericUrl }}\",\"description\":\"{{ seomatic.site.creator.genericDescription }}\",\"subjectOf\":null,\"additionalType\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"identifier\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{{ seomatic.meta.seoTitle }}\",\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.siteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":{\"humans\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"/* TEAM */\\n\\nCreator: {{ seomatic.site.creator.genericName ?? \\\"n/a\\\" }}\\nURL: {{ parseEnv(seomatic.site.creator.genericUrl ?? \\\"n/a\\\") }}\\nDescription: {{ seomatic.site.creator.genericDescription ?? \\\"n/a\\\" }}\\n\\n/* THANKS */\\n\\nCraft CMS - https://craftcms.com\\nPixel & Tonic - https://pixelandtonic.com\\n\\n/* SITE */\\n\\nStandards: HTML5, CSS3\\nComponents: Craft CMS 4, Yii2, PHP, JavaScript, SEOmatic\\n\",\"siteId\":null,\"include\":true,\"handle\":\"humans\",\"path\":\"humans.txt\",\"template\":\"_frontend/pages/humans.twig\",\"controller\":\"frontend-template\",\"action\":\"humans\"},\"robots\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# robots.txt for {{ seomatic.helper.baseSiteUrl(\\\"/\\\") }}\\n\\n{{ seomatic.helper.sitemapIndex() }}\\n{% switch seomatic.config.environment %}\\n\\n{% case \\\"live\\\" %}\\n\\n# live - don\'t allow web crawlers to index cpresources/ or vendor/\\n\\nUser-agent: *\\nDisallow: /cpresources/\\nDisallow: /vendor/\\nDisallow: /.env\\nDisallow: /cache/\\n\\n{% case \\\"staging\\\" %}\\n\\n# staging - disallow all\\n\\nUser-agent: *\\nDisallow: /\\n\\n{% case \\\"local\\\" %}\\n\\n# local - disallow all\\n\\nUser-agent: *\\nDisallow: /\\n\\n{% default %}\\n\\n# default - don\'t allow web crawlers to index cpresources/ or vendor/\\n\\nUser-agent: *\\nDisallow: /cpresources/\\nDisallow: /vendor/\\nDisallow: /.env\\nDisallow: /cache/\\n\\n{% endswitch %}\\n\",\"siteId\":null,\"include\":true,\"handle\":\"robots\",\"path\":\"robots.txt\",\"template\":\"_frontend/pages/robots.twig\",\"controller\":\"frontend-template\",\"action\":\"robots\"},\"ads\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# ads.txt file for {{ seomatic.helper.baseSiteUrl(\\\"/\\\") }}\\n# More info: https://support.google.com/admanager/answer/7441288?hl=en\\n{{ seomatic.helper.baseSiteUrl(\\\"/\\\") }},123,DIRECT\\n\",\"siteId\":null,\"include\":false,\"handle\":\"ads\",\"path\":\"ads.txt\",\"template\":\"_frontend/pages/ads.twig\",\"controller\":\"frontend-template\",\"action\":\"ads\"},\"security\":{\"templateVersion\":\"1.0.0\",\"templateString\":\"# security.txt file for {{ seomatic.helper.baseSiteUrl(\\\"/\\\") }} - more info: https://securitytxt.org/\\n\\n# (required) Contact email address for security issues\\nContact: mailto:user@example.com\\n\\n# (required) Expiration date for the security information herein\\nExpires: {{ date(\'+1 year\')|atom }}\\n\\n# (optional) OpenPGP key:\\nEncryption: {{ url(\'pgp-key.txt\') }}\\n\\n# (optional) Security policy page:\\nPolicy: {{ url(\'security-policy\') }}\\n\\n# (optional) Security acknowledgements page:\\nAcknowledgements: {{ url(\'hall-of-fame\') }}\\n\",\"siteId\":null,\"include\":false,\"handle\":\"security\",\"path\":\"security.txt\",\"template\":\"_frontend/pages/security.twig\",\"controller\":\"frontend-template\",\"action\":\"security\"}},\"name\":\"Frontend Templates\",\"description\":\"Templates that are rendered on the frontend\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":\"SeomaticEditableTemplate\",\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"fromCustom\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":\"\",\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":\"1\",\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":\"\",\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":\"1\",\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":\"\",\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":\"1\",\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(2,'2022-07-25 00:21:43','2022-07-25 00:29:53','fbdcfc57-3aa5-4d1e-bd31-9d5bd7614237','1.0.30','section',1,'Home','home','single',NULL,'index',1,'{\"1\":{\"id\":1,\"sectionId\":1,\"siteId\":1,\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"__home__\",\"template\":\"index\",\"language\":\"en-us\"}}','2022-07-25 00:24:17','{\"language\":null,\"mainEntityOfPage\":\"WebSite\",\"seoTitle\":\"{{ seomatic.helper.extractTextFromField(entry.title) }}\",\"siteNamePosition\":\"\",\"seoDescription\":\"{{ seomatic.helper.extractTextFromField(entry.previewText) }}\",\"seoKeywords\":\"{{ seomatic.helper.extractTextFromField(entry.keywords) }}\",\"seoImage\":\"{{ seomatic.helper.socialTransform(entry.previewImage.collect()[0], \\\"base\\\", 1, \\\"crop\\\") }}\",\"seoImageWidth\":\"{{ seomatic.helper.socialTransformWidth(entry.previewImage.collect()[0], \\\"base\\\", 1, \\\"crop\\\") }}\",\"seoImageHeight\":\"{{ seomatic.helper.socialTransformHeight(entry.previewImage.collect()[0], \\\"base\\\", 1, \\\"crop\\\") }}\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{{ entry.url }}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{{ seomatic.meta.seoTitle }}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{{ seomatic.meta.seoDescription }}\",\"ogImage\":\"{{ seomatic.helper.socialTransform(entry.previewImage.collect()[0], \\\"facebook\\\", 1, \\\"crop\\\") }}\",\"ogImageWidth\":\"{{ seomatic.helper.socialTransformWidth(entry.previewImage.collect()[0], \\\"facebook\\\", 1, \\\"crop\\\") }}\",\"ogImageHeight\":\"{{ seomatic.helper.socialTransformHeight(entry.previewImage.collect()[0], \\\"facebook\\\", 1, \\\"crop\\\") }}\",\"ogImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{{ seomatic.site.twitterHandle }}\",\"twitterTitle\":\"{{ seomatic.meta.seoTitle }}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{{ seomatic.meta.seoDescription }}\",\"twitterImage\":\"{{ seomatic.helper.socialTransform(entry.previewImage.collect()[0], seomatic.helper.twitterTransform(), 1, \\\"crop\\\") }}\",\"twitterImageWidth\":\"{{ seomatic.helper.socialTransformWidth(entry.previewImage.collect()[0], seomatic.helper.twitterTransform(), 1, \\\"crop\\\") }}\",\"twitterImageHeight\":\"{{ seomatic.helper.socialTransformHeight(entry.previewImage.collect()[0], seomatic.helper.twitterTransform(), 1, \\\"crop\\\") }}\",\"twitterImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"inherited\":[],\"overrides\":[]}','{\"siteName\":\"Foster Commerce Dot All 2022\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}],\"inherited\":[],\"overrides\":[]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"context\":\"http://schema.org\",\"type\":\"{{ seomatic.meta.mainEntityOfPage }}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"issn\":null,\"teaches\":null,\"educationalLevel\":null,\"abstract\":null,\"creativeWorkStatus\":null,\"expires\":null,\"contentReferenceTime\":null,\"material\":null,\"review\":null,\"fileFormat\":null,\"text\":null,\"translator\":null,\"award\":null,\"assesses\":null,\"copyrightNotice\":null,\"schemaVersion\":null,\"countryOfOrigin\":null,\"pattern\":null,\"accountablePerson\":null,\"funding\":null,\"educationalUse\":null,\"genre\":null,\"keywords\":null,\"position\":null,\"accessibilityHazard\":null,\"alternativeHeadline\":null,\"audience\":null,\"offers\":null,\"locationCreated\":null,\"associatedMedia\":null,\"materialExtent\":null,\"mainEntity\":null,\"copyrightHolder\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"awards\":null,\"contentLocation\":null,\"sdDatePublished\":null,\"producer\":null,\"spatial\":null,\"publisher\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#creator\"},\"sourceOrganization\":null,\"character\":null,\"funder\":null,\"exampleOfWork\":null,\"usageInfo\":null,\"provider\":null,\"sdPublisher\":null,\"comment\":null,\"accessibilityFeature\":null,\"publication\":null,\"translationOfWork\":null,\"interactivityType\":null,\"commentCount\":null,\"accessMode\":null,\"aggregateRating\":null,\"timeRequired\":null,\"typicalAgeRange\":null,\"interactionStatistic\":null,\"copyrightYear\":\"{{ entry.postDate | date(\\\"Y\\\") }}\",\"isBasedOn\":null,\"workExample\":null,\"publishingPrinciples\":null,\"discussionUrl\":null,\"releasedEvent\":null,\"dateCreated\":false,\"workTranslation\":null,\"editor\":null,\"creditText\":null,\"recordedAt\":null,\"editEIDR\":null,\"author\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"dateModified\":\"{{ entry.dateUpdated |atom }}\",\"sponsor\":null,\"accessibilitySummary\":null,\"encodingFormat\":null,\"maintainer\":null,\"educationalAlignment\":null,\"acquireLicensePage\":null,\"isAccessibleForFree\":null,\"datePublished\":\"{{ entry.postDate |atom }}\",\"spatialCoverage\":null,\"sdLicense\":null,\"conditionsOfAccess\":null,\"correction\":null,\"contentRating\":null,\"size\":null,\"isPartOf\":null,\"temporal\":null,\"thumbnailUrl\":null,\"inLanguage\":\"{{ seomatic.meta.language }}\",\"license\":null,\"creator\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#creator\"},\"reviews\":null,\"about\":null,\"isFamilyFriendly\":null,\"headline\":\"{{ seomatic.meta.seoTitle }}\",\"accessibilityAPI\":null,\"publisherImprint\":null,\"isBasedOnUrl\":null,\"encodings\":null,\"interpretedAsClaim\":null,\"accessibilityControl\":null,\"citation\":null,\"version\":null,\"archivedAt\":null,\"learningResourceType\":null,\"encoding\":null,\"audio\":null,\"mentions\":null,\"accessModeSufficient\":null,\"hasPart\":null,\"temporalCoverage\":null,\"contributor\":null,\"video\":null,\"mainEntityOfPage\":\"{{ seomatic.meta.canonicalUrl }}\",\"alternateName\":null,\"name\":\"{{ seomatic.meta.seoTitle }}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{{ seomatic.site.siteLinksSearchTarget }}\",\"query-input\":\"{{ seomatic.helper.siteLinksQueryInput() }}\"},\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.meta.seoImage }}\"},\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"description\":\"{{ seomatic.meta.seoDescription }}\",\"subjectOf\":null,\"additionalType\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"identifier\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{{ seomatic.meta.seoTitle }}\",\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.siteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromField\",\"seoDescriptionField\":\"previewText\",\"seoKeywordsSource\":\"fromField\",\"seoKeywordsField\":\"keywords\",\"seoImageIds\":\"\",\"seoImageSource\":\"fromField\",\"seoImageField\":\"previewImage\",\"seoImageTransform\":\"1\",\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"title\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":\"\",\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"image\",\"twitterImageTransform\":\"1\",\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":\"\",\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"image\",\"ogImageTransform\":\"1\",\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(3,'2022-07-25 00:21:43','2022-07-25 00:30:08','b5fab0d5-219e-4f42-92e3-8009c64e3b54','1.0.30','section',3,'Pages','pages','structure',NULL,'index',1,'{\"1\":{\"id\":3,\"sectionId\":3,\"siteId\":1,\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"{parent.uri}/{slug}\",\"template\":\"index\",\"language\":\"en-us\"}}','2022-07-25 00:30:08','{\"language\":null,\"mainEntityOfPage\":\"WebSite\",\"seoTitle\":\"{{ seomatic.helper.extractTextFromField(entry.title) }}\",\"siteNamePosition\":\"\",\"seoDescription\":\"{{ seomatic.helper.extractTextFromField(entry.previewText) }}\",\"seoKeywords\":\"{{ seomatic.helper.extractTextFromField(entry.keywords) }}\",\"seoImage\":\"{{ seomatic.helper.socialTransform(entry.previewImage.collect()[0], \\\"base\\\", 1, \\\"crop\\\") }}\",\"seoImageWidth\":\"{{ seomatic.helper.socialTransformWidth(entry.previewImage.collect()[0], \\\"base\\\", 1, \\\"crop\\\") }}\",\"seoImageHeight\":\"{{ seomatic.helper.socialTransformHeight(entry.previewImage.collect()[0], \\\"base\\\", 1, \\\"crop\\\") }}\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{{ entry.url }}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{{ seomatic.meta.seoTitle }}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{{ seomatic.meta.seoDescription }}\",\"ogImage\":\"{{ seomatic.helper.socialTransform(entry.previewImage.collect()[0], \\\"facebook\\\", 1, \\\"crop\\\") }}\",\"ogImageWidth\":\"{{ seomatic.helper.socialTransformWidth(entry.previewImage.collect()[0], \\\"facebook\\\", 1, \\\"crop\\\") }}\",\"ogImageHeight\":\"{{ seomatic.helper.socialTransformHeight(entry.previewImage.collect()[0], \\\"facebook\\\", 1, \\\"crop\\\") }}\",\"ogImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{{ seomatic.site.twitterHandle }}\",\"twitterTitle\":\"{{ seomatic.meta.seoTitle }}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{{ seomatic.meta.seoDescription }}\",\"twitterImage\":\"{{ seomatic.helper.socialTransform(entry.previewImage.collect()[0], seomatic.helper.twitterTransform(), 1, \\\"crop\\\") }}\",\"twitterImageWidth\":\"{{ seomatic.helper.socialTransformWidth(entry.previewImage.collect()[0], seomatic.helper.twitterTransform(), 1, \\\"crop\\\") }}\",\"twitterImageHeight\":\"{{ seomatic.helper.socialTransformHeight(entry.previewImage.collect()[0], seomatic.helper.twitterTransform(), 1, \\\"crop\\\") }}\",\"twitterImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"inherited\":[],\"overrides\":[]}','{\"siteName\":\"Foster Commerce Dot All 2022\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}],\"inherited\":[],\"overrides\":[]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"context\":\"http://schema.org\",\"type\":\"{{ seomatic.meta.mainEntityOfPage }}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"issn\":null,\"teaches\":null,\"educationalLevel\":null,\"abstract\":null,\"creativeWorkStatus\":null,\"expires\":null,\"contentReferenceTime\":null,\"material\":null,\"review\":null,\"fileFormat\":null,\"text\":null,\"translator\":null,\"award\":null,\"assesses\":null,\"copyrightNotice\":null,\"schemaVersion\":null,\"countryOfOrigin\":null,\"pattern\":null,\"accountablePerson\":null,\"funding\":null,\"educationalUse\":null,\"genre\":null,\"keywords\":null,\"position\":null,\"accessibilityHazard\":null,\"alternativeHeadline\":null,\"audience\":null,\"offers\":null,\"locationCreated\":null,\"associatedMedia\":null,\"materialExtent\":null,\"mainEntity\":null,\"copyrightHolder\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"awards\":null,\"contentLocation\":null,\"sdDatePublished\":null,\"producer\":null,\"spatial\":null,\"publisher\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#creator\"},\"sourceOrganization\":null,\"character\":null,\"funder\":null,\"exampleOfWork\":null,\"usageInfo\":null,\"provider\":null,\"sdPublisher\":null,\"comment\":null,\"accessibilityFeature\":null,\"publication\":null,\"translationOfWork\":null,\"interactivityType\":null,\"commentCount\":null,\"accessMode\":null,\"aggregateRating\":null,\"timeRequired\":null,\"typicalAgeRange\":null,\"interactionStatistic\":null,\"copyrightYear\":\"{{ entry.postDate | date(\\\"Y\\\") }}\",\"isBasedOn\":null,\"workExample\":null,\"publishingPrinciples\":null,\"discussionUrl\":null,\"releasedEvent\":null,\"dateCreated\":false,\"workTranslation\":null,\"editor\":null,\"creditText\":null,\"recordedAt\":null,\"editEIDR\":null,\"author\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"dateModified\":\"{{ entry.dateUpdated |atom }}\",\"sponsor\":null,\"accessibilitySummary\":null,\"encodingFormat\":null,\"maintainer\":null,\"educationalAlignment\":null,\"acquireLicensePage\":null,\"isAccessibleForFree\":null,\"datePublished\":\"{{ entry.postDate |atom }}\",\"spatialCoverage\":null,\"sdLicense\":null,\"conditionsOfAccess\":null,\"correction\":null,\"contentRating\":null,\"size\":null,\"isPartOf\":null,\"temporal\":null,\"thumbnailUrl\":null,\"inLanguage\":\"{{ seomatic.meta.language }}\",\"license\":null,\"creator\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#creator\"},\"reviews\":null,\"about\":null,\"isFamilyFriendly\":null,\"headline\":\"{{ seomatic.meta.seoTitle }}\",\"accessibilityAPI\":null,\"publisherImprint\":null,\"isBasedOnUrl\":null,\"encodings\":null,\"interpretedAsClaim\":null,\"accessibilityControl\":null,\"citation\":null,\"version\":null,\"archivedAt\":null,\"learningResourceType\":null,\"encoding\":null,\"audio\":null,\"mentions\":null,\"accessModeSufficient\":null,\"hasPart\":null,\"temporalCoverage\":null,\"contributor\":null,\"video\":null,\"mainEntityOfPage\":\"{{ seomatic.meta.canonicalUrl }}\",\"alternateName\":null,\"name\":\"{{ seomatic.meta.seoTitle }}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{{ seomatic.site.siteLinksSearchTarget }}\",\"query-input\":\"{{ seomatic.helper.siteLinksQueryInput() }}\"},\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.meta.seoImage }}\"},\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"description\":\"{{ seomatic.meta.seoDescription }}\",\"subjectOf\":null,\"additionalType\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"identifier\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{{ seomatic.meta.seoTitle }}\",\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.siteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromField\",\"seoDescriptionField\":\"previewText\",\"seoKeywordsSource\":\"fromField\",\"seoKeywordsField\":\"keywords\",\"seoImageIds\":\"\",\"seoImageSource\":\"fromField\",\"seoImageField\":\"previewImage\",\"seoImageTransform\":\"1\",\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"title\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":\"\",\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"image\",\"twitterImageTransform\":\"1\",\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":\"\",\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"image\",\"ogImageTransform\":\"1\",\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(4,'2022-07-25 00:21:43','2022-07-25 00:21:43','6973a35c-8aa7-4f6b-a8b7-98943a90c8b7','1.0.30','section',2,'Settings','settings','single',NULL,'',1,'{\"1\":{\"id\":2,\"sectionId\":2,\"siteId\":1,\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"settings\",\"template\":null,\"language\":\"en-us\"}}','2022-07-24 23:40:26','{\"language\":null,\"mainEntityOfPage\":\"WebPage\",\"seoTitle\":\"{{ entry.title }}\",\"siteNamePosition\":\"\",\"seoDescription\":\"\",\"seoKeywords\":\"\",\"seoImage\":\"\",\"seoImageWidth\":\"\",\"seoImageHeight\":\"\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{{ entry.url }}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{{ seomatic.meta.seoTitle }}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{{ seomatic.meta.seoDescription }}\",\"ogImage\":\"{{ seomatic.meta.seoImage }}\",\"ogImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"ogImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"ogImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{{ seomatic.site.twitterHandle }}\",\"twitterTitle\":\"{{ seomatic.meta.seoTitle }}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{{ seomatic.meta.seoDescription }}\",\"twitterImage\":\"{{ seomatic.meta.seoImage }}\",\"twitterImageWidth\":\"{{ seomatic.meta.seoImageWidth }}\",\"twitterImageHeight\":\"{{ seomatic.meta.seoImageHeight }}\",\"twitterImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"inherited\":[],\"overrides\":[]}','{\"siteName\":\"Foster Commerce Dot All 2022\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}],\"inherited\":[],\"overrides\":[]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"context\":\"http://schema.org\",\"type\":\"{{ seomatic.meta.mainEntityOfPage }}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"lastReviewed\":null,\"specialty\":null,\"primaryImageOfPage\":null,\"significantLink\":null,\"reviewedBy\":null,\"mainContentOfPage\":null,\"relatedLink\":null,\"speakable\":null,\"breadcrumb\":null,\"significantLinks\":null,\"teaches\":null,\"educationalLevel\":null,\"abstract\":null,\"creativeWorkStatus\":null,\"expires\":null,\"contentReferenceTime\":null,\"material\":null,\"review\":null,\"fileFormat\":null,\"text\":null,\"translator\":null,\"award\":null,\"assesses\":null,\"copyrightNotice\":null,\"schemaVersion\":null,\"countryOfOrigin\":null,\"pattern\":null,\"accountablePerson\":null,\"funding\":null,\"educationalUse\":null,\"genre\":null,\"keywords\":null,\"position\":null,\"accessibilityHazard\":null,\"alternativeHeadline\":null,\"audience\":null,\"offers\":null,\"locationCreated\":null,\"associatedMedia\":null,\"materialExtent\":null,\"mainEntity\":null,\"copyrightHolder\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"awards\":null,\"contentLocation\":null,\"sdDatePublished\":null,\"producer\":null,\"spatial\":null,\"publisher\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#creator\"},\"sourceOrganization\":null,\"character\":null,\"funder\":null,\"exampleOfWork\":null,\"usageInfo\":null,\"provider\":null,\"sdPublisher\":null,\"comment\":null,\"accessibilityFeature\":null,\"publication\":null,\"translationOfWork\":null,\"interactivityType\":null,\"commentCount\":null,\"accessMode\":null,\"aggregateRating\":null,\"timeRequired\":null,\"typicalAgeRange\":null,\"interactionStatistic\":null,\"copyrightYear\":\"{{ entry.postDate | date(\\\"Y\\\") }}\",\"isBasedOn\":null,\"workExample\":null,\"publishingPrinciples\":null,\"discussionUrl\":null,\"releasedEvent\":null,\"dateCreated\":false,\"workTranslation\":null,\"editor\":null,\"creditText\":null,\"recordedAt\":null,\"editEIDR\":null,\"author\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"dateModified\":\"{{ entry.dateUpdated |atom }}\",\"sponsor\":null,\"accessibilitySummary\":null,\"encodingFormat\":null,\"maintainer\":null,\"educationalAlignment\":null,\"acquireLicensePage\":null,\"isAccessibleForFree\":null,\"datePublished\":\"{{ entry.postDate |atom }}\",\"spatialCoverage\":null,\"sdLicense\":null,\"conditionsOfAccess\":null,\"correction\":null,\"contentRating\":null,\"size\":null,\"isPartOf\":null,\"temporal\":null,\"thumbnailUrl\":null,\"inLanguage\":\"{{ seomatic.meta.language }}\",\"license\":null,\"creator\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#creator\"},\"reviews\":null,\"about\":null,\"isFamilyFriendly\":null,\"headline\":\"{{ seomatic.meta.seoTitle }}\",\"accessibilityAPI\":null,\"publisherImprint\":null,\"isBasedOnUrl\":null,\"encodings\":null,\"interpretedAsClaim\":null,\"accessibilityControl\":null,\"citation\":null,\"version\":null,\"archivedAt\":null,\"learningResourceType\":null,\"encoding\":null,\"audio\":null,\"mentions\":null,\"accessModeSufficient\":null,\"hasPart\":null,\"temporalCoverage\":null,\"contributor\":null,\"video\":null,\"mainEntityOfPage\":\"{{ seomatic.meta.canonicalUrl }}\",\"alternateName\":null,\"name\":\"{{ seomatic.meta.seoTitle }}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{{ seomatic.site.siteLinksSearchTarget }}\",\"query-input\":\"{{ seomatic.helper.siteLinksQueryInput() }}\"},\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.meta.seoImage }}\"},\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"description\":\"{{ seomatic.meta.seoDescription }}\",\"subjectOf\":null,\"additionalType\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"identifier\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{{ seomatic.meta.seoTitle }}\",\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.siteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromCustom\",\"seoTitleField\":\"\",\"siteNamePositionSource\":\"fromCustom\",\"seoDescriptionSource\":\"fromCustom\",\"seoDescriptionField\":\"\",\"seoKeywordsSource\":\"fromCustom\",\"seoKeywordsField\":\"\",\"seoImageIds\":[],\"seoImageSource\":\"fromAsset\",\"seoImageField\":\"\",\"seoImageTransform\":true,\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":[],\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"\",\"twitterImageTransform\":true,\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":[],\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"\",\"ogImageTransform\":true,\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(5,'2022-07-25 00:21:43','2022-07-25 00:30:41','6c305b4a-22d8-428d-b447-8a06c92e819c','1.0.36','product',1,'Catalog','catalog','product',NULL,'index',1,'{\"1\":{\"id\":1,\"productTypeId\":1,\"siteId\":1,\"hasUrls\":true,\"uriFormat\":\"{{alias(\\\"@nuxtBaseUrl\\\")}}/catalog/{slug}\",\"template\":\"index\",\"uriFormatIsRequired\":true,\"language\":\"en-us\"}}','2022-07-25 00:30:41','{\"language\":null,\"mainEntityOfPage\":\"Product\",\"seoTitle\":\"{{ seomatic.helper.extractTextFromField(product.title) }}\",\"siteNamePosition\":\"\",\"seoDescription\":\"{{ seomatic.helper.extractTextFromField(product.previewText) }}\",\"seoKeywords\":\"{{ seomatic.helper.extractTextFromField(product.keywords) }}\",\"seoImage\":\"{{ seomatic.helper.socialTransform(product.previewImage.collect()[0], \\\"base\\\", 1, \\\"crop\\\") }}\",\"seoImageWidth\":\"{{ seomatic.helper.socialTransformWidth(product.previewImage.collect()[0], \\\"base\\\", 1, \\\"crop\\\") }}\",\"seoImageHeight\":\"{{ seomatic.helper.socialTransformHeight(product.previewImage.collect()[0], \\\"base\\\", 1, \\\"crop\\\") }}\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{{ product.url }}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{{ seomatic.meta.seoTitle }}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{{ seomatic.meta.seoDescription }}\",\"ogImage\":\"{{ seomatic.helper.socialTransform(product.previewImage.collect()[0], \\\"facebook\\\", 1, \\\"crop\\\") }}\",\"ogImageWidth\":\"{{ seomatic.helper.socialTransformWidth(product.previewImage.collect()[0], \\\"facebook\\\", 1, \\\"crop\\\") }}\",\"ogImageHeight\":\"{{ seomatic.helper.socialTransformHeight(product.previewImage.collect()[0], \\\"facebook\\\", 1, \\\"crop\\\") }}\",\"ogImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{{ seomatic.site.twitterHandle }}\",\"twitterTitle\":\"{{ seomatic.meta.seoTitle }}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{{ seomatic.meta.seoDescription }}\",\"twitterImage\":\"{{ seomatic.helper.socialTransform(product.previewImage.collect()[0], seomatic.helper.twitterTransform(), 1, \\\"crop\\\") }}\",\"twitterImageWidth\":\"{{ seomatic.helper.socialTransformWidth(product.previewImage.collect()[0], seomatic.helper.twitterTransform(), 1, \\\"crop\\\") }}\",\"twitterImageHeight\":\"{{ seomatic.helper.socialTransformHeight(product.previewImage.collect()[0], seomatic.helper.twitterTransform(), 1, \\\"crop\\\") }}\",\"twitterImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"inherited\":[],\"overrides\":[]}','{\"siteName\":\"Foster Commerce Dot All 2022\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}],\"inherited\":[],\"overrides\":[]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"context\":\"http://schema.org\",\"type\":\"{{ seomatic.meta.mainEntityOfPage }}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"isAccessoryOrSparePartFor\":null,\"hasAdultConsideration\":null,\"gtin12\":null,\"nsn\":null,\"material\":null,\"review\":null,\"award\":null,\"width\":null,\"countryOfOrigin\":null,\"pattern\":null,\"category\":null,\"funding\":null,\"mpn\":null,\"height\":null,\"keywords\":null,\"purchaseDate\":null,\"hasEnergyConsumptionDetails\":null,\"audience\":null,\"offers\":{\"type\":\"Offer\",\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"price\":\"{{ product.getDefaultVariant().getPrice()|number_format(2, \\\".\\\", \\\"\\\") }}\",\"priceCurrency\":\"{{ craft.commerce.paymentCurrencies.primaryPaymentCurrencyIso() }}\",\"offeredBy\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"seller\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"availability\":\"http://schema.org/{% if product.hasUnlimitedStock or product.totalStock > 0 %}InStock{% else %}OutOfStock{% endif %}\"},\"productionDate\":null,\"itemCondition\":null,\"awards\":null,\"gtin\":null,\"productID\":null,\"countryOfAssembly\":null,\"color\":null,\"aggregateRating\":null,\"isSimilarTo\":null,\"depth\":null,\"countryOfLastProcessing\":null,\"isVariantOf\":null,\"slogan\":null,\"brand\":null,\"manufacturer\":null,\"hasMeasurement\":null,\"isConsumableFor\":null,\"logo\":null,\"gtin8\":null,\"sku\":\"{{ product.getDefaultVariant().getSku() }}\",\"inProductGroupWithID\":null,\"model\":null,\"hasMerchantReturnPolicy\":null,\"releaseDate\":null,\"gtin14\":null,\"weight\":null,\"size\":null,\"additionalProperty\":null,\"gtin13\":null,\"reviews\":null,\"isFamilyFriendly\":null,\"isRelatedTo\":null,\"mainEntityOfPage\":\"{{ seomatic.meta.canonicalUrl }}\",\"alternateName\":null,\"name\":\"{{ seomatic.meta.seoTitle }}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{{ seomatic.site.siteLinksSearchTarget }}\",\"query-input\":\"{{ seomatic.helper.siteLinksQueryInput() }}\"},\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.meta.seoImage }}\"},\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"description\":\"{{ seomatic.meta.seoDescription }}\",\"subjectOf\":null,\"additionalType\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"identifier\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{{ seomatic.meta.seoTitle }}\",\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.siteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"Product\",\"siteSubType\":\"\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromField\",\"seoDescriptionField\":\"previewText\",\"seoKeywordsSource\":\"fromField\",\"seoKeywordsField\":\"keywords\",\"seoImageIds\":\"\",\"seoImageSource\":\"fromField\",\"seoImageField\":\"previewImage\",\"seoImageTransform\":\"1\",\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"title\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"sameAsGlobal\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":\"\",\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"previewImage\",\"twitterImageTransform\":\"1\",\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"sameAsGlobal\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":\"\",\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"previewImage\",\"ogImageTransform\":\"1\",\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}'),(6,'2022-07-25 00:28:12','2022-07-25 00:30:08','ef9c7116-1ad6-495d-803c-f3a7752fa269','1.0.30','section',3,'Pages','pages','structure',3,'index',1,'{\"1\":{\"id\":3,\"sectionId\":3,\"siteId\":1,\"enabledByDefault\":true,\"hasUrls\":true,\"uriFormat\":\"{parent.uri}/{slug}\",\"template\":\"index\",\"language\":\"en-us\"}}','2022-07-25 00:30:08','{\"language\":null,\"mainEntityOfPage\":\"WebSite\",\"seoTitle\":\"{{ seomatic.helper.extractTextFromField(entry.title) }}\",\"siteNamePosition\":\"\",\"seoDescription\":\"{{ seomatic.helper.extractTextFromField(entry.previewText) }}\",\"seoKeywords\":\"{{ seomatic.helper.extractTextFromField(entry.keywords) }}\",\"seoImage\":\"{{ seomatic.helper.socialTransform(entry.previewImage.collect()[0], \\\"base\\\", 1, \\\"crop\\\") }}\",\"seoImageWidth\":\"{{ seomatic.helper.socialTransformWidth(entry.previewImage.collect()[0], \\\"base\\\", 1, \\\"crop\\\") }}\",\"seoImageHeight\":\"{{ seomatic.helper.socialTransformHeight(entry.previewImage.collect()[0], \\\"base\\\", 1, \\\"crop\\\") }}\",\"seoImageDescription\":\"\",\"canonicalUrl\":\"{{ entry.url }}\",\"robots\":\"all\",\"ogType\":\"website\",\"ogTitle\":\"{{ seomatic.meta.seoTitle }}\",\"ogSiteNamePosition\":\"\",\"ogDescription\":\"{{ seomatic.meta.seoDescription }}\",\"ogImage\":\"{{ seomatic.helper.socialTransform(entry.previewImage.collect()[0], \\\"facebook\\\", 1, \\\"crop\\\") }}\",\"ogImageWidth\":\"{{ seomatic.helper.socialTransformWidth(entry.previewImage.collect()[0], \\\"facebook\\\", 1, \\\"crop\\\") }}\",\"ogImageHeight\":\"{{ seomatic.helper.socialTransformHeight(entry.previewImage.collect()[0], \\\"facebook\\\", 1, \\\"crop\\\") }}\",\"ogImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"twitterCard\":\"summary_large_image\",\"twitterCreator\":\"{{ seomatic.site.twitterHandle }}\",\"twitterTitle\":\"{{ seomatic.meta.seoTitle }}\",\"twitterSiteNamePosition\":\"\",\"twitterDescription\":\"{{ seomatic.meta.seoDescription }}\",\"twitterImage\":\"{{ seomatic.helper.socialTransform(entry.previewImage.collect()[0], seomatic.helper.twitterTransform(), 1, \\\"crop\\\") }}\",\"twitterImageWidth\":\"{{ seomatic.helper.socialTransformWidth(entry.previewImage.collect()[0], seomatic.helper.twitterTransform(), 1, \\\"crop\\\") }}\",\"twitterImageHeight\":\"{{ seomatic.helper.socialTransformHeight(entry.previewImage.collect()[0], seomatic.helper.twitterTransform(), 1, \\\"crop\\\") }}\",\"twitterImageDescription\":\"{{ seomatic.meta.seoImageDescription }}\",\"inherited\":[],\"overrides\":[]}','{\"siteName\":\"Foster Commerce Dot All 2022\",\"identity\":null,\"creator\":null,\"twitterHandle\":\"\",\"facebookProfileId\":\"\",\"facebookAppId\":\"\",\"googleSiteVerification\":\"\",\"bingSiteVerification\":\"\",\"pinterestSiteVerification\":\"\",\"facebookSiteVerification\":\"\",\"sameAsLinks\":[],\"siteLinksSearchTarget\":\"\",\"siteLinksQueryInput\":\"\",\"referrer\":\"no-referrer-when-downgrade\",\"additionalSitemapUrls\":[],\"additionalSitemapUrlsDateUpdated\":null,\"additionalSitemaps\":[]}','{\"sitemapUrls\":true,\"sitemapAssets\":true,\"sitemapFiles\":true,\"sitemapAltLinks\":true,\"sitemapChangeFreq\":\"weekly\",\"sitemapPriority\":0.5,\"sitemapLimit\":null,\"structureDepth\":null,\"sitemapImageFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"caption\",\"field\":\"\"},{\"property\":\"geo_location\",\"field\":\"\"},{\"property\":\"license\",\"field\":\"\"}],\"sitemapVideoFieldMap\":[{\"property\":\"title\",\"field\":\"title\"},{\"property\":\"description\",\"field\":\"\"},{\"property\":\"thumbnailLoc\",\"field\":\"\"},{\"property\":\"duration\",\"field\":\"\"},{\"property\":\"category\",\"field\":\"\"}],\"inherited\":[],\"overrides\":[]}','{\"MetaTagContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"General Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContaineropengraph\":{\"data\":[],\"name\":\"Facebook\",\"description\":\"Facebook OpenGraph Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"opengraph\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainertwitter\":{\"data\":[],\"name\":\"Twitter\",\"description\":\"Twitter Card Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"twitter\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTagContainermiscellaneous\":{\"data\":[],\"name\":\"Miscellaneous\",\"description\":\"Miscellaneous Meta Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTagContainer\",\"handle\":\"miscellaneous\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaLinkContainergeneral\":{\"data\":[],\"name\":\"General\",\"description\":\"Link Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaLinkContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaScriptContainergeneral\":{\"data\":[],\"position\":1,\"name\":\"General\",\"description\":\"Script Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaScriptContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaJsonLdContainergeneral\":{\"data\":{\"mainEntityOfPage\":{\"context\":\"http://schema.org\",\"type\":\"{{ seomatic.meta.mainEntityOfPage }}\",\"id\":null,\"graph\":null,\"include\":true,\"key\":\"mainEntityOfPage\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[],\"nonce\":null,\"issn\":null,\"teaches\":null,\"educationalLevel\":null,\"abstract\":null,\"creativeWorkStatus\":null,\"expires\":null,\"contentReferenceTime\":null,\"material\":null,\"review\":null,\"fileFormat\":null,\"text\":null,\"translator\":null,\"award\":null,\"assesses\":null,\"copyrightNotice\":null,\"schemaVersion\":null,\"countryOfOrigin\":null,\"pattern\":null,\"accountablePerson\":null,\"funding\":null,\"educationalUse\":null,\"genre\":null,\"keywords\":null,\"position\":null,\"accessibilityHazard\":null,\"alternativeHeadline\":null,\"audience\":null,\"offers\":null,\"locationCreated\":null,\"associatedMedia\":null,\"materialExtent\":null,\"mainEntity\":null,\"copyrightHolder\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"awards\":null,\"contentLocation\":null,\"sdDatePublished\":null,\"producer\":null,\"spatial\":null,\"publisher\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#creator\"},\"sourceOrganization\":null,\"character\":null,\"funder\":null,\"exampleOfWork\":null,\"usageInfo\":null,\"provider\":null,\"sdPublisher\":null,\"comment\":null,\"accessibilityFeature\":null,\"publication\":null,\"translationOfWork\":null,\"interactivityType\":null,\"commentCount\":null,\"accessMode\":null,\"aggregateRating\":null,\"timeRequired\":null,\"typicalAgeRange\":null,\"interactionStatistic\":null,\"copyrightYear\":\"{{ entry.postDate | date(\\\"Y\\\") }}\",\"isBasedOn\":null,\"workExample\":null,\"publishingPrinciples\":null,\"discussionUrl\":null,\"releasedEvent\":null,\"dateCreated\":false,\"workTranslation\":null,\"editor\":null,\"creditText\":null,\"recordedAt\":null,\"editEIDR\":null,\"author\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#identity\"},\"dateModified\":\"{{ entry.dateUpdated |atom }}\",\"sponsor\":null,\"accessibilitySummary\":null,\"encodingFormat\":null,\"maintainer\":null,\"educationalAlignment\":null,\"acquireLicensePage\":null,\"isAccessibleForFree\":null,\"datePublished\":\"{{ entry.postDate |atom }}\",\"spatialCoverage\":null,\"sdLicense\":null,\"conditionsOfAccess\":null,\"correction\":null,\"contentRating\":null,\"size\":null,\"isPartOf\":null,\"temporal\":null,\"thumbnailUrl\":null,\"inLanguage\":\"{{ seomatic.meta.language }}\",\"license\":null,\"creator\":{\"id\":\"{{ parseEnv(seomatic.site.identity.genericUrl) }}#creator\"},\"reviews\":null,\"about\":null,\"isFamilyFriendly\":null,\"headline\":\"{{ seomatic.meta.seoTitle }}\",\"accessibilityAPI\":null,\"publisherImprint\":null,\"isBasedOnUrl\":null,\"encodings\":null,\"interpretedAsClaim\":null,\"accessibilityControl\":null,\"citation\":null,\"version\":null,\"archivedAt\":null,\"learningResourceType\":null,\"encoding\":null,\"audio\":null,\"mentions\":null,\"accessModeSufficient\":null,\"hasPart\":null,\"temporalCoverage\":null,\"contributor\":null,\"video\":null,\"mainEntityOfPage\":\"{{ seomatic.meta.canonicalUrl }}\",\"alternateName\":null,\"name\":\"{{ seomatic.meta.seoTitle }}\",\"potentialAction\":{\"type\":\"SearchAction\",\"target\":\"{{ seomatic.site.siteLinksSearchTarget }}\",\"query-input\":\"{{ seomatic.helper.siteLinksQueryInput() }}\"},\"image\":{\"type\":\"ImageObject\",\"url\":\"{{ seomatic.meta.seoImage }}\"},\"url\":\"{{ seomatic.meta.canonicalUrl }}\",\"description\":\"{{ seomatic.meta.seoDescription }}\",\"subjectOf\":null,\"additionalType\":null,\"disambiguatingDescription\":null,\"sameAs\":null,\"identifier\":null}},\"name\":\"General\",\"description\":\"JsonLd Tags\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaJsonLdContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false},\"MetaTitleContainergeneral\":{\"data\":{\"title\":{\"title\":\"{{ seomatic.meta.seoTitle }}\",\"siteName\":\"{{ seomatic.site.siteName }}\",\"siteNamePosition\":\"{{ seomatic.meta.siteNamePosition }}\",\"separatorChar\":\"{{ seomatic.config.separatorChar }}\",\"include\":true,\"key\":\"title\",\"environment\":null,\"dependencies\":null,\"tagAttrs\":[]}},\"name\":\"General\",\"description\":\"Meta Title Tag\",\"class\":\"nystudio107\\\\seomatic\\\\models\\\\MetaTitleContainer\",\"handle\":\"general\",\"include\":true,\"dependencies\":[],\"clearCache\":false}}','[]','{\"data\":[],\"name\":null,\"description\":null,\"class\":\"nystudio107\\\\seomatic\\\\models\\\\FrontendTemplateContainer\",\"handle\":null,\"include\":true,\"dependencies\":null,\"clearCache\":false}','{\"siteType\":\"CreativeWork\",\"siteSubType\":\"WebSite\",\"siteSpecificType\":\"\",\"seoTitleSource\":\"fromField\",\"seoTitleField\":\"title\",\"siteNamePositionSource\":\"sameAsGlobal\",\"seoDescriptionSource\":\"fromField\",\"seoDescriptionField\":\"previewText\",\"seoKeywordsSource\":\"fromField\",\"seoKeywordsField\":\"keywords\",\"seoImageIds\":\"\",\"seoImageSource\":\"fromField\",\"seoImageField\":\"previewImage\",\"seoImageTransform\":\"1\",\"seoImageTransformMode\":\"crop\",\"seoImageDescriptionSource\":\"fromCustom\",\"seoImageDescriptionField\":\"title\",\"twitterCreatorSource\":\"sameAsSite\",\"twitterCreatorField\":\"\",\"twitterTitleSource\":\"sameAsSeo\",\"twitterTitleField\":\"\",\"twitterSiteNamePositionSource\":\"fromCustom\",\"twitterDescriptionSource\":\"sameAsSeo\",\"twitterDescriptionField\":\"\",\"twitterImageIds\":\"\",\"twitterImageSource\":\"sameAsSeo\",\"twitterImageField\":\"image\",\"twitterImageTransform\":\"1\",\"twitterImageTransformMode\":\"crop\",\"twitterImageDescriptionSource\":\"sameAsSeo\",\"twitterImageDescriptionField\":\"\",\"ogTitleSource\":\"sameAsSeo\",\"ogTitleField\":\"\",\"ogSiteNamePositionSource\":\"fromCustom\",\"ogDescriptionSource\":\"sameAsSeo\",\"ogDescriptionField\":\"\",\"ogImageIds\":\"\",\"ogImageSource\":\"sameAsSeo\",\"ogImageField\":\"image\",\"ogImageTransform\":\"1\",\"ogImageTransformMode\":\"crop\",\"ogImageDescriptionSource\":\"sameAsSeo\",\"ogImageDescriptionField\":\"\"}');
/*!40000 ALTER TABLE `seomatic_metabundles` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sitegroups` VALUES (1,'Foster Commerce Dot All 2022','2022-07-24 18:09:58','2022-07-24 18:09:58',NULL,'96429840-47c0-490f-a057-4565f9d9d895');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sites` VALUES (1,1,1,'1','Foster Commerce Dot All 2022','default','en-US',1,'$CRAFT_BASE_URL',1,'2022-07-24 18:09:58','2022-07-25 00:16:45',NULL,'f8a2a825-4c38-46e8-853b-b3ee5d46969b');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `stripe_customers`
--

LOCK TABLES `stripe_customers` WRITE;
/*!40000 ALTER TABLE `stripe_customers` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `stripe_customers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `stripe_invoices`
--

LOCK TABLES `stripe_invoices` WRITE;
/*!40000 ALTER TABLE `stripe_invoices` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `stripe_invoices` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `stripe_paymentintents`
--

LOCK TABLES `stripe_paymentintents` WRITE;
/*!40000 ALTER TABLE `stripe_paymentintents` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `stripe_paymentintents` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structureelements` VALUES (1,2,NULL,1,1,2,0,'2022-07-25 00:40:24','2022-07-25 00:40:50','a0192612-7fd3-4dc5-8478-6cbcd288798a');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `structures` VALUES (1,NULL,'2022-07-24 23:27:23','2022-07-24 23:27:23',NULL,'1c741add-2650-4095-a422-47bd2ba29393'),(2,NULL,'2022-07-24 23:36:04','2022-07-24 23:36:04',NULL,'31df17bf-3c53-4a00-a46f-014c47f15584');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'admin@fostercommerce.com','$2y$13$RXO5V7oXdCPwhnPmStZ.1ulAbqYF3jME.dgMVJccratBikhiBokfa','2022-07-25 16:43:12',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2022-07-24 18:10:00','2022-07-24 18:10:00','2022-07-25 16:43:12');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Images','','2022-07-24 23:15:57','2022-07-24 23:15:57','da50e70c-e162-4219-8463-503070d6db45');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `volumes` VALUES (1,2,'Images','images','localAssetImages','','','site',NULL,1,'2022-07-24 23:15:57','2022-07-24 23:15:57',NULL,'6208c751-b47b-4315-ac54-cd1f33debd7a');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2022-07-24 18:10:02','2022-07-24 18:10:02','f89ba255-70f5-4be9-84e0-94a2ee505ce2'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2022-07-24 18:10:02','2022-07-24 18:10:02','f9db1769-17f5-46c9-b53f-7af8752e52a2'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2022-07-24 18:10:02','2022-07-24 18:10:02','77fa085f-2d36-4655-a0a4-9df08fcfe333'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2022-07-24 18:10:02','2022-07-24 18:10:02','8aa69405-710a-49cc-a502-abbb5431db96');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-25 17:11:12
